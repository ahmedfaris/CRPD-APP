# 🚀 Local Server & PostgreSQL Deployment Guide
## Enterprise IT Service Desk & Device Asset Management System

This document provides complete instructions for exporting, installing, and running this application on your own **local server** (on-premise, internal intranet, or private VPS) connected to a **PostgreSQL** database.

---

## 📋 System Requirements

| Component | Minimum | Recommended |
|---|---|---|
| **OS** | Ubuntu 22.04 / 24.04 LTS, Debian 12, RHEL 9, or Windows Server | Ubuntu 24.04 LTS / Docker Host |
| **CPU / RAM** | 2 vCPU / 2 GB RAM | 4 vCPU / 4 GB RAM |
| **Node.js** | Node.js v20.x or v22.x LTS | Node.js v20.18 LTS |
| **Database** | PostgreSQL 14+ | PostgreSQL 16 |
| **Docker (Option 1)**| Docker Engine 24+ & Docker Compose v2+ | Latest Docker Compose |

---

## ⚡ Option 1: Quick Docker Compose Deployment (Recommended)

This is the fastest, cleanest, and most isolated way to run the entire stack (PostgreSQL + App) in a single command.

### Step 1: Copy Application to Server
Transfer the project folder or the archive (`itsm_app_export_*.tar.gz`) to your server:
```bash
# Extract if you transferred the tar.gz archive
tar -xzf itsm_app_export_*.tar.gz
cd export_bundle # or cd project_directory
```

### Step 2: Configure Environment
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Open `.env` and set a strong `JWT_SECRET`:
```env
JWT_SECRET="replace-with-a-random-32-character-secret-string"
```

### Step 3: Launch with Docker Compose
Run the following command to build the image, start PostgreSQL, run the initial schema migrations, and launch the service:
```bash
docker compose up -d --build
```

### Step 4: Verify Health
```bash
docker compose ps
docker compose logs -f app
```
You can now access the system in your web browser:
👉 **`http://<YOUR_SERVER_IP>:3000`**

---

## 🛠️ Option 2: Native Bare-Metal / Local Server Deployment

Follow this guide if you are deploying directly onto an operating system without Docker.

### 1. Install PostgreSQL 16 and Node.js 20

#### On Ubuntu / Debian:
```bash
# 1. Update package list
sudo apt update && sudo apt upgrade -y

# 2. Install Node.js 20 LTS via NodeSource
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs build-essential

# 3. Install PostgreSQL 16
sudo apt install -y postgresql postgresql-contrib

# 4. Verify installations
node -v    # Should show v20.x
npm -v
psql --version
```

---

### 2. Configure PostgreSQL Database & User

Log into PostgreSQL and create the dedicated database and user:
```bash
sudo -u postgres psql
```

Inside the PostgreSQL prompt (`psql`), execute:
```sql
-- 1. Create a secure user
CREATE USER itsm_user WITH ENCRYPTED PASSWORD 'YourSecurePassword2026!';

-- 2. Create the production database
CREATE DATABASE itsm_db OWNER itsm_user;

-- 3. Grant full permissions
GRANT ALL PRIVILEGES ON DATABASE itsm_db TO itsm_user;

-- 4. Connect to the database and grant schema privileges
\c itsm_db
GRANT ALL ON SCHEMA public TO itsm_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO itsm_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO itsm_user;

\q
```

---

### 3. Initialize Schema & Initial Seed Data

You have two convenient ways to initialize the database:

#### Method A: Direct SQL Import (Fastest)
Run the provided `init-db.sql` directly into your PostgreSQL database:
```bash
psql -U itsm_user -d itsm_db -h localhost -f init-db.sql
```

#### Method B: Automated Application Startup
The application automatically checks and creates missing tables (`initTicketTables.ts`) and seeds initial administrative users on startup.

---

### 4. Configure Application Environment

1. Navigate to the project root directory:
```bash
cd /opt/itsm-app  # or your installation path
```

2. Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

3. Edit `.env` with your PostgreSQL credentials:
```env
PORT=3000
NODE_ENV=production

# Strong JWT Secret
JWT_SECRET="e9834b92c4b8109d94f275e7a932d01e4a781b29"

# PostgreSQL Connection String
DATABASE_URL="postgres://itsm_user:YourSecurePassword2026!@localhost:5432/itsm_db"

# Or Discrete Parameters:
SQL_HOST="localhost"
SQL_PORT="5432"
SQL_USER="itsm_user"
SQL_PASSWORD="YourSecurePassword2026!"
SQL_DB_NAME="itsm_db"
DATABASE_SSL="false"
```

---

### 5. Install Dependencies & Build

```bash
# Install dependencies
npm install

# Test PostgreSQL connection
npm run db:test

# Build production assets (Vite Frontend + Node.js bundle)
npm run build
```

---

### 6. Run as a Background Service with PM2 (Recommended)

To ensure the application stays online, restarts on server reboot, and manages logs, use **PM2**:

```bash
# Install PM2 globally
sudo npm install -g pm2

# Start the application
pm2 start dist/server.cjs --name "itsm-desk"

# Configure PM2 to start on system boot
pm2 startup
pm2 save

# Check status and logs
pm2 status
pm2 logs itsm-desk
```

#### Alternative: Linux `systemd` Service
If you prefer standard systemd:
Create `/etc/systemd/system/itsm-desk.service`:
```ini
[Unit]
Description=Enterprise IT Service Desk
After=network.target postgresql.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/itsm-app
ExecStart=/usr/bin/node /opt/itsm-app/dist/server.cjs
Restart=always
RestartSec=5
Environment=NODE_ENV=production
Environment=PORT=3000

[Install]
WantedBy=multi-user.target
```
Enable and start the service:
```bash
sudo systemctl daemon-reload
sudo systemctl enable itsm-desk
sudo systemctl start itsm-desk
sudo systemctl status itsm-desk
```

---

## 🌐 Nginx Reverse Proxy Setup (Port 80 / 443 HTTPS)

To access the system on standard web ports (`80` or `443`) and use custom domain names with SSL:

1. Install Nginx:
```bash
sudo apt install -y nginx
```

2. Create `/etc/nginx/sites-available/itsm.conf`:
```nginx
server {
    listen 80;
    server_name itsm.yourdomain.local; # or your server IP

    # Increase maximum upload size for ticket attachments
    client_max_body_size 25M;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

3. Enable site and test configuration:
```bash
sudo ln -s /etc/nginx/sites-available/itsm.conf /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

---

## 🔑 Default Credentials & First Login

Once the application is running, log in with the initial administrative account:

| Account | Email | Password | Role / Permissions |
|---|---|---|---|
| **System Administrator** | `admin@system.local` | `Admin@2026!` | Full Admin / All Permissions |
| **Operational Staff** | `ahmed.faris89@gmail.com` | `Admin@2026!` | Standard Employee / Ticket Submitter |

> 🔒 **Security Best Practice:** After initial login, go to **User Management** -> Edit User -> Change Password to update passwords immediately.

---

## 💾 PostgreSQL Maintenance & Backups

### Create a Database Backup (`pg_dump`):
```bash
pg_dump -U itsm_user -h localhost -d itsm_db -F c -b -v -f "/backup/itsm_db_$(date +%Y%m%d_%H%M%S).dump"
```

### Restore from Backup:
```bash
pg_restore -U itsm_user -h localhost -d itsm_db -v "/backup/itsm_db_backup.dump"
```

### Diagnostic Connection Test:
```bash
npm run db:test
```
This script validates your environment variables, verifies PostgreSQL TCP communication, checks database version, and inspects all registered tables.
