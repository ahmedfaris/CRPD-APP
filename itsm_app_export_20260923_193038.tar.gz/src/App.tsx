import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { TicketProvider, useTickets } from './context/TicketContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { ThemeProvider } from './context/ThemeContext';
import { LoginView } from './components/LoginView';
import { MetroNavbar } from './components/MetroNavbar';
import { MetroDashboard } from './components/MetroDashboard';
import { ArchivingApp } from './components/ArchivingApp';
import { EmployeeManagementApp } from './components/EmployeeManagementApp';
import { Navbar } from './components/Navbar';
import { TicketList } from './components/TicketList';
import { TicketDetailModal } from './components/TicketDetailModal';
import { CreateTicketModal } from './components/CreateTicketModal';
import { DashboardView } from './components/DashboardView';
import { UserManagementView } from './components/UserManagementView';
import { TeamManagementView } from './components/TeamManagementView';
import { UserManagementAppView } from './components/UserManagementAppView';
import { UserPolicyControlView } from './components/UserPolicyControlView';
import { ChangePasswordModal } from './components/ChangePasswordModal';
import { SystemSettingsModal } from './components/SystemSettingsModal';
import { ExportDocsModal } from './components/ExportDocsModal';
import { OrgStructureApp } from './components/OrgStructureApp';
import { DeviceManagementApp } from './components/DeviceManagementApp';
import { Ticket } from './types';
import { Database, Shield, Terminal, ArrowLeft } from 'lucide-react';

import { OrgProvider } from './context/OrgContext';
import { DeviceProvider } from './context/DeviceContext';

function AppContent() {
  const { isAuthenticated, currentUser, isAdmin, canAccessTeamManagement } = useAuth();
  const { tickets } = useTickets();
  const { t, language, dir } = useLanguage();

  // Active Organization App within the Portal: Metro Hub, Tickets, Archiving, Employees, Policy, Org Structure, or Devices
  const [currentApp, setCurrentApp] = useState<'metro' | 'tickets' | 'archiving' | 'employees' | 'policy' | 'org-structure' | 'devices'>('metro');

  // Ticket Management Sub-tabs
  const [currentTab, setCurrentTab] = useState<'tickets' | 'dashboard' | 'users'>('tickets');
  const [teamSubTab, setTeamSubTab] = useState<'teams' | 'roles'>('teams');
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showDocsExportModal, setShowDocsExportModal] = useState(false);

  // If user is not authenticated or undergoing 2FA, show the Login/2FA flow
  if (!isAuthenticated) {
    return <LoginView />;
  }

  // 1. METRO DASHBOARD HUB VIEW
  if (currentApp === 'metro') {
    return (
      <div className="min-h-screen dark:bg-slate-950 bg-slate-50 dark:text-slate-100 text-slate-900 flex flex-col font-sans" dir={dir}>
        <MetroNavbar 
          currentApp="metro" 
          onSelectApp={setCurrentApp} 
          onOpenDocsExport={() => setShowDocsExportModal(true)}
        />
        <main className="flex-1">
          <MetroDashboard
            onSelectApp={setCurrentApp}
            ticketCount={tickets.length}
            documentCount={5}
            employeeCount={6}
            onOpenSettings={() => setShowSettingsModal(true)}
            onOpenDocsExport={() => setShowDocsExportModal(true)}
          />
        </main>
      {/* Main Container Modals */}
        {showSettingsModal && (
          <SystemSettingsModal 
            onClose={() => setShowSettingsModal(false)} 
            onOpenDocsExport={() => setShowDocsExportModal(true)}
          />
        )}
        {showDocsExportModal && (
          <ExportDocsModal onClose={() => setShowDocsExportModal(false)} />
        )}
      </div>
    );
  }

  // 2. ARCHIVING & ELECTRONIC RECORDS APP VIEW
  if (currentApp === 'archiving') {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans" dir={dir}>
        <MetroNavbar 
          currentApp="archiving" 
          onSelectApp={setCurrentApp} 
          onOpenDocsExport={() => setShowDocsExportModal(true)}
        />
        <main className="flex-1">
          <ArchivingApp onBackToMetro={() => setCurrentApp('metro')} />
        </main>
        {showDocsExportModal && (
          <ExportDocsModal onClose={() => setShowDocsExportModal(false)} />
        )}
      </div>
    );
  }

  // 3. EMPLOYEE MANAGEMENT & DIRECTORY APP VIEW
  if (currentApp === 'employees') {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans" dir={dir}>
        <MetroNavbar 
          currentApp="employees" 
          onSelectApp={setCurrentApp} 
          onOpenDocsExport={() => setShowDocsExportModal(true)}
        />
        <main className="flex-1">
          <EmployeeManagementApp onBackToMetro={() => setCurrentApp('metro')} />
        </main>
        {showDocsExportModal && (
          <ExportDocsModal onClose={() => setShowDocsExportModal(false)} />
        )}
      </div>
    );
  }

  // 4. USER MANAGEMENT APP VIEW
  if (currentApp === 'policy') {
    return (
      <>
        <UserManagementAppView 
          onBackToHub={() => setCurrentApp('metro')} 
        />
        {showDocsExportModal && (
          <ExportDocsModal onClose={() => setShowDocsExportModal(false)} />
        )}
      </>
    );
  }

  // 5. ORGANIZATIONAL STRUCTURE APP VIEW
  if (currentApp === 'org-structure') {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans" dir={dir}>
        <MetroNavbar 
          currentApp="org-structure" 
          onSelectApp={setCurrentApp} 
          onOpenDocsExport={() => setShowDocsExportModal(true)}
        />
        <main className="flex-1">
          <OrgStructureApp onBackToMetro={() => setCurrentApp('metro')} />
        </main>
        {showDocsExportModal && (
          <ExportDocsModal onClose={() => setShowDocsExportModal(false)} />
        )}
      </div>
    );
  }

  // 6. ELECTRONIC DEVICE MANAGEMENT APP VIEW
  if (currentApp === 'devices') {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans" dir={dir}>
        <MetroNavbar 
          currentApp="devices" 
          onSelectApp={setCurrentApp} 
          onOpenDocsExport={() => setShowDocsExportModal(true)}
        />
        <main className="flex-1">
          <DeviceManagementApp onBackToMetro={() => setCurrentApp('metro')} />
        </main>
        {showDocsExportModal && (
          <ExportDocsModal onClose={() => setShowDocsExportModal(false)} />
        )}
      </div>
    );
  }

  // 7. TICKET MANAGEMENT SYSTEM VIEW
  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans selection:bg-blue-100 selection:text-blue-900" dir={dir}>
      
      {/* Top Navbar with Metro Hub link & Language Toggle */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenCreateTicket={() => setShowCreateModal(true)}
        onBackToMetro={() => setCurrentApp('metro')}
        onOpenDocsExport={() => setShowDocsExportModal(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* Return to Metro Bar */}
        <div className="flex items-center justify-between bg-white px-4 py-2.5 rounded-xl border border-slate-200 shadow-xs">
          <button
            onClick={() => setCurrentApp('metro')}
            className="flex items-center space-x-1.5 text-xs font-bold text-blue-700 hover:text-blue-800 transition cursor-pointer"
          >
            <ArrowLeft className={`w-4 h-4 mx-1 ${dir === 'rtl' ? 'rotate-180' : ''}`} />
            <span>{t('nav.allApps')} ({language === 'ar' ? 'مركز مترو' : 'Metro Hub'})</span>
          </button>

          <span className="text-xs text-slate-500 font-mono">
            {language === 'ar' ? 'التطبيق: ' : 'App: '}
            <strong className="text-slate-800">{language === 'ar' ? 'نظام التذاكر والدعم' : 'Ticket Management'}</strong>
          </span>
        </div>

        {/* Tab Views */}
        {currentTab === 'tickets' && (
          <TicketList
            onSelectTicket={(ticket: Ticket) => setSelectedTicketId(ticket.id)}
            onOpenCreate={() => setShowCreateModal(true)}
            onNavigateToDashboard={() => setCurrentTab('dashboard')}
          />
        )}

        {currentTab === 'dashboard' && (
          <DashboardView
            onSelectTicket={(ticket: Ticket) => setSelectedTicketId(ticket.id)}
            onOpenCreate={() => setShowCreateModal(true)}
          />
        )}

        {currentTab === 'users' && canAccessTeamManagement && (
          teamSubTab === 'roles' && isAdmin ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
                <button
                  onClick={() => setTeamSubTab('teams')}
                  className="flex items-center space-x-1.5 text-xs font-bold text-blue-600 hover:text-blue-700 cursor-pointer"
                >
                  <ArrowLeft className={`w-4 h-4 mx-1 ${dir === 'rtl' ? 'rotate-180' : ''}`} />
                  <span>{language === 'ar' ? 'العودة إلى جدول فرق العمل' : 'Back to Teams Table'}</span>
                </button>
                <span className="text-xs font-semibold text-slate-500">
                  {language === 'ar' ? 'تهيئة صلاحيات الأدوار (بما فيها إدارة الفرق)' : 'Configure Role Permissions'}
                </span>
              </div>
              <UserManagementView onOpenCreateModal={() => {}} />
            </div>
          ) : (
            <TeamManagementView onNavigateToRoles={isAdmin ? () => setTeamSubTab('roles') : undefined} />
          )
        )}

      </main>

      {/* Modals */}
      {selectedTicketId && (
        <TicketDetailModal
          ticketId={selectedTicketId}
          onClose={() => setSelectedTicketId(null)}
        />
      )}

      {showCreateModal && (
        <CreateTicketModal
          onClose={() => setShowCreateModal(false)}
          onCreated={(newId) => {
            setShowCreateModal(false);
            setSelectedTicketId(newId);
          }}
        />
      )}

      {showSettingsModal && (
        <SystemSettingsModal 
          onClose={() => setShowSettingsModal(false)} 
          onOpenDocsExport={() => setShowDocsExportModal(true)}
        />
      )}

      {showDocsExportModal && (
        <ExportDocsModal onClose={() => setShowDocsExportModal(false)} />
      )}

      {/* Mandatory Password Change Filter Interceptor */}
      <ChangePasswordModal />

      {/* Enterprise Bottom Status Bar */}
      <footer className="bg-white border-t border-slate-200 py-3 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-4">
            <span className="flex items-center font-medium text-slate-700 mx-1">
              <Database className="w-3.5 h-3.5 mx-1 text-emerald-600" />
              TicketManagementDB ({language === 'ar' ? 'متصل' : 'Online'})
            </span>
            <span className="hidden sm:inline text-slate-300 mx-1">•</span>
            <span className="hidden sm:flex items-center mx-1">
              <Shield className="w-3.5 h-3.5 mx-1 text-blue-600" />
              {language === 'ar' ? '2FA نشط (سماحية ±1د)' : '2FA Active (±1m tolerance)'}
            </span>
            <span className="hidden md:inline text-slate-300 mx-1">•</span>
            <span className="hidden md:flex items-center mx-1">
              <Terminal className="w-3.5 h-3.5 mx-1 text-slate-500" />
              Serilog Seq Sink (:5341)
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <span>{language === 'ar' ? 'الجلسة: ' : 'Session: '}<strong className="text-slate-800">{currentUser?.fullName}</strong> ({currentUser?.role})</span>
          </div>
        </div>
      </footer>

    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <OrgProvider>
            <DeviceProvider>
              <TicketProvider>
                <AppContent />
              </TicketProvider>
            </DeviceProvider>
          </OrgProvider>
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
