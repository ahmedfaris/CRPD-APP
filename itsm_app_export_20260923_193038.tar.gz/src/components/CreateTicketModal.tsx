import React, { useState } from 'react';
import { useTickets, getSlaMinutes, getAssignedTeamForTicketType } from '../context/TicketContext';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  TicketType, 
  PriorityStars, 
  TicketPriority, 
  SupportedInformationSystem, 
  UserRequestAction,
  TicketAttachment,
  TicketStage,
  HardwareDeviceType,
  DepartmentRequestDoc,
  ElectronicDevice
} from '../types';
import { HardwareAssetSelector, mapDeviceTypeToHardwareType } from './HardwareAssetSelector';
import { WordEditor } from './WordEditor';
import { PictureAttachmentsUploader } from './PictureAttachmentsUploader';
import { StarPrioritySelector, starsToPriority } from './StarPrioritySelector';
import { 
  X, 
  Send, 
  Wrench, 
  Laptop, 
  UserPlus, 
  ShieldAlert, 
  Users, 
  CheckCircle2, 
  ArrowLeft,
  ArrowRight,
  Server,
  FileText,
  UploadCloud,
  FileCheck,
  Printer,
  Calendar,
  Hash,
  Info,
  ChevronRight,
  HardDrive,
  Cpu,
  Trash2,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';

interface CreateTicketModalProps {
  onClose: () => void;
  onCreated: (ticketId: string) => void;
}

const SUPPORTED_SYSTEMS: SupportedInformationSystem[] = [
  'Old IMS',
  'New IMS',
  '2FA',
  'Active Directory',
  'Enterprise ERP',
  'Document Archiving',
  'Corporate Email & 365',
  'Other System',
];

const HARDWARE_DEVICE_TYPES: HardwareDeviceType[] = [
  'Computer',
  'Printer',
  'FingerPrint Device',
  'Scanner',
  'Network Device',
  'Other Device',
];

const USER_REQUEST_ACTIONS: UserRequestAction[] = [
  'Create New User',
  'Delete User',
  'Modify User Account & Permissions',
  'Reset Password / Unlock Account',
  'Role & Privilege Elevation',
  'Other Request',
];

export function CreateTicketModal({ onClose, onCreated }: CreateTicketModalProps) {
  const { createTicket, tickets, addComment, systemSettings } = useTickets();
  const { currentUser, isOperationalUser, isAdmin, switchUser, users } = useAuth();
  const { language, dir, t } = useLanguage();

  // Multi-step Wizard: Step 1 (Type), Step 2 (Specifics), Step 3 (Mandatory PDF), Step 4 (Confirmation)
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4>(1);

  // Step 1: Selected Ticket Type
  const [selectedType, setSelectedType] = useState<TicketType | null>(null);

  // Step 2: Core Fields
  const [title, setTitle] = useState('');
  const [descriptionHtml, setDescriptionHtml] = useState('');
  const [priorityStars, setPriorityStars] = useState<PriorityStars>(2);
  const [stage] = useState<TicketStage>('New');

  // Specific: Hardware Maintenance (Linked directly to Asset Management System)
  const [hardwareDeviceType, setHardwareDeviceType] = useState<HardwareDeviceType>('Computer');
  const [selectedDeviceId, setSelectedDeviceId] = useState<string | number | null>(null);
  const [selectedDevice, setSelectedDevice] = useState<ElectronicDevice | null>(null);
  const [assetType, setAssetType] = useState('');
  const [serialOrBarcode, setSerialOrBarcode] = useState('');
  const [physicalLocation, setPhysicalLocation] = useState('');

  const handleSelectAssetDevice = (device: ElectronicDevice) => {
    setSelectedDeviceId(device.id);
    setSelectedDevice(device);
    const mappedType = mapDeviceTypeToHardwareType(device.deviceType, device.category);
    setHardwareDeviceType(mappedType);
    setAssetType(`${device.brand} ${device.model}`.trim());
    setSerialOrBarcode(device.serialNumber || device.deviceCode || '');
    setPhysicalLocation(device.location || device.department || '');
  };

  const handleClearAssetDevice = () => {
    setSelectedDeviceId(null);
    setSelectedDevice(null);
    setAssetType('');
    setSerialOrBarcode('');
  };

  // Specific: Systems Troubleshoot & User Request
  const [targetSystem, setTargetSystem] = useState<SupportedInformationSystem>('Old IMS');
  const [customSystemName, setCustomSystemName] = useState('');
  const [systemIssueCategory, setSystemIssueCategory] = useState('Error / Crash');

  // Specific: User Request
  const [userRequestAction, setUserRequestAction] = useState<UserRequestAction>('Create New User');
  const [targetFullName, setTargetFullName] = useState('');
  const [targetUsername, setTargetUsername] = useState('');
  const [targetDepartment, setTargetDepartment] = useState('');
  const [roleOrPermissions, setRoleOrPermissions] = useState('');
  const [businessJustification, setBusinessJustification] = useState('');

  // Picture attachments (JPEG/PNG up to 3)
  const [attachments, setAttachments] = useState<TicketAttachment[]>([]);
  
  // Optional initial comment
  const [initialComment, setInitialComment] = useState('');

  // Step 3: Mandatory Department Request PDF Attachment
  const defaultReqNumber = `DEP-REQ-2026-${(tickets.length + 89).toString().padStart(4, '0')}`;
  const [deptRequestNumber, setDeptRequestNumber] = useState(defaultReqNumber);
  const [deptRequestDate, setDeptRequestDate] = useState(new Date().toISOString().split('T')[0]);
  const [deptRequestDoc, setDeptRequestDoc] = useState<DepartmentRequestDoc | null>(null);
  const [pdfUploadError, setPdfUploadError] = useState<string | null>(null);

  // Auto-calculated fields
  const ticketPriority: TicketPriority = starsToPriority(priorityStars);
  const sla = getSlaMinutes(ticketPriority, systemSettings);
  const nextTicketNumber = `TCK-2026-${String(tickets.length + 1).padStart(4, '0')}`;

  // Helper translations
  const getTicketTypeTitle = (type: TicketType) => {
    if (language === 'ar') {
      switch (type) {
        case 'Hardware Maintenance': return 'صيانة الأجهزة والمعدات';
        case 'Systems Troubleshoot': return 'معالجة مشاكل وأعطال الأنظمة';
        case 'User Request': return 'طلبات المستخدمين والصلاحيات';
      }
    }
    return type;
  };

  const getHardwareLabel = (device: HardwareDeviceType) => {
    if (language === 'ar') {
      switch (device) {
        case 'Computer': return 'حاسوب / محطة عمل (Computer)';
        case 'Printer': return 'طابعة عادية / حرارية (Printer)';
        case 'FingerPrint Device': return 'جهاز البصمة والحضور (FingerPrint)';
        case 'Scanner': return 'ماسح ضوئي / باركود (Scanner)';
        case 'Network Device': return 'جهاز شبكة / راوتر / سويتش (Network)';
        case 'Other Device': return 'جهاز / أصل آخر...';
      }
    }
    return device;
  };

  const getSystemLabel = (sys: SupportedInformationSystem) => {
    if (language === 'ar') {
      switch (sys) {
        case 'Old IMS': return 'نظام إدارة المخزون القديم (Old IMS)';
        case 'New IMS': return 'نظام المخزون المتطور (New IMS)';
        case '2FA': return 'نظام المصادقة الثنائية (2FA)';
        case 'Active Directory': return 'دليل النطاق (Active Directory)';
        case 'Document Archiving': return 'أرشيف الوثائق الإلكتروني';
        case 'Enterprise ERP': return 'نظام تخطيط الموارد ERP';
        case 'Corporate Email & 365': return 'البريد الإلكتروني المؤسسي & 365';
        case 'Other System': return 'نظام مؤسسي آخر...';
      }
    }
    return sys;
  };

  const getUserActionLabel = (action: UserRequestAction) => {
    if (language === 'ar') {
      switch (action) {
        case 'Create New User': return 'إنشاء حساب مستخدم جديد';
        case 'Delete User': return 'حذف أو إلغاء حساب مستخدم';
        case 'Modify User Account & Permissions': return 'تعديل بيانات الحساب والصلاحيات';
        case 'Reset Password / Unlock Account': return 'إعادة تعيين كلمة المرور / إلغاء القفل';
        case 'Role & Privilege Elevation': return 'ترقية الأدوار والامتيازات';
        case 'Other Request': return 'طلب وصول / إجراء آخر...';
      }
    }
    return action;
  };

  const getTeamName = (type: TicketType) => {
    const teamRes = getAssignedTeamForTicketType(type);
    if (language === 'ar') {
      switch (teamRes.teamType) {
        case 'Technical Team':
          return 'الفريق الفني (مختص بالأجهزة والمعدات)';
        case 'Database and Systems Admins':
          return 'مسؤولو قواعد البيانات والأنظمة (أعطال البرمجيات)';
        case 'Security Team':
          return 'فريق الأمن السيبراني (طلبات المستخدمين والصلاحيات)';
      }
    }
    return teamRes.teamName;
  };

  if (!currentUser) return null;

  // 1. ACCESS CONTROL ENFORCEMENT: Only Operational Users and Admins can create tickets
  if (!isOperationalUser && !isAdmin) {
    const operationalUserSample = users.find((u) => u.userType === 'Operational User');

    return (
      <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in" dir={dir}>
        <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden">
          
          <div className="px-6 py-4 border-b border-slate-200 bg-rose-50 flex items-center justify-between">
            <div className="flex items-center space-x-2.5 text-rose-800">
              <ShieldAlert className="w-5 h-5 text-rose-600" />
              <h2 className="text-base font-bold">
                {language === 'ar' ? 'الصلاحية مقيدة' : 'Access Restricted'}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 space-y-4 text-xs sm:text-sm">
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs leading-relaxed">
              <p className="font-bold text-amber-950 mb-1 flex items-center">
                <Info className="w-4 h-4 mx-1.5 text-amber-700" />
                {language === 'ar' 
                  ? 'يقتصر إنشاء التذاكر على المستخدمين التشغيليين والمدراء فقط'
                  : 'Only Operational Users and Admins Can Create Tickets'}
              </p>
              {language === 'ar'
                ? 'وفقًا لسياسات الحوكمة المؤسسية المعتمدة، الفنيون يديرون معالجة التذاكر، بينما يقتصر إنشاء التذاكر على المستخدمين التشغيليين والمدراء.'
                : 'According to corporate governance policy, Technical users manage configuration and ticket resolution, while Operational Users and Admins can create support tickets.'}
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1.5">
              <div className="text-slate-500 font-medium">{language === 'ar' ? 'الحساب الحالي:' : 'Currently Logged In:'}</div>
              <div className="font-bold text-slate-800 text-sm">{currentUser.fullName}</div>
              <div className="text-slate-600">{language === 'ar' ? 'البريد:' : 'Email:'} {currentUser.email}</div>
              <div className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-purple-100 text-purple-800 border border-purple-200">
                {language === 'ar' ? `نوع الحساب: ${currentUser.userType || currentUser.role}` : `User Type: ${currentUser.userType || currentUser.role}`}
              </div>
            </div>

            {operationalUserSample && (
              <div className="pt-2">
                <p className="text-xs text-slate-500 mb-2">
                  {language === 'ar' 
                    ? 'لتجربة إنشاء تذكرة، يمكنك التبديل إلى حساب مستخدم تشغيلي:'
                    : 'To test ticket creation, switch to an Operational User account:'}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    switchUser(operationalUserSample.id);
                  }}
                  className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center space-x-2 transition shadow-xs cursor-pointer"
                >
                  <Users className="w-4 h-4 mx-1" />
                  <span>
                    {language === 'ar'
                      ? `تبديل إلى ${operationalUserSample.fullName} (مستخدم تشغيلي)`
                      : `Switch to ${operationalUserSample.fullName} (Operational User)`}
                  </span>
                </button>
              </div>
            )}
          </div>

          <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200 rounded-lg transition cursor-pointer"
            >
              {language === 'ar' ? 'إغلاق' : 'Close'}
            </button>
          </div>

        </div>
      </div>
    );
  }

  // Handle PDF Upload from File Input
  const handlePdfFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPdfUploadError(null);

    // Validate type strictly PDF
    if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
      setPdfUploadError(
        language === 'ar'
          ? 'عذراً، يجب أن يكون الملف المرفق بصيغة مستند PDF فقط (.pdf).'
          : 'Invalid file format. The department request must strictly be a PDF document (.pdf).'
      );
      return;
    }

    // Max 10MB
    if (file.size > 10 * 1024 * 1024) {
      setPdfUploadError(
        language === 'ar'
          ? 'حجم ملف الـ PDF يتجاوز الحد الأقصى المسموح به (10 ميجابايت).'
          : 'PDF document exceeds 10MB size limit.'
      );
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setDeptRequestDoc({
        requestNumber: deptRequestNumber.trim() || defaultReqNumber,
        requestDate: deptRequestDate,
        source: 'PC Upload',
        fileName: file.name,
        fileSize: `${(file.size / 1024).toFixed(1)} KB`,
        dataUrl,
        uploadedAt: new Date().toISOString(),
      });
    };
    reader.readAsDataURL(file);
  };

  // Step Navigation Handlers
  const handleNextFromStep1 = (type: TicketType) => {
    setSelectedType(type);
    setCurrentStep(2);
  };

  const handleNextFromStep2 = () => {
    if (!title.trim()) {
      alert(language === 'ar' ? 'يرجى إدخال عنوان للبلاغ قبل المتابعة.' : 'Please enter a ticket title before proceeding.');
      return;
    }
    setCurrentStep(3);
  };

  const handleNextFromStep3 = () => {
    if (!deptRequestDoc) {
      setPdfUploadError(
        language === 'ar'
          ? 'المرفق إلزامي: لا يمكن الانتقال للتأكيد دون إرفاق مستند طلب القسم بصيغة PDF.'
          : 'Mandatory Requirement: You must attach the signed Department Request PDF before proceeding to confirmation.'
      );
      return;
    }
    setPdfUploadError(null);
    setCurrentStep(4);
  };

  // Final Submission in Step 4
  const handleFinalSubmit = () => {
    if (!selectedType || !deptRequestDoc) return;

    const actualTargetSystem = (targetSystem === 'Other System' && customSystemName.trim())
      ? customSystemName.trim()
      : targetSystem;

    const teamRes = getAssignedTeamForTicketType(selectedType);

    const createdTicket = createTicket(
      {
        title: title.trim(),
        description: descriptionHtml.trim() || `<p>${title.trim()}</p>`,
        ticketType: selectedType,
        priorityStars,
        priority: ticketPriority,
        teamId: teamRes.teamId,
        hardwareDeviceType: selectedType === 'Hardware Maintenance' ? hardwareDeviceType : undefined,
        deptRequest: deptRequestDoc,
        stage: 'New',
        targetSystem: (selectedType === 'Systems Troubleshoot' || selectedType === 'User Request') 
          ? actualTargetSystem 
          : undefined,
        userRequestAction: selectedType === 'User Request' ? userRequestAction : undefined,
        userRequestDetails: selectedType === 'User Request' ? {
          targetFullName: targetFullName.trim(),
          targetUsername: targetUsername.trim(),
          targetDepartment: targetDepartment.trim(),
          roleOrPermissions: roleOrPermissions.trim(),
          businessJustification: businessJustification.trim(),
        } : undefined,
        hardwareDetails: selectedType === 'Hardware Maintenance' ? {
          deviceId: selectedDeviceId || undefined,
          deviceCode: selectedDevice?.deviceCode || undefined,
          deviceType: hardwareDeviceType,
          assetType: assetType.trim() || (selectedDevice ? `${selectedDevice.brand} ${selectedDevice.model}` : hardwareDeviceType),
          brand: selectedDevice?.brand || undefined,
          model: selectedDevice?.model || undefined,
          serialOrBarcode: serialOrBarcode.trim(),
          physicalLocation: physicalLocation.trim(),
          department: selectedDevice?.department || undefined,
        } : undefined,
        attachments,
      },
      currentUser
    );

    if (initialComment.trim()) {
      addComment(createdTicket.id, initialComment.trim(), false, currentUser);
    }

    onCreated(createdTicket.id);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in" dir={dir}>
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3">
            {currentStep > 1 && (
              <button
                type="button"
                onClick={() => setCurrentStep((prev) => (prev - 1) as 1 | 2 | 3 | 4)}
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-200 transition mx-1"
                title={language === 'ar' ? 'الرجوع للخطوة السابقة' : 'Back to previous step'}
              >
                {dir === 'rtl' ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
              </button>
            )}
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-bold text-slate-900 mx-1">
                  {selectedType 
                    ? (language === 'ar' ? `إنشاء تذكرة: ${getTicketTypeTitle(selectedType)}` : `Create ${selectedType} Ticket`)
                    : (language === 'ar' ? 'إنشاء تذكرة دعم جديدة' : 'Create New Support Ticket')}
                </h2>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-blue-100 text-blue-800 border border-blue-200 font-semibold">
                  {nextTicketNumber}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {language === 'ar' ? 'مقدم الطلب:' : 'Requester:'} <strong className="text-slate-800">{currentUser.fullName}</strong> • 
                <span className="mx-1 text-emerald-700 font-semibold">
                  {language === 'ar' ? 'مستخدم تشغيلي' : 'Operational User'}
                </span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wizard Step Progress Tracker */}
        <div className="px-6 py-2.5 bg-slate-100/80 border-b border-slate-200 flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2 sm:space-x-4">
            {/* Step 1 */}
            <div className={`flex items-center space-x-1.5 ${currentStep >= 1 ? 'text-blue-700 font-bold' : 'text-slate-400'}`}>
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                currentStep >= 1 ? 'bg-blue-600 text-white' : 'bg-slate-300 text-slate-600'
              }`}>
                1
              </span>
              <span className="hidden sm:inline">{language === 'ar' ? 'نوع البلاغ' : 'Ticket Type'}</span>
            </div>

            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />

            {/* Step 2 */}
            <div className={`flex items-center space-x-1.5 ${currentStep >= 2 ? 'text-blue-700 font-bold' : 'text-slate-400'}`}>
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                currentStep >= 2 ? 'bg-blue-600 text-white' : 'bg-slate-300 text-slate-600'
              }`}>
                2
              </span>
              <span className="hidden sm:inline">{language === 'ar' ? 'تفاصيل البلاغ' : 'Specific Details'}</span>
            </div>

            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />

            {/* Step 3 */}
            <div className={`flex items-center space-x-1.5 ${currentStep >= 3 ? 'text-blue-700 font-bold' : 'text-slate-400'}`}>
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                currentStep >= 3 ? 'bg-blue-600 text-white' : 'bg-slate-300 text-slate-600'
              }`}>
                3
              </span>
              <span className="hidden sm:inline">{language === 'ar' ? 'طلب القسم (PDF)' : 'Dept Request (PDF)'}</span>
            </div>

            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />

            {/* Step 4 */}
            <div className={`flex items-center space-x-1.5 ${currentStep >= 4 ? 'text-blue-700 font-bold' : 'text-slate-400'}`}>
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                currentStep >= 4 ? 'bg-blue-600 text-white' : 'bg-slate-300 text-slate-600'
              }`}>
                4
              </span>
              <span className="hidden sm:inline">{language === 'ar' ? 'المراجعة والاعتماد' : 'Confirmation'}</span>
            </div>
          </div>

          <div className="text-[11px] text-slate-500 font-medium">
            {language === 'ar' ? `الخطوة ${currentStep} من 4` : `Step ${currentStep} of 4`}
          </div>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">

          {/* ============================================================ */}
          {/* STEP 1: PROMPT TO SELECT TICKET TYPE                          */}
          {/* ============================================================ */}
          {currentStep === 1 && (
            <div className="space-y-5 animate-in fade-in">
              <div className="text-center max-w-lg mx-auto space-y-1.5">
                <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                  {language === 'ar' ? 'الخطوة 1: تحديد تصنيف ونوع البلاغ' : 'Step 1: Classification Prompt'}
                </span>
                <h3 className="text-lg font-bold text-slate-900">
                  {language === 'ar' ? 'ما نوع البلاغ أو التذكرة التي ترغب بإنشائها؟' : 'What type of ticket would you like to create?'}
                </h3>
                <p className="text-xs text-slate-500">
                  {language === 'ar'
                    ? 'اختر نوع البلاغ. يُحال كل نوع تلقائياً إلى الفريق المختص (فريق الأجهزة، مسؤولو الأنظمة وقواعد البيانات، أو فريق الأمان).'
                    : 'Select the ticket type. Each type is automatically routed to its dedicated support team.'}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                
                {/* 1. Hardware Maintenance */}
                <button
                  type="button"
                  id="btn-select-hardware"
                  onClick={() => handleNextFromStep1('Hardware Maintenance')}
                  className="p-5 rounded-2xl border-2 border-slate-200 hover:border-blue-500 bg-white hover:bg-blue-50/30 text-start transition-all group flex flex-col justify-between shadow-xs hover:shadow-md cursor-pointer"
                >
                  <div className="space-y-3">
                    <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Wrench className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-700">
                        {language === 'ar' ? 'صيانة الأجهزة والمعدات' : 'Hardware Maintenance'}
                      </h4>
                      <p className="text-xs text-slate-500 mt-1 line-clamp-3">
                        {language === 'ar'
                          ? 'أجهزة الحاسوب، الطابعات، أجهزة البصمة، الماسحات الضوئية، وأجهزة الشبكات ومحطات العمل.'
                          : 'Computers, printers, fingerprint devices, scanners, network devices, and physical workstation hardware.'}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-600 space-y-1">
                    <div className="text-slate-400 font-medium">
                      {language === 'ar' ? 'يُحال تلقائياً إلى:' : 'Auto-routed to:'}
                    </div>
                    <div className="font-bold text-slate-800 text-[11px]">
                      {getTeamName('Hardware Maintenance')}
                    </div>
                  </div>
                </button>

                {/* 2. Systems Troubleshoot */}
                <button
                  type="button"
                  id="btn-select-troubleshoot"
                  onClick={() => handleNextFromStep1('Systems Troubleshoot')}
                  className="p-5 rounded-2xl border-2 border-slate-200 hover:border-blue-500 bg-white hover:bg-blue-50/30 text-start transition-all group flex flex-col justify-between shadow-xs hover:shadow-md cursor-pointer"
                >
                  <div className="space-y-3">
                    <div className="w-12 h-12 rounded-xl bg-blue-500/10 text-blue-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Laptop className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-700">
                        {language === 'ar' ? 'معالجة أعطال الأنظمة' : 'Systems Troubleshoot'}
                      </h4>
                      <p className="text-xs text-slate-500 mt-1 line-clamp-3">
                        {language === 'ar'
                          ? 'أعطال البرمجيات، قواعد البيانات، وبطء الاستجابة في الأنظمة: Old IMS, New IMS, 2FA, Active Directory وغيرها.'
                          : 'Software errors, database timeouts, crashes across Old IMS, New IMS, 2FA, Active Directory, and ERP.'}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-600 space-y-1">
                    <div className="text-slate-400 font-medium">
                      {language === 'ar' ? 'يُحال تلقائياً إلى:' : 'Auto-routed to:'}
                    </div>
                    <div className="font-bold text-slate-800 text-[11px]">
                      {getTeamName('Systems Troubleshoot')}
                    </div>
                  </div>
                </button>

                {/* 3. User Request */}
                <button
                  type="button"
                  id="btn-select-user-request"
                  onClick={() => handleNextFromStep1('User Request')}
                  className="p-5 rounded-2xl border-2 border-slate-200 hover:border-blue-500 bg-white hover:bg-blue-50/30 text-start transition-all group flex flex-col justify-between shadow-xs hover:shadow-md cursor-pointer"
                >
                  <div className="space-y-3">
                    <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <UserPlus className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-700">
                        {language === 'ar' ? 'طلبات المستخدمين والصلاحيات' : 'User Request'}
                      </h4>
                      <p className="text-xs text-slate-500 mt-1 line-clamp-3">
                        {language === 'ar'
                          ? 'إنشاء حساب جديد، حذف حساب، تعديل الصلاحيات، إعادة تعيين كلمة المرور، وترقية الأدوار.'
                          : 'Create user, delete user, modify permissions, password reset, or privilege elevation across enterprise systems.'}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-600 space-y-1">
                    <div className="text-slate-400 font-medium">
                      {language === 'ar' ? 'يُحال تلقائياً إلى:' : 'Auto-routed to:'}
                    </div>
                    <div className="font-bold text-slate-800 text-[11px]">
                      {getTeamName('User Request')}
                    </div>
                  </div>
                </button>

              </div>
            </div>
          )}

          {/* ============================================================ */}
          {/* STEP 2: SPECIFIC DETAILS & DESCRIPTION                       */}
          {/* ============================================================ */}
          {currentStep === 2 && selectedType && (
            <div className="space-y-5 text-xs sm:text-sm animate-in fade-in">
              
              {/* Type & Team Routing Banner */}
              <div className="p-3.5 bg-blue-50/80 border border-blue-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center space-x-2.5">
                  <span className="p-1.5 rounded-lg bg-blue-600 text-white mx-1">
                    {selectedType === 'Hardware Maintenance' ? (
                      <Wrench className="w-4 h-4" />
                    ) : selectedType === 'Systems Troubleshoot' ? (
                      <Laptop className="w-4 h-4" />
                    ) : (
                      <UserPlus className="w-4 h-4" />
                    )}
                  </span>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-bold text-blue-900 mx-1">
                        {getTicketTypeTitle(selectedType)}
                      </span>
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-blue-200 text-blue-900 font-semibold">
                        {language === 'ar' ? 'المرحلة: جديد' : `Stage: ${stage}`}
                      </span>
                    </div>
                    <div className="text-[12px] text-blue-800 mt-0.5">
                      {language === 'ar' ? 'الفريق المسند إليه آلياً:' : 'Auto-Assigned Team:'}{' '}
                      <strong>{getTeamName(selectedType)}</strong>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="text-xs font-semibold text-blue-700 hover:text-blue-900 underline self-start sm:self-auto cursor-pointer"
                >
                  {language === 'ar' ? 'تغيير نوع البلاغ' : 'Change Type'}
                </button>
              </div>

              {/* SPECIFIC FIELDS: HARDWARE MAINTENANCE (Loaded from Asset Management System + Quick Add) */}
              {selectedType === 'Hardware Maintenance' && (
                <HardwareAssetSelector
                  selectedDeviceId={selectedDeviceId}
                  selectedDevice={selectedDevice}
                  onSelectDevice={handleSelectAssetDevice}
                  onClearDevice={handleClearAssetDevice}
                  hardwareDeviceType={hardwareDeviceType}
                  onChangeHardwareDeviceType={setHardwareDeviceType}
                  assetType={assetType}
                  onChangeAssetType={setAssetType}
                  serialOrBarcode={serialOrBarcode}
                  onChangeSerialOrBarcode={setSerialOrBarcode}
                  physicalLocation={physicalLocation}
                  onChangePhysicalLocation={setPhysicalLocation}
                />
              )}

              {/* SPECIFIC FIELDS: SYSTEMS TROUBLESHOOT */}
              {selectedType === 'Systems Troubleshoot' && (
                <div className="p-4 bg-blue-50/60 border border-blue-200 rounded-xl space-y-3">
                  <label className="block text-xs font-bold text-blue-950">
                    {language === 'ar' ? 'النظام المؤسسي المتأثر' : 'Affected Enterprise System'} <span className="text-rose-500">*</span>
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {SUPPORTED_SYSTEMS.map((sys) => (
                      <button
                        key={sys}
                        type="button"
                        onClick={() => setTargetSystem(sys)}
                        className={`py-2 px-2.5 rounded-lg text-xs font-semibold border transition text-start flex items-center justify-between cursor-pointer ${
                          targetSystem === sys
                            ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <span className="truncate">{getSystemLabel(sys)}</span>
                        {targetSystem === sys && <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />}
                      </button>
                    ))}
                  </div>

                  {targetSystem === 'Other System' && (
                    <input
                      type="text"
                      required
                      value={customSystemName}
                      onChange={(e) => setCustomSystemName(e.target.value)}
                      placeholder={language === 'ar' ? 'أدخل اسم النظام...' : 'Specify system name...'}
                      className="w-full mt-2 px-3 py-2 border border-slate-300 rounded-lg text-xs text-slate-900 bg-white focus:ring-2 focus:ring-blue-500"
                    />
                  )}

                  <div className="pt-2">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {language === 'ar' ? 'نوع العطل أو المشكلة' : 'Issue Category'}
                    </label>
                    <select
                      value={systemIssueCategory}
                      onChange={(e) => setSystemIssueCategory(e.target.value)}
                      className="w-full sm:w-1/2 px-3 py-1.5 border border-slate-300 rounded-lg text-xs text-slate-900 bg-white focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Error / Crash">{language === 'ar' ? 'خطأ في النظام أو توقف مفاجئ (Crash)' : 'Error / Crash'}</option>
                      <option value="Slow Performance">{language === 'ar' ? 'بطء حاد وتأخر الاستجابة (Performance)' : 'Slow Performance'}</option>
                      <option value="Data Sync Issue">{language === 'ar' ? 'فشل مزامنة البيانات (Data Sync)' : 'Data Sync Issue'}</option>
                      <option value="Authentication / 2FA">{language === 'ar' ? 'مشكلة تسجيل دخول / مصادقة 2FA' : 'Authentication / 2FA'}</option>
                      <option value="Other Issue">{language === 'ar' ? 'مشكلة تقنية أخرى' : 'Other Issue'}</option>
                    </select>
                  </div>
                </div>
              )}

              {/* SPECIFIC FIELDS: USER REQUEST */}
              {selectedType === 'User Request' && (
                <div className="p-4 bg-emerald-50/50 border border-emerald-200 rounded-xl space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-emerald-950 mb-2">
                      {language === 'ar' ? 'نوع الإجراء المطلوب' : 'Specific Action'} <span className="text-rose-500">*</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {USER_REQUEST_ACTIONS.map((action) => (
                        <button
                          key={action}
                          type="button"
                          onClick={() => setUserRequestAction(action)}
                          className={`py-1.5 px-2.5 rounded-lg text-xs font-semibold border transition text-start cursor-pointer ${
                            userRequestAction === action
                              ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-emerald-100/50'
                          }`}
                        >
                          {getUserActionLabel(action)}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {language === 'ar' ? 'النظام المؤسسي المعني' : 'Target System'} <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={targetSystem}
                      onChange={(e) => setTargetSystem(e.target.value as SupportedInformationSystem)}
                      className="w-full sm:w-1/2 px-3 py-1.5 border border-slate-300 rounded-lg text-xs text-slate-900 bg-white focus:ring-2 focus:ring-emerald-500"
                    >
                      {SUPPORTED_SYSTEMS.map((sys) => (
                        <option key={sys} value={sys}>{getSystemLabel(sys)}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        {language === 'ar' ? 'اسم الموظف المستهدف بالطلب' : 'Target Employee Full Name'} <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={targetFullName}
                        onChange={(e) => setTargetFullName(e.target.value)}
                        placeholder={language === 'ar' ? 'مثال: أحمد عبد الله الهاشمي' : 'e.g. Markus Althaus'}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs text-slate-900 bg-white focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        {language === 'ar' ? 'اسم المستخدم / الرقم الوظيفي' : 'Target Username / Employee ID'}
                      </label>
                      <input
                        type="text"
                        value={targetUsername}
                        onChange={(e) => setTargetUsername(e.target.value)}
                        placeholder="EMP-9082"
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs text-slate-900 bg-white focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        {language === 'ar' ? 'الصلاحيات أو الدور المطلوب' : 'Requested Role or Permissions'}
                      </label>
                      <input
                        type="text"
                        value={roleOrPermissions}
                        onChange={(e) => setRoleOrPermissions(e.target.value)}
                        placeholder={language === 'ar' ? 'مثال: مشرف مستودع، صلاحيات اعتماد الجرد' : 'e.g. Operations Supervisor, Inventory Approver Rights'}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs text-slate-900 bg-white focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        {language === 'ar' ? 'المبرر الإداري للطلب' : 'Business Justification'}
                      </label>
                      <input
                        type="text"
                        value={businessJustification}
                        onChange={(e) => setBusinessJustification(e.target.value)}
                        placeholder={language === 'ar' ? 'مثال: انضمام موظف جديد ومعتمد رسمياً' : 'e.g. Approved team expansion'}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs text-slate-900 bg-white focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Title */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'ar' ? 'عنوان البلاغ / موضوع التذكرة' : 'Ticket Title / Subject'} <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder={language === 'ar' ? 'لخص المشكلة أو الطلب بدقة وإيجاز...' : 'Summarize the issue or request clearly...'}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              {/* Description with Word Editor */}
              <div>
                <WordEditor
                  value={descriptionHtml}
                  onChange={setDescriptionHtml}
                  label={language === 'ar' ? 'الوصف التفصيلي والخطوات (Word Editor)' : 'Detailed Description & Steps (Word Editor)'}
                  placeholder={language === 'ar' ? 'أدخل تفاصيل المشكلة، رسائل الخطأ، والخطوات التوضيحية...' : 'Type full details, error logs, user steps, or context...'}
                  minHeight="130px"
                />
              </div>

              {/* 3 Yellow Stars Priority Selector with SLA indicator */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <StarPrioritySelector
                  stars={priorityStars}
                  onChange={(stars) => setPriorityStars(stars)}
                />
              </div>

              {/* Attachments: strictly JPEG/PNG, up to 3 */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <PictureAttachmentsUploader
                  attachments={attachments}
                  onChange={setAttachments}
                  maxFiles={systemSettings?.maxPictureAttachments ?? 3}
                  maxSizeBytes={systemSettings?.maxAttachmentSizeBytes ?? 5 * 1024 * 1024}
                  uploaderName={currentUser?.fullName || 'Operational User'}
                />
              </div>

              {/* Optional initial comment */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'ar' ? 'ملاحظة أولية للفريق الفني المختص (اختياري)' : 'Initial Comment / Notes to Assigned Team (Optional)'}
                </label>
                <input
                  type="text"
                  value={initialComment}
                  onChange={(e) => setInitialComment(e.target.value)}
                  placeholder={language === 'ar' ? 'مثال: قطع الغيار متوفرة بالخزانة B في حال إرسال فني...' : 'e.g. Spare parts are stored in Cabinet B if technician is dispatched...'}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

            </div>
          )}

          {/* ============================================================ */}
          {/* STEP 3: MANDATORY DEPARTMENT REQUEST ATTACHMENT (PDF)        */}
          {/* ============================================================ */}
          {currentStep === 3 && (
            <div className="space-y-5 text-xs sm:text-sm animate-in fade-in">
              <div className="p-4 bg-rose-50/70 border border-rose-200 rounded-xl flex items-start space-x-3">
                <FileText className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-rose-900">
                    {language === 'ar' ? 'المرفق الإلزامي: كتاب / طلب القسم المعتمد (PDF)' : 'Mandatory Department Request Document (PDF)'}
                  </h4>
                  <p className="text-xs text-rose-700 mt-1 leading-relaxed">
                    {language === 'ar'
                      ? 'وفقاً لتعليمات وسياسات المؤسسة، يلزم إرفاق نسخة معتمدة وموقعة من طلب القسم بصيغة PDF لكل تذكرة يتم رفعها.'
                      : 'According to organization compliance rules, every ticket requires an authorized Department Request document attached strictly as a PDF file.'}
                  </p>
                </div>
              </div>

              {/* Request Metadata Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center space-x-1">
                    <Hash className="w-3.5 h-3.5 text-blue-600 mx-1" />
                    <span>{language === 'ar' ? 'رقم طلب / كتاب القسم' : 'Department Request Document Number'}</span>
                    <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={deptRequestNumber}
                    onChange={(e) => {
                      setDeptRequestNumber(e.target.value);
                      if (deptRequestDoc) {
                        setDeptRequestDoc({ ...deptRequestDoc, requestNumber: e.target.value });
                      }
                    }}
                    placeholder="DEP-REQ-2026-088"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-800 bg-white focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center space-x-1">
                    <Calendar className="w-3.5 h-3.5 text-blue-600 mx-1" />
                    <span>{language === 'ar' ? 'تاريخ اعتماد الطلب' : 'Request Authorization Date'}</span>
                    <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={deptRequestDate}
                    onChange={(e) => {
                      setDeptRequestDate(e.target.value);
                      if (deptRequestDoc) {
                        setDeptRequestDoc({ ...deptRequestDoc, requestDate: e.target.value });
                      }
                    }}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs text-slate-800 bg-white focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* PDF Document Upload Dropzone */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700">
                  {language === 'ar' ? 'إرفاق ملف طلب القسم (PDF)' : 'Attach Department Request (PDF)'}
                </label>
                <div className="border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-xl p-6 text-center bg-slate-50/50 hover:bg-slate-50 transition cursor-pointer">
                  <input
                    type="file"
                    id="pdf-upload-input"
                    accept="application/pdf,.pdf"
                    onChange={handlePdfFileChange}
                    className="hidden"
                  />
                  <label htmlFor="pdf-upload-input" className="cursor-pointer block space-y-2">
                    <div className="w-12 h-12 mx-auto rounded-full bg-rose-100 text-rose-600 flex items-center justify-center">
                      <FileText className="w-6 h-6" />
                    </div>
                    <p className="text-xs font-bold text-slate-800">
                      {language === 'ar' ? 'اضغط لاختيار ملف طلب القسم (PDF فقط)' : 'Click to select Department Request PDF (.pdf only)'}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      {language === 'ar' ? 'يُقبل مستند PDF بحجم أقصى 10 ميجابايت' : 'Strictly PDF document up to 10 MB'}
                    </p>
                  </label>
                </div>
              </div>

              {/* PDF Error Display */}
              {pdfUploadError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-start space-x-2 animate-in fade-in">
                  <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{pdfUploadError}</span>
                </div>
              )}

              {/* Attached PDF Preview Card */}
              {deptRequestDoc && (
                <div className="p-4 bg-emerald-50 border-2 border-emerald-300 rounded-xl flex items-center justify-between animate-in fade-in shadow-xs">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-lg bg-rose-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                      PDF
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-bold text-slate-900 mx-1">{deptRequestDoc.fileName}</span>
                        <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 mx-0.5 text-emerald-600" />
                          {language === 'ar' ? 'معتمد وموثق' : 'Verified'}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5 flex items-center space-x-2">
                        <span>{language === 'ar' ? 'رقم الطلب:' : 'Req #:'} <strong>{deptRequestDoc.requestNumber}</strong></span>
                        <span>•</span>
                        <span>{deptRequestDoc.fileSize}</span>
                        <span>•</span>
                        <span>{deptRequestDoc.source}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setDeptRequestDoc(null)}
                    className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-100 transition"
                    title={language === 'ar' ? 'إزالة المستند' : 'Remove document'}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}

            </div>
          )}

          {/* ============================================================ */}
          {/* STEP 4: CONFIRMATION VIEW                                    */}
          {/* ============================================================ */}
          {currentStep === 4 && selectedType && deptRequestDoc && (
            <div className="space-y-5 animate-in fade-in text-xs sm:text-sm">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase tracking-wider font-bold text-blue-700">
                    {language === 'ar' ? 'الخطوة 4: مراجعة واعتماد بيانات التذكرة' : 'Step 4: Ticket Confirmation Review'}
                  </span>
                  <h3 className="text-base font-bold text-slate-900 mt-0.5">
                    {title}
                  </h3>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-blue-600 text-white font-bold text-xs font-mono shadow-xs">
                  {nextTicketNumber}
                </span>
              </div>

              {/* Summary Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Card 1: Routing & SLA */}
                <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
                  <div className="text-xs font-bold text-slate-800 border-b border-slate-200 pb-1.5 flex items-center justify-between">
                    <span>{language === 'ar' ? 'فريق الدعم واتفاقية الخدمة SLA' : 'Support Team & SLA Target'}</span>
                    <span className="text-amber-500 font-bold">
                      {'★'.repeat(priorityStars)}{'☆'.repeat(3 - priorityStars)} ({ticketPriority})
                    </span>
                  </div>
                  <div className="text-xs space-y-1">
                    <div className="flex justify-between">
                      <span className="text-slate-500">{language === 'ar' ? 'نوع البلاغ:' : 'Ticket Type:'}</span>
                      <strong className="text-slate-800">{getTicketTypeTitle(selectedType)}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">{language === 'ar' ? 'الفريق الفني المسند:' : 'Assigned Team:'}</span>
                      <strong className="text-blue-800">{getTeamName(selectedType)}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">{language === 'ar' ? 'مهلة الاستجابة:' : 'Response SLA:'}</span>
                      <strong className="text-slate-800">{sla.response / 60} {language === 'ar' ? 'ساعة' : 'hour(s)'}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">{language === 'ar' ? 'مهلة المعالجة والإغلاق:' : 'Resolution SLA:'}</span>
                      <strong className="text-slate-800">{sla.resolution / 60} {language === 'ar' ? 'ساعة' : 'hours'}</strong>
                    </div>
                  </div>
                </div>

                {/* Card 2: Requester & Dept Request */}
                <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
                  <div className="text-xs font-bold text-slate-800 border-b border-slate-200 pb-1.5 flex items-center justify-between">
                    <span>{language === 'ar' ? 'مقدم البلاغ وطلب القسم' : 'Requester & Dept Request'}</span>
                    <span className="text-emerald-700 font-bold">{currentUser.department}</span>
                  </div>
                  <div className="text-xs space-y-1">
                    <div className="flex justify-between">
                      <span className="text-slate-500">{language === 'ar' ? 'اسم المستخدم:' : 'User Name:'}</span>
                      <strong className="text-slate-800">{currentUser.fullName}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">{language === 'ar' ? 'كتاب القسم المعتمد:' : 'Dept Request #:'}</span>
                      <strong className="text-slate-800 font-mono">{deptRequestDoc.requestNumber}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">{language === 'ar' ? 'ملف الـ PDF المرفق:' : 'PDF Document:'}</span>
                      <span className="text-rose-700 font-bold flex items-center">
                        <FileText className="w-3.5 h-3.5 mx-1" />
                        {deptRequestDoc.fileName}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">{language === 'ar' ? 'تاريخ الاعتماد:' : 'Authorized Date:'}</span>
                      <span className="text-slate-700">{deptRequestDoc.requestDate}</span>
                    </div>
                  </div>
                </div>

              </div>

              {/* Specific Details Review */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2">
                <div className="text-xs font-bold text-slate-800 border-b border-slate-100 pb-1.5">
                  {language === 'ar' ? 'التفاصيل النوعية للبلاغ' : 'Specific Parameters'}
                </div>

                {selectedType === 'Hardware Maintenance' && (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                    <div>
                      <span className="text-slate-400 block">{language === 'ar' ? 'نوع الجهاز' : 'Device'}</span>
                      <strong className="text-slate-800">{getHardwareLabel(hardwareDeviceType)}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">{language === 'ar' ? 'الموديل / الأصل' : 'Model / Tag'}</span>
                      <strong className="text-slate-800">{assetType || 'N/A'}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">{language === 'ar' ? 'رمز الأصل / السيريال' : 'Asset Code / S/N'}</span>
                      <strong className="text-slate-800 font-mono">{selectedDevice?.deviceCode || serialOrBarcode || 'N/A'}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">{language === 'ar' ? 'الموقع الفعلي' : 'Location'}</span>
                      <strong className="text-slate-800">{physicalLocation}</strong>
                    </div>
                  </div>
                )}

                {selectedType === 'Systems Troubleshoot' && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                    <div>
                      <span className="text-slate-400 block">{language === 'ar' ? 'النظام المتأثر' : 'System'}</span>
                      <strong className="text-slate-800">{getSystemLabel(targetSystem)}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">{language === 'ar' ? 'نوع المشكلة' : 'Issue Category'}</span>
                      <strong className="text-slate-800">{systemIssueCategory}</strong>
                    </div>
                  </div>
                )}

                {selectedType === 'User Request' && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                    <div>
                      <span className="text-slate-400 block">{language === 'ar' ? 'نوع الإجراء' : 'Action'}</span>
                      <strong className="text-slate-800">{getUserActionLabel(userRequestAction)}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">{language === 'ar' ? 'النظام المعني' : 'System'}</span>
                      <strong className="text-slate-800">{getSystemLabel(targetSystem)}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">{language === 'ar' ? 'اسم الموظف' : 'Target User'}</span>
                      <strong className="text-slate-800">{targetFullName}</strong>
                    </div>
                  </div>
                )}
              </div>

              {/* Description Preview */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2">
                <div className="text-xs font-bold text-slate-800 border-b border-slate-100 pb-1.5">
                  {language === 'ar' ? 'نص الوصف والخطوات (Word Editor)' : 'Description Content'}
                </div>
                <div 
                  className="prose prose-xs max-w-none text-slate-700 bg-slate-50 p-3 rounded-lg max-h-32 overflow-y-auto"
                  dangerouslySetInnerHTML={{ __html: descriptionHtml || `<p>${title}</p>` }}
                />
              </div>

              {/* Attachments preview summary */}
              {attachments.length > 0 && (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                  <div className="text-xs font-bold text-slate-700">
                    {language === 'ar' ? `المرفقات المصورة المرفقة (${attachments.length} صور JPEG/PNG)` : `Attached Pictures (${attachments.length} JPEG/PNG)`}
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {attachments.map((att) => (
                      <div key={att.id} className="relative aspect-4/3 rounded-lg overflow-hidden border border-slate-300 bg-slate-900">
                        {att.dataUrl && <img src={att.dataUrl} alt={att.fileName} className="w-full h-full object-cover" />}
                        <div className="absolute bottom-0 inset-x-0 bg-black/70 px-1.5 py-0.5 text-[9px] text-white truncate">
                          {att.fileName}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          )}

        </div>

        {/* Modal Footer Controls */}
        <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200 rounded-lg transition cursor-pointer"
          >
            {language === 'ar' ? 'إلغاء' : 'Cancel'}
          </button>

          <div className="flex items-center space-x-2">
            {currentStep === 2 && (
              <button
                type="button"
                onClick={handleNextFromStep2}
                className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm transition flex items-center space-x-2 cursor-pointer"
              >
                <span>{language === 'ar' ? 'التالي: إرفاق طلب القسم (PDF)' : 'Next: Dept Request (PDF)'}</span>
                {dir === 'rtl' ? <ArrowLeft className="w-3.5 h-3.5 mx-1" /> : <ArrowRight className="w-3.5 h-3.5 mx-1" />}
              </button>
            )}

            {currentStep === 3 && (
              <button
                type="button"
                onClick={handleNextFromStep3}
                className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm transition flex items-center space-x-2 cursor-pointer"
              >
                <span>{language === 'ar' ? 'التالي: مراجعة واعتماد التذكرة' : 'Next: Review & Confirm'}</span>
                {dir === 'rtl' ? <ArrowLeft className="w-3.5 h-3.5 mx-1" /> : <ArrowRight className="w-3.5 h-3.5 mx-1" />}
              </button>
            )}

            {currentStep === 4 && (
              <button
                type="button"
                onClick={handleFinalSubmit}
                className="px-6 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm transition flex items-center space-x-2 cursor-pointer"
              >
                <FileCheck className="w-4 h-4 mx-1" />
                <span>
                  {language === 'ar' ? `اعتماد وإرسال التذكرة (${nextTicketNumber})` : `Confirm & Submit Ticket (${nextTicketNumber})`}
                </span>
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
