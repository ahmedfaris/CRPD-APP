import { useTickets } from '../context/TicketContext';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { Ticket } from '../types';
import { 
  BarChart3, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Flame, 
  ShieldCheck, 
  Database, 
  Layers, 
  Activity, 
  Server,
  ArrowUpRight,
  PlusCircle,
  Wrench,
  Laptop,
  UserPlus,
  Star
} from 'lucide-react';

interface DashboardViewProps {
  onSelectTicket: (ticket: Ticket) => void;
  onOpenCreate?: () => void;
}

export function DashboardView({ onSelectTicket, onOpenCreate }: DashboardViewProps) {
  const { tickets, metrics } = useTickets();
  const { users, isOperationalUser } = useAuth();
  const { language, dir } = useLanguage();

  // Ticket type counts
  const typeCounts = {
    hardware: tickets.filter((t) => t.ticketType === 'Hardware Maintenance').length,
    troubleshoot: tickets.filter((t) => t.ticketType === 'Systems Troubleshoot').length,
    userRequest: tickets.filter((t) => t.ticketType === 'User Request').length,
  };

  // Priority stars counts
  const starCounts = {
    threeStar: tickets.filter((t) => (t.priorityStars || 2) === 3).length,
    twoStar: tickets.filter((t) => (t.priorityStars || 2) === 2).length,
    oneStar: tickets.filter((t) => (t.priorityStars || 2) === 1).length,
  };

  // Category counts
  const categoryCounts = tickets.reduce((acc, t) => {
    acc[t.category] = (acc[t.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Priority counts
  const priorityCounts = {
    Critical: tickets.filter((t) => t.priority === 'Critical').length,
    High: tickets.filter((t) => t.priority === 'High').length,
    Medium: tickets.filter((t) => t.priority === 'Medium').length,
    Low: tickets.filter((t) => t.priority === 'Low').length,
  };

  const criticalTickets = tickets.filter((t) => t.priority === 'Critical' && t.status !== 'Closed');

  return (
    <div className="space-y-6" dir={dir}>
      
      {/* Dashboard Action Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900">
            {language === 'ar' ? 'لوحة تحكم مكتب الخدمة والتذاكر' : 'Service Desk & Ticket Dashboard'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {language === 'ar' 
              ? 'إدارة التذاكر التشغيلية، واستكشاف أخطاء الأنظمة، وصيانة الأجهزة، وطلبات الهوية والصلاحيات (IAM)' 
              : 'Operational ticketing, system troubleshooting, hardware maintenance & IAM user requests'}
          </p>
        </div>

        {onOpenCreate && (
          <button
            id="dashboard-btn-create-ticket"
            onClick={onOpenCreate}
            className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md hover:shadow-lg transition self-start sm:self-auto cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 mx-1" />
            <span>{language === 'ar' ? 'إنشاء تذكرة جديدة' : 'Create New Ticket'}</span>
          </button>
        )}
      </div>

      {/* Ticket Classification Breakdown (3 Types) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider flex items-center">
              <Wrench className="w-3.5 h-3.5 mx-1.5 text-amber-500" />
              {language === 'ar' ? 'صيانة الأجهزة والمعدات' : 'Hardware Maintenance'}
            </span>
            <div className="text-2xl font-bold text-slate-900">{typeCounts.hardware}</div>
            <div className="text-[11px] text-slate-500">
              {language === 'ar' ? 'طابعات، ماسحات ضوئية، محطات عمل' : 'Printers, Scanners, Terminals'}
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-xs font-bold font-mono">
            {Math.round((typeCounts.hardware / (tickets.length || 1)) * 100)}%
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider flex items-center">
              <Laptop className="w-3.5 h-3.5 mx-1.5 text-blue-500" />
              {language === 'ar' ? 'استكشاف أعطال الأنظمة' : 'Systems Troubleshoot'}
            </span>
            <div className="text-2xl font-bold text-slate-900">{typeCounts.troubleshoot}</div>
            <div className="text-[11px] text-slate-500">
              {language === 'ar' ? 'نظام قديم، نظام حديث، AD، ERP' : 'Old IMS, New IMS, AD, ERP'}
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-blue-50 text-blue-800 border border-blue-200 text-xs font-bold font-mono">
            {Math.round((typeCounts.troubleshoot / (tickets.length || 1)) * 100)}%
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider flex items-center">
              <UserPlus className="w-3.5 h-3.5 mx-1.5 text-emerald-500" />
              {language === 'ar' ? 'طلبات المستخدمين (IAM)' : 'User Request (IAM)'}
            </span>
            <div className="text-2xl font-bold text-slate-900">{typeCounts.userRequest}</div>
            <div className="text-[11px] text-slate-500">
              {language === 'ar' ? 'حسابات جديدة، أدوار، صلاحيات وصول' : 'Accounts, Roles, Permissions'}
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold font-mono">
            {Math.round((typeCounts.userRequest / (tickets.length || 1)) * 100)}%
          </span>
        </div>
      </div>
      
      {/* Top Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              {language === 'ar' ? 'إجمالي البلاغات' : 'Total Tickets'}
            </span>
            <span className="p-1.5 rounded-lg bg-blue-50 text-blue-600">
              <Layers className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-slate-900">{metrics.total}</span>
            <span className="text-xs text-slate-500 mx-1">{language === 'ar' ? 'تذكرة مسجلة' : 'tickets in DB'}</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between pt-2 border-t border-slate-100">
            <span>{metrics.open + metrics.inProgress} {language === 'ar' ? 'نشطة' : 'active'}</span>
            <span className="text-emerald-600 font-semibold">{metrics.resolved + metrics.closed} {language === 'ar' ? 'محلولة ومغلقة' : 'resolved'}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              {language === 'ar' ? 'الالتزام باتفاقية SLA' : 'SLA Compliance'}
            </span>
            <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
              <CheckCircle2 className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-slate-900">{metrics.slaComplianceRate}%</span>
            <span className="text-xs text-emerald-600 font-medium mx-1">{language === 'ar' ? 'المستهدف ≥ 95%' : 'target ≥ 95%'}</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between pt-2 border-t border-slate-100">
            <span>{language === 'ar' ? 'المتجاوزة:' : 'Breaches:'} {metrics.slaBreached}</span>
            <span className="text-slate-400">{language === 'ar' ? 'الاستجابة والحل' : 'Response & Resol.'}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              {language === 'ar' ? 'الحوادث الحرجة (Sev-1)' : 'Critical Incidents'}
            </span>
            <span className="p-1.5 rounded-lg bg-rose-50 text-rose-600">
              <Flame className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-rose-600">{metrics.critical}</span>
            <span className="text-xs text-rose-500 font-medium mx-1">{language === 'ar' ? 'عاجل وحرج' : 'Sev-1 / Urgent'}</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between pt-2 border-t border-slate-100">
            <span>{language === 'ar' ? 'أولوية NOC و SOC' : 'NOC & SOC priority'}</span>
            <span className="text-rose-600 font-medium">SLA: 1h / 4h</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              {language === 'ar' ? 'متوسط وقت المعالجة' : 'Avg Resolution'}
            </span>
            <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-slate-900">
              {metrics.avgResolutionTimeHours} {language === 'ar' ? 'ساعة' : 'h'}
            </span>
            <span className="text-xs text-slate-500 mx-1">{language === 'ar' ? 'المتوسط الحسابي' : 'hours mean time'}</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between pt-2 border-t border-slate-100">
            <span>{language === 'ar' ? 'مؤشر MTTR' : 'MTTR KPI'}</span>
            <span className="text-indigo-600 font-medium">{language === 'ar' ? 'المستهدف: < 8 ساعات' : 'Target: < 8h'}</span>
          </div>
        </div>

      </div>

      {/* Charts & Distributions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Priority & Severity Distribution */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
              <BarChart3 className="w-4 h-4 text-blue-600 mx-1" />
              <span>{language === 'ar' ? 'توزيع مستويات الأولوية والخطورة' : 'Priority & Severity Breakdown'}</span>
            </h3>
            <span className="text-xs text-slate-400">{language === 'ar' ? 'مباشر من قاعدة البيانات' : 'Real-time DB query'}</span>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-rose-700 flex items-center">
                  <span className="w-2 h-2 rounded-full bg-rose-600 mx-2" />
                  {language === 'ar' ? 'حرج وعاجل (Sev-1)' : 'Critical'}
                </span>
                <span className="font-mono text-slate-600 font-bold">{priorityCounts.Critical}</span>
              </div>
              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-rose-600 rounded-full" 
                  style={{ width: `${(priorityCounts.Critical / (tickets.length || 1)) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-orange-700 flex items-center">
                  <span className="w-2 h-2 rounded-full bg-orange-500 mx-2" />
                  {language === 'ar' ? 'عالي الأولوية' : 'High'}
                </span>
                <span className="font-mono text-slate-600 font-bold">{priorityCounts.High}</span>
              </div>
              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-orange-500 rounded-full" 
                  style={{ width: `${(priorityCounts.High / (tickets.length || 1)) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-amber-700 flex items-center">
                  <span className="w-2 h-2 rounded-full bg-amber-500 mx-2" />
                  {language === 'ar' ? 'متوسط الأولوية' : 'Medium'}
                </span>
                <span className="font-mono text-slate-600 font-bold">{priorityCounts.Medium}</span>
              </div>
              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-amber-500 rounded-full" 
                  style={{ width: `${(priorityCounts.Medium / (tickets.length || 1)) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-700 flex items-center">
                  <span className="w-2 h-2 rounded-full bg-slate-400 mx-2" />
                  {language === 'ar' ? 'منخفض' : 'Low'}
                </span>
                <span className="font-mono text-slate-600 font-bold">{priorityCounts.Low}</span>
              </div>
              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-slate-400 rounded-full" 
                  style={{ width: `${(priorityCounts.Low / (tickets.length || 1)) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Categories Distribution */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
              <Layers className="w-4 h-4 text-indigo-600 mx-1" />
              <span>{language === 'ar' ? 'توزيع فئات الخدمة' : 'Service Category Allocation'}</span>
            </h3>
            <span className="text-xs text-slate-400">
              {Object.keys(categoryCounts).length} {language === 'ar' ? 'فئات نشطة' : 'categories active'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {Object.entries(categoryCounts).map(([cat, count]) => (
              <div key={cat} className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between">
                <span className="text-xs text-slate-700 font-medium truncate mx-1">{cat}</span>
                <span className="text-xs font-bold font-mono bg-white px-2 py-0.5 rounded border border-slate-200 text-blue-700">
                  {count}
                </span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Critical Active Incidents & System Health Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Critical Incidents List */}
        <div className="lg:col-span-8 bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 mx-1" />
              <span>{language === 'ar' ? 'قائمة البلاغات الحرجة والطارئة' : 'High Priority & Critical Incident Queue'}</span>
            </h3>
            <span className="text-xs text-slate-500 font-medium">
              {language === 'ar' ? 'تتطلب استجابة فورية' : 'Immediate response needed'}
            </span>
          </div>

          {criticalTickets.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
              {language === 'ar' ? 'لا توجد حوادث حرجة نشطة حالياً. جميع الأنظمة تعمل بصورة طبيعية.' : 'No active critical incidents. All systems functioning normally.'}
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {criticalTickets.map((t) => (
                <div
                  key={t.id}
                  onClick={() => onSelectTicket(t)}
                  className="py-3 px-2 flex items-center justify-between hover:bg-slate-50 rounded-lg cursor-pointer transition group"
                >
                  <div className="space-y-1 truncate pr-4">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-[11px] font-bold text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200 mx-1">
                        #{t.id}
                      </span>
                      <span className="text-xs font-semibold text-slate-800 group-hover:text-blue-600 transition truncate">
                        {t.title}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      {t.department} • {language === 'ar' ? 'مقدم البلاغ:' : 'Requester:'} {t.requesterName} • {language === 'ar' ? 'المكلف:' : 'Assignee:'} {t.assigneeName || (language === 'ar' ? 'غير مسند' : 'Unassigned')}
                    </p>
                  </div>

                  <div className="flex items-center space-x-2 shrink-0">
                    <span className="text-xs font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                      {language === 'ar' ? 'حرج' : t.status}
                    </span>
                    <ArrowUpRight className={`w-4 h-4 text-slate-400 group-hover:text-blue-600 transition ${dir === 'rtl' ? 'rotate-[-90deg]' : ''}`} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Backend & Security Infrastructure Status (CRPD APP Environment) */}
        <div className="lg:col-span-4 bg-slate-900 text-slate-100 p-5 rounded-xl border border-slate-800 shadow-md space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
            <Server className="w-4 h-4 text-emerald-400 mx-1" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              {language === 'ar' ? 'بنية نظام CRPD APP التحتية' : 'CRPD APP Architecture'}
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">{language === 'ar' ? 'قاعدة البيانات:' : 'Database Instance:'}</span>
              <span className="font-mono font-semibold text-emerald-400">TicketManagementDB</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400">{language === 'ar' ? 'خادم السجلات (Serilog):' : 'Serilog Sink:'}</span>
              <span className="font-mono font-semibold text-blue-400">Seq @ :5341 (CompactJson)</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400">{language === 'ar' ? 'تشفير كلمات المرور:' : 'Identity Hasher:'}</span>
              <span className="font-mono font-semibold text-slate-200">BCrypt (WorkFactor: 11)</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400">{language === 'ar' ? 'فلاتر الأمان والحماية:' : 'Security Filters:'}</span>
              <span className="font-mono text-xs text-amber-400">UserActivity + ForcePassword</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400">{language === 'ar' ? 'سياسة قفل الحساب:' : 'Lockout Policy:'}</span>
              <span className="font-mono text-xs text-slate-300">
                {language === 'ar' ? '6 محاولات (5 د / 10 د / 15 د)' : '6 Attempts (5m / 10m / 15m)'}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400">{language === 'ar' ? 'سياسة كلمة المرور:' : 'Password Policy:'}</span>
              <span className="font-mono text-xs text-slate-300">
                {language === 'ar' ? '12+ حرف، أرقام، رموز، أحرف كبيرة' : '12+ Chars, Dig, Up, Low, Spec'}
              </span>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span className="flex items-center">
              <span className="w-2 h-2 rounded-full bg-emerald-400 mx-1.5 animate-pulse" />
              {language === 'ar' ? 'كافة الأنظمة الفرعية تعمل بكفاءة' : 'All Subsystems Healthy'}
            </span>
            <span>Seed: admin@system.local</span>
          </div>
        </div>

      </div>

    </div>
  );
}
