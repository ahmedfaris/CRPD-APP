import React, { useState, useMemo } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useDevices } from '../context/DeviceContext';
import { useOrg } from '../context/OrgContext';
import { 
  ElectronicDevice, 
  DeviceCategory, 
  DeviceType, 
  DeviceMaintenanceItem, 
  DeviceDepartmentHistoryItem 
} from '../types';
import { 
  Laptop, 
  Printer, 
  Monitor, 
  Fingerprint, 
  Scan, 
  Wifi, 
  Network, 
  Server, 
  HardDrive, 
  Cpu, 
  Wrench, 
  ShieldCheck, 
  History, 
  Calendar, 
  Building2, 
  Tag, 
  Search, 
  Plus, 
  Filter, 
  ArrowRightLeft, 
  Download, 
  Trash2, 
  Edit3, 
  CheckCircle2, 
  AlertTriangle, 
  X, 
  ChevronRight, 
  ArrowLeft, 
  Activity, 
  Clock, 
  FileText, 
  Sparkles,
  SlidersHorizontal,
  DollarSign,
  UserCheck,
  MapPin,
  Globe,
  Radio,
  Lock,
  QrCode as QrCodeIcon
} from 'lucide-react';
import { isSameDepartment } from '../utils/departmentHelper';
import { AssetQrScannerModal } from './AssetQrScannerModal';
import { AssetQrBadgeModal } from './AssetQrBadgeModal';

interface DeviceManagementAppProps {
  onBackToMetro: () => void;
}

export function DeviceManagementApp({ onBackToMetro }: DeviceManagementAppProps) {
  const { t, language, dir } = useLanguage();
  const { currentUser, isTechnicalUser, isAdmin } = useAuth();
  const isTech = Boolean(isTechnicalUser || isAdmin);
  const userDept = currentUser?.department;
  const { devices, addDevice, updateDevice, transferDepartment, addMaintenanceRecord, deleteDevice } = useDevices();
  const { getAllDepartments } = useOrg();

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'ALL' | 'electronic' | 'network'>('ALL');
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('ALL');
  const [selectedWarrantyStatus, setSelectedWarrantyStatus] = useState<'ALL' | 'active' | 'expired'>('ALL');

  // Modals
  const [viewDeviceModal, setViewDeviceModal] = useState<ElectronicDevice | null>(null);
  const [activeDetailTab, setActiveDetailTab] = useState<'overview' | 'departments' | 'maintenance'>('overview');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingDevice, setEditingDevice] = useState<ElectronicDevice | null>(null);
  const [transferModalDevice, setTransferModalDevice] = useState<ElectronicDevice | null>(null);
  const [maintenanceModalDevice, setMaintenanceModalDevice] = useState<ElectronicDevice | null>(null);
  const [isQrScannerOpen, setIsQrScannerOpen] = useState(false);
  const [badgeModalDevice, setBadgeModalDevice] = useState<ElectronicDevice | null>(null);

  // Forms State: Create / Edit Device
  const [formCategory, setFormCategory] = useState<DeviceCategory>('electronic');
  const [formDeviceType, setFormDeviceType] = useState<DeviceType>('Computer');
  const [formBrand, setFormBrand] = useState('');
  const [formModel, setFormModel] = useState('');
  const [formSerialNumber, setFormSerialNumber] = useState('');
  const [formDateOfPurchase, setFormDateOfPurchase] = useState(new Date().toISOString().split('T')[0]);
  const [formWarrantyStartDate, setFormWarrantyStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [formWarrantyPeriod, setFormWarrantyPeriod] = useState('24 Months');
  const [formDepartment, setFormDepartment] = useState('Information Technology');
  const [formDepartmentAr, setFormDepartmentAr] = useState('');
  const [formLocation, setFormLocation] = useState('');
  const [formIpAddress, setFormIpAddress] = useState('');
  const [formMacAddress, setFormMacAddress] = useState('');
  const [formAssignedEmployee, setFormAssignedEmployee] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formStatus, setFormStatus] = useState<'Operational' | 'Under Maintenance' | 'Storage' | 'Retired'>('Operational');

  // Forms State: Transfer Department
  const [transferTargetDept, setTransferTargetDept] = useState('');
  const [transferTargetDeptAr, setTransferTargetDeptAr] = useState('');
  const [transferReason, setTransferReason] = useState('');
  const [transferDate, setTransferDate] = useState(new Date().toISOString().split('T')[0]);

  // Forms State: Add Maintenance Record
  const [maintDate, setMaintDate] = useState(new Date().toISOString().split('T')[0]);
  const [maintType, setMaintType] = useState<'Routine' | 'Repair' | 'Upgrade' | 'Inspection' | 'Replacement'>('Routine');
  const [maintDescription, setMaintDescription] = useState('');
  const [maintPerformedBy, setMaintPerformedBy] = useState(currentUser?.fullName || 'Hardware Technician');
  const [maintCost, setMaintCost] = useState('0');
  const [maintStatus, setMaintStatus] = useState<'Completed' | 'In Progress' | 'Scheduled'>('Completed');
  const [maintNotes, setMaintNotes] = useState('');

  // Department List sourced directly from Organizational Structure
  const orgDepts = getAllDepartments();
  const allDepartmentsList = useMemo(() => {
    if (orgDepts && orgDepts.length > 0) {
      return orgDepts.map(d => language === 'ar' ? (d.nameAr || d.nameEn) : d.nameEn);
    }
    return [
      language === 'ar' ? 'تكنولوجيا المعلومات' : 'Information Technology',
      language === 'ar' ? 'العمليات والتنفيذ' : 'Operations',
      language === 'ar' ? 'الأرشفة الإلكترونية والسجلات' : 'Electronic Archiving & Records',
      language === 'ar' ? 'دعم العملاء ومكتب المساعدة' : 'Customer Support & Helpdesk',
      language === 'ar' ? 'الموارد البشرية' : 'Human Resources'
    ];
  }, [orgDepts, language]);

  // Helper Icon for Device Types
  const getDeviceIcon = (type: string, category: string) => {
    const tLower = (type || '').toLowerCase();
    if (tLower.includes('computer') || tLower.includes('pc') || tLower.includes('laptop')) {
      return <Laptop className="w-5 h-5 text-blue-500" />;
    }
    if (tLower.includes('printer')) {
      return <Printer className="w-5 h-5 text-amber-500" />;
    }
    if (tLower.includes('screen') || tLower.includes('monitor')) {
      return <Monitor className="w-5 h-5 text-purple-500" />;
    }
    if (tLower.includes('fingerprint') || tLower.includes('biometric')) {
      return <Fingerprint className="w-5 h-5 text-emerald-500" />;
    }
    if (tLower.includes('scanner') || tLower.includes('scan')) {
      return <Scan className="w-5 h-5 text-cyan-500" />;
    }
    if (tLower.includes('router')) {
      return <Server className="w-5 h-5 text-indigo-500" />;
    }
    if (tLower.includes('switch')) {
      return <Network className="w-5 h-5 text-teal-500" />;
    }
    if (tLower.includes('access point') || tLower.includes('wifi') || tLower.includes('ap')) {
      return <Wifi className="w-5 h-5 text-sky-500" />;
    }
    return category === 'network' ? <Network className="w-5 h-5 text-indigo-500" /> : <HardDrive className="w-5 h-5 text-slate-500" />;
  };

  // Scope assets: allow all users to view assets with filter by selectedDepartment
  const scopedDevices = devices;

  // Filtered Devices
  const filteredDevices = useMemo(() => {
    return scopedDevices.filter(device => {
      // Category filter
      if (selectedCategory !== 'ALL' && device.category !== selectedCategory) {
        return false;
      }
      // Type filter
      if (selectedType !== 'ALL' && device.deviceType.toLowerCase() !== selectedType.toLowerCase()) {
        return false;
      }
      // Department filter (selectable for all users)
      if (selectedDepartment !== 'ALL' && !isSameDepartment(device.department, selectedDepartment) && !(device.departmentAr && isSameDepartment(device.departmentAr, selectedDepartment))) {
        return false;
      }
      // Warranty Status filter
      if (selectedWarrantyStatus === 'active' && !device.isWarrantyActive) {
        return false;
      }
      if (selectedWarrantyStatus === 'expired' && device.isWarrantyActive) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchCode = device.deviceCode.toLowerCase().includes(q);
        const matchBrand = device.brand.toLowerCase().includes(q);
        const matchModel = device.model.toLowerCase().includes(q);
        const matchType = device.deviceType.toLowerCase().includes(q);
        const matchDept = device.department.toLowerCase().includes(q) || (device.departmentAr && device.departmentAr.toLowerCase().includes(q));
        const matchSerial = device.serialNumber ? device.serialNumber.toLowerCase().includes(q) : false;
        const matchIp = device.ipAddress ? device.ipAddress.toLowerCase().includes(q) : false;
        const matchEmp = device.assignedEmployee ? device.assignedEmployee.toLowerCase().includes(q) : false;
        return matchCode || matchBrand || matchModel || matchType || matchDept || matchSerial || matchIp || matchEmp;
      }
      return true;
    });
  }, [scopedDevices, selectedCategory, selectedType, selectedDepartment, selectedWarrantyStatus, searchQuery]);

  // Metrics
  const metrics = useMemo(() => {
    const total = scopedDevices.length;
    const electronicCount = scopedDevices.filter(d => d.category === 'electronic').length;
    const networkCount = scopedDevices.filter(d => d.category === 'network').length;
    const warrantyActiveCount = scopedDevices.filter(d => d.isWarrantyActive).length;
    const maintenanceCount = scopedDevices.reduce((sum, d) => sum + (d.maintenanceHistory?.length || 0), 0);
    return { total, electronicCount, networkCount, warrantyActiveCount, maintenanceCount };
  }, [scopedDevices]);

  // Open Create Modal
  const handleOpenCreate = () => {
    setEditingDevice(null);
    setFormCategory('electronic');
    setFormDeviceType('Computer');
    setFormBrand('');
    setFormModel('');
    setFormSerialNumber('');
    setFormDateOfPurchase(new Date().toISOString().split('T')[0]);
    setFormWarrantyStartDate(new Date().toISOString().split('T')[0]);
    setFormWarrantyPeriod('24 Months');

    const defaultMatched = userDept ? orgDepts.find(d => isSameDepartment(d.nameEn, userDept) || isSameDepartment(d.nameAr, userDept)) : null;
    const defaultDept = defaultMatched || orgDepts[0];
    const initialDeptEn = defaultDept ? defaultDept.nameEn : (userDept || 'Information Technology');
    const initialDeptAr = defaultDept ? defaultDept.nameAr : '';
    setFormDepartment(initialDeptEn);
    setFormDepartmentAr(initialDeptAr);

    setFormLocation('');
    setFormIpAddress('');
    setFormMacAddress('');
    setFormAssignedEmployee('');
    setFormNotes('');
    setFormStatus('Operational');
    setIsCreateModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (dev: ElectronicDevice) => {
    setEditingDevice(dev);
    setFormCategory(dev.category);
    setFormDeviceType(dev.deviceType);
    setFormBrand(dev.brand);
    setFormModel(dev.model);
    setFormSerialNumber(dev.serialNumber || '');
    setFormDateOfPurchase(dev.dateOfPurchase);
    setFormWarrantyStartDate(dev.warrantyStartDate || dev.dateOfPurchase);
    setFormWarrantyPeriod(dev.warrantyPeriod);
    setFormDepartment(dev.department);
    setFormDepartmentAr(dev.departmentAr || '');
    setFormLocation(dev.location || '');
    setFormIpAddress(dev.ipAddress || '');
    setFormMacAddress(dev.macAddress || '');
    setFormAssignedEmployee(dev.assignedEmployee || '');
    setFormNotes(dev.notes || '');
    setFormStatus(dev.status);
    setIsCreateModalOpen(true);
  };

  // Submit Create / Edit
  const handleSubmitDevice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formBrand.trim() || !formModel.trim() || !formDepartment) return;

    if (editingDevice) {
      const matchedDept = orgDepts.find(d => 
        isSameDepartment(d.nameEn, formDepartment) || 
        isSameDepartment(d.nameAr, formDepartment)
      );
      const resolvedDeptEn = matchedDept ? matchedDept.nameEn : formDepartment;
      const resolvedDeptAr = matchedDept ? matchedDept.nameAr : (formDepartmentAr || undefined);

      await updateDevice(editingDevice.id, {
        category: formCategory,
        deviceType: formDeviceType,
        brand: formBrand.trim(),
        model: formModel.trim(),
        serialNumber: formSerialNumber.trim() || undefined,
        dateOfPurchase: formDateOfPurchase,
        warrantyStartDate: formWarrantyStartDate,
        warrantyPeriod: formWarrantyPeriod,
        department: resolvedDeptEn,
        departmentAr: resolvedDeptAr,
        location: formLocation.trim() || undefined,
        ipAddress: formIpAddress.trim() || undefined,
        macAddress: formMacAddress.trim() || undefined,
        assignedEmployee: formAssignedEmployee.trim() || undefined,
        notes: formNotes.trim() || undefined,
        status: formStatus
      });
      if (viewDeviceModal && viewDeviceModal.id === editingDevice.id) {
        setViewDeviceModal(prev => prev ? {
          ...prev,
          category: formCategory,
          deviceType: formDeviceType,
          brand: formBrand.trim(),
          model: formModel.trim(),
          serialNumber: formSerialNumber.trim() || undefined,
          dateOfPurchase: formDateOfPurchase,
          warrantyStartDate: formWarrantyStartDate,
          warrantyPeriod: formWarrantyPeriod,
          department: resolvedDeptEn,
          departmentAr: resolvedDeptAr,
          location: formLocation.trim() || undefined,
          ipAddress: formIpAddress.trim() || undefined,
          macAddress: formMacAddress.trim() || undefined,
          assignedEmployee: formAssignedEmployee.trim() || undefined,
          notes: formNotes.trim() || undefined,
          status: formStatus
        } : null);
      }
    } else {
      const effectiveDepartment = formDepartment || userDept || 'Information Technology';

      const matchedDept = orgDepts.find(d => 
        isSameDepartment(d.nameEn, effectiveDepartment) || 
        isSameDepartment(d.nameAr, effectiveDepartment)
      );
      const resolvedDeptEn = matchedDept ? matchedDept.nameEn : effectiveDepartment;
      const resolvedDeptAr = matchedDept ? matchedDept.nameAr : (formDepartmentAr || undefined);

      await addDevice({
        category: formCategory,
        deviceType: formDeviceType,
        brand: formBrand.trim(),
        model: formModel.trim(),
        serialNumber: formSerialNumber.trim() || undefined,
        dateOfPurchase: formDateOfPurchase,
        warrantyStartDate: formWarrantyStartDate,
        warrantyPeriod: formWarrantyPeriod,
        department: resolvedDeptEn,
        departmentAr: resolvedDeptAr,
        location: formLocation.trim() || undefined,
        ipAddress: formIpAddress.trim() || undefined,
        macAddress: formMacAddress.trim() || undefined,
        assignedEmployee: formAssignedEmployee.trim() || undefined,
        notes: formNotes.trim() || undefined,
        status: formStatus,
        departmentHistory: [],
        maintenanceHistory: []
      });
    }

    setIsCreateModalOpen(false);
  };

  // Open Transfer Modal
  const handleOpenTransfer = (dev: ElectronicDevice) => {
    setTransferModalDevice(dev);
    const available = orgDepts.filter(d => 
      !isSameDepartment(d.nameEn, dev.department) && 
      !isSameDepartment(d.nameAr, dev.department)
    );
    const target = available[0] || orgDepts[0];
    setTransferTargetDept(target ? target.nameEn : 'Operations');
    setTransferTargetDeptAr(target ? target.nameAr : 'العمليات والتنفيذ');
    setTransferReason('');
    setTransferDate(new Date().toISOString().split('T')[0]);
  };

  // Submit Department Transfer
  const handleSubmitTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!transferModalDevice || !transferTargetDept) return;

    const matched = orgDepts.find(d => 
      isSameDepartment(d.nameEn, transferTargetDept) || 
      isSameDepartment(d.nameAr, transferTargetDept)
    );
    const targetDeptEn = matched ? matched.nameEn : transferTargetDept;
    const targetDeptAr = matched ? matched.nameAr : (transferTargetDeptAr || transferTargetDept);

    await transferDepartment(transferModalDevice.id, targetDeptEn, transferReason, targetDeptAr);
    
    // Update active view modal if open
    if (viewDeviceModal && viewDeviceModal.id === transferModalDevice.id) {
      const historyItem: DeviceDepartmentHistoryItem = {
        id: 'dh-' + Date.now(),
        department: transferModalDevice.department,
        departmentAr: transferModalDevice.departmentAr || transferModalDevice.department,
        assignedDate: transferModalDevice.dateOfPurchase,
        transferredDate: transferDate,
        transferredBy: currentUser?.fullName || 'Current User',
        reason: transferReason || 'Departmental reorganization'
      };
      setViewDeviceModal(prev => prev ? {
        ...prev,
        department: targetDeptEn,
        departmentAr: targetDeptAr,
        departmentHistory: [...prev.departmentHistory, historyItem]
      } : null);
    }

    setTransferModalDevice(null);
  };

  // Open Maintenance Modal
  const handleOpenMaintenance = (dev: ElectronicDevice) => {
    setMaintenanceModalDevice(dev);
    setMaintDate(new Date().toISOString().split('T')[0]);
    setMaintType('Routine');
    setMaintDescription('');
    setMaintPerformedBy(currentUser?.fullName || 'Hardware Tech Team');
    setMaintCost('0');
    setMaintStatus('Completed');
    setMaintNotes('');
  };

  // Submit Maintenance Record
  const handleSubmitMaintenance = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!maintenanceModalDevice || !maintDescription.trim()) return;

    const newRecord: Omit<DeviceMaintenanceItem, 'id'> = {
      date: maintDate,
      type: maintType,
      description: maintDescription.trim(),
      performedBy: maintPerformedBy.trim(),
      cost: parseFloat(maintCost) || 0,
      status: maintStatus,
      notes: maintNotes.trim() || undefined
    };

    await addMaintenanceRecord(maintenanceModalDevice.id, newRecord);

    if (viewDeviceModal && viewDeviceModal.id === maintenanceModalDevice.id) {
      setViewDeviceModal(prev => prev ? {
        ...prev,
        maintenanceHistory: [...prev.maintenanceHistory, { ...newRecord, id: 'mh-' + Date.now() }]
      } : null);
    }

    setMaintenanceModalDevice(null);
  };

  // Handle Delete
  const handleDelete = async (dev: ElectronicDevice) => {
    const confirmMsg = language === 'ar' 
      ? `هل أنت متأكد من حذف الجهاز ${dev.deviceCode} (${dev.brand} ${dev.model})؟` 
      : `Are you sure you want to delete device ${dev.deviceCode} (${dev.brand} ${dev.model})?`;
    if (window.confirm(confirmMsg)) {
      await deleteDevice(dev.id);
      if (viewDeviceModal?.id === dev.id) {
        setViewDeviceModal(null);
      }
    }
  };

  // Export inventory to CSV
  const handleExportCSV = () => {
    const headers = [
      'Device Code',
      'Category',
      'Device Type',
      'Brand',
      'Model',
      'Serial Number',
      'Current Department',
      'Date of Purchase',
      'Warranty Start Date',
      'Warranty Period',
      'Warranty Expiration',
      'Warranty Active',
      'Status',
      'IP Address',
      'MAC Address',
      'Location',
      'Assigned Employee',
      'Department History Count',
      'Maintenance History Count'
    ];

    const rows = filteredDevices.map(d => [
      `"${d.deviceCode}"`,
      `"${d.category}"`,
      `"${d.deviceType}"`,
      `"${d.brand}"`,
      `"${d.model}"`,
      `"${d.serialNumber || ''}"`,
      `"${d.department}"`,
      `"${d.dateOfPurchase}"`,
      `"${d.warrantyStartDate}"`,
      `"${d.warrantyPeriod}"`,
      `"${d.warrantyExpiryDate || ''}"`,
      `"${d.isWarrantyActive ? 'Yes' : 'No'}"`,
      `"${d.status}"`,
      `"${d.ipAddress || ''}"`,
      `"${d.macAddress || ''}"`,
      `"${d.location || ''}"`,
      `"${d.assignedEmployee || ''}"`,
      d.departmentHistory?.length || 0,
      d.maintenanceHistory?.length || 0
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `assets_inventory_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-900 text-slate-100 p-4 sm:p-6 lg:p-8 font-sans selection:bg-blue-600 selection:text-white" dir={dir}>
      <div className="max-w-7xl mx-auto space-y-6">

        {/* Top Header Ribbon & Back to Metro */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-800/80 backdrop-blur-md p-5 rounded-2xl border border-slate-700/80 shadow-xl">
          <div className="flex items-center space-x-3.5">
            <button
              onClick={onBackToMetro}
              className="p-2.5 rounded-xl bg-slate-700/80 hover:bg-slate-700 text-slate-300 hover:text-white transition border border-slate-600/60 shadow-xs cursor-pointer"
              title={language === 'ar' ? 'العودة إلى مركز مترو' : 'Back to Metro Hub'}
            >
              <ArrowLeft className={`w-5 h-5 mx-0.5 ${dir === 'rtl' ? 'rotate-180' : ''}`} />
            </button>
            <div>
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/20">
                  <Laptop className="w-5 h-5" />
                </div>
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                  {language === 'ar' ? 'إدارة الأصول' : 'Asset Management'}
                </h1>
                <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  {metrics.total} {language === 'ar' ? 'أصل' : 'Assets'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1 max-w-2xl">
                {language === 'ar'
                  ? 'تسجيل وجرد ومتابعة الأصول والعهد التقنية (الحواسيب، الطابعات، الشاشات، أجهزة البصمة، والماسحات الضوئية) بالإضافة لأجهزة الشبكات (الراوترات، السويتشات، ونقاط الوصول) وتتبع فترات الضمان وسجل الصيانة وسجل انتقال الأقسام.'
                  : 'Register, track, and manage organization assets (computers, printers, screens, biometrics, scanners) and network gear with warranty monitoring, maintenance history, and department transfer logs.'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2.5">
            <button
              onClick={() => setIsQrScannerOpen(true)}
              className="flex items-center space-x-2 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/25 transition cursor-pointer"
              title={language === 'ar' ? 'فحص رمز الاستجابة السريعة (QR) للأصل عبر كاميرا الجهاز' : 'Scan physical asset QR code using camera'}
            >
              <QrCodeIcon className="w-4 h-4 mx-1" />
              <span>{language === 'ar' ? 'مسح رمز QR للأصل' : 'Scan Asset QR'}</span>
            </button>

            <button
              onClick={handleExportCSV}
              className="flex items-center space-x-2 px-3.5 py-2.5 rounded-xl bg-slate-700/80 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-600/70 transition shadow-xs cursor-pointer"
              title={language === 'ar' ? 'تصدير جدول جرد الأصول إلى CSV' : 'Export Asset Inventory to CSV'}
            >
              <Download className="w-4 h-4 text-cyan-400 mx-1" />
              <span>{language === 'ar' ? 'تصدير جرد الأصول' : 'Export Assets CSV'}</span>
            </button>

            <button
              onClick={handleOpenCreate}
              className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-xs font-bold shadow-lg shadow-blue-500/20 transition cursor-pointer"
            >
              <Plus className="w-4 h-4 mx-1" />
              <span>{language === 'ar' ? 'إدخال أصل جديد' : 'Register New Asset'}</span>
            </button>
          </div>
        </div>

        {/* METRICS STATS CARDS */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
          <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400">
                {language === 'ar' ? 'إجمالي الأصول' : 'Total Assets'}
              </span>
              <HardDrive className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-2xl font-black text-white mt-2">{metrics.total}</div>
            <div className="text-[11px] text-slate-400 mt-1">
              {language === 'ar' ? 'أصول تقنية مسجلة' : 'Registered IT Assets'}
            </div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400">
                {language === 'ar' ? 'أجهزة إلكترونية' : 'Electronic Devices'}
              </span>
              <Laptop className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-2xl font-black text-cyan-400 mt-2">{metrics.electronicCount}</div>
            <div className="text-[11px] text-slate-400 mt-1">
              {language === 'ar' ? 'حواسيب، طابعات، شاشات، بصمة، سكانر' : 'PC, Printer, Screen, Biometric, Scan'}
            </div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400">
                {language === 'ar' ? 'أجهزة شبكية' : 'Network Devices'}
              </span>
              <Network className="w-4 h-4 text-teal-400" />
            </div>
            <div className="text-2xl font-black text-teal-400 mt-2">{metrics.networkCount}</div>
            <div className="text-[11px] text-slate-400 mt-1">
              {language === 'ar' ? 'راوتر، سويتش، أكسس بوينت' : 'Routers, Switches, APs'}
            </div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400">
                {language === 'ar' ? 'تحت الضمان الساري' : 'Under Active Warranty'}
              </span>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-black text-emerald-400 mt-2">{metrics.warrantyActiveCount}</div>
            <div className="text-[11px] text-slate-400 mt-1">
              {metrics.total > 0 ? `${Math.round((metrics.warrantyActiveCount / metrics.total) * 100)}%` : '0%'} {language === 'ar' ? 'ساري المفعول' : 'Coverage Rate'}
            </div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60 col-span-2 sm:col-span-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400">
                {language === 'ar' ? 'سجلات الصيانة' : 'Maintenance Records'}
              </span>
              <Wrench className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-black text-amber-400 mt-2">{metrics.maintenanceCount}</div>
            <div className="text-[11px] text-slate-400 mt-1">
              {language === 'ar' ? 'عمليات دورية وإصلاح' : 'Logged service events'}
            </div>
          </div>
        </div>

        {/* SEARCH & FILTERS BAR */}
        <div className="bg-slate-800/90 p-4 sm:p-5 rounded-2xl border border-slate-700/80 space-y-4 shadow-lg">
          {/* Row 1: Search Box & Category Tabs */}
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
            
            {/* Search Input */}
            <div className="flex items-center gap-2 flex-1">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={language === 'ar' 
                    ? 'بحث برمز الجهاز، الموديل، الماركة، الرقم التسلسلي، القسم، عنوان IP...' 
                    : 'Search by Device Code, Brand, Model, Serial No, Department, IP...'}
                  className="w-full bg-slate-900/90 border border-slate-700 rounded-xl pl-10 pr-10 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-hidden focus:border-cyan-500 transition"
                />
                {searchQuery ? (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setIsQrScannerOpen(true)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-emerald-400 transition"
                    title={language === 'ar' ? 'مسح رمز QR بالكاميرا' : 'Scan QR with Camera'}
                  >
                    <QrCodeIcon className="w-4 h-4" />
                  </button>
                )}
              </div>

              <button
                type="button"
                onClick={() => setIsQrScannerOpen(true)}
                className="hidden sm:flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-700/80 border border-slate-700 text-slate-300 hover:text-emerald-300 text-xs font-semibold transition cursor-pointer shrink-0"
                title={language === 'ar' ? 'فاحص رمز الاستجابة السريعة (QR) عبر الكاميرا' : 'QR Camera Scanner'}
              >
                <QrCodeIcon className="w-4 h-4 text-emerald-400" />
                <span>{language === 'ar' ? 'مسح QR' : 'Scan QR'}</span>
              </button>
            </div>

            {/* Category Segmented Buttons */}
            <div className="flex items-center bg-slate-900/90 p-1 rounded-xl border border-slate-700 self-start lg:self-auto">
              <button
                onClick={() => { setSelectedCategory('ALL'); setSelectedType('ALL'); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  selectedCategory === 'ALL'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {language === 'ar' ? 'كافة الأصول' : 'All Assets'} ({devices.length})
              </button>
              <button
                onClick={() => { setSelectedCategory('electronic'); setSelectedType('ALL'); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer ${
                  selectedCategory === 'electronic'
                    ? 'bg-cyan-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Laptop className="w-3.5 h-3.5 mx-1" />
                <span>{language === 'ar' ? 'أجهزة إلكترونية' : 'Electronic'} ({metrics.electronicCount})</span>
              </button>
              <button
                onClick={() => { setSelectedCategory('network'); setSelectedType('ALL'); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer ${
                  selectedCategory === 'network'
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Network className="w-3.5 h-3.5 mx-1" />
                <span>{language === 'ar' ? 'أجهزة شبكية' : 'Network'} ({metrics.networkCount})</span>
              </button>
            </div>
          </div>

          {/* Row 2: Type Filter Chips & Dropdowns */}
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-700/60">
            <span className="text-[11px] font-bold text-slate-400 flex items-center space-x-1">
              <SlidersHorizontal className="w-3.5 h-3.5 mx-1" />
              <span>{language === 'ar' ? 'النوع:' : 'Type:'}</span>
            </span>

            {/* Electronic Types */}
            {selectedCategory !== 'network' && (
              <>
                <button
                  onClick={() => setSelectedType(selectedType === 'Computer' ? 'ALL' : 'Computer')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition cursor-pointer flex items-center space-x-1 ${
                    selectedType === 'Computer'
                      ? 'bg-blue-600/30 text-blue-300 border-blue-500'
                      : 'bg-slate-900/60 text-slate-400 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <Laptop className="w-3 h-3 mx-1" />
                  <span>{language === 'ar' ? 'حاسوب' : 'Computer'}</span>
                </button>
                <button
                  onClick={() => setSelectedType(selectedType === 'Printer' ? 'ALL' : 'Printer')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition cursor-pointer flex items-center space-x-1 ${
                    selectedType === 'Printer'
                      ? 'bg-amber-600/30 text-amber-300 border-amber-500'
                      : 'bg-slate-900/60 text-slate-400 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <Printer className="w-3 h-3 mx-1" />
                  <span>{language === 'ar' ? 'طابعة' : 'Printer'}</span>
                </button>
                <button
                  onClick={() => setSelectedType(selectedType === 'Screen' ? 'ALL' : 'Screen')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition cursor-pointer flex items-center space-x-1 ${
                    selectedType === 'Screen'
                      ? 'bg-purple-600/30 text-purple-300 border-purple-500'
                      : 'bg-slate-900/60 text-slate-400 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <Monitor className="w-3 h-3 mx-1" />
                  <span>{language === 'ar' ? 'شاشة' : 'Screen'}</span>
                </button>
                <button
                  onClick={() => setSelectedType(selectedType === 'Fingerprint device' ? 'ALL' : 'Fingerprint device')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition cursor-pointer flex items-center space-x-1 ${
                    selectedType === 'Fingerprint device'
                      ? 'bg-emerald-600/30 text-emerald-300 border-emerald-500'
                      : 'bg-slate-900/60 text-slate-400 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <Fingerprint className="w-3 h-3 mx-1" />
                  <span>{language === 'ar' ? 'جهاز بصمة' : 'Fingerprint Device'}</span>
                </button>
                <button
                  onClick={() => setSelectedType(selectedType === 'Scanner' ? 'ALL' : 'Scanner')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition cursor-pointer flex items-center space-x-1 ${
                    selectedType === 'Scanner'
                      ? 'bg-cyan-600/30 text-cyan-300 border-cyan-500'
                      : 'bg-slate-900/60 text-slate-400 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <Scan className="w-3 h-3 mx-1" />
                  <span>{language === 'ar' ? 'ماسح ضوئي' : 'Scanner'}</span>
                </button>
              </>
            )}

            {/* Network Types */}
            {selectedCategory !== 'electronic' && (
              <>
                <button
                  onClick={() => setSelectedType(selectedType === 'router' ? 'ALL' : 'router')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition cursor-pointer flex items-center space-x-1 ${
                    selectedType === 'router'
                      ? 'bg-indigo-600/30 text-indigo-300 border-indigo-500'
                      : 'bg-slate-900/60 text-slate-400 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <Server className="w-3 h-3 mx-1" />
                  <span>{language === 'ar' ? 'راوتر' : 'Router'}</span>
                </button>
                <button
                  onClick={() => setSelectedType(selectedType === 'switch' ? 'ALL' : 'switch')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition cursor-pointer flex items-center space-x-1 ${
                    selectedType === 'switch'
                      ? 'bg-teal-600/30 text-teal-300 border-teal-500'
                      : 'bg-slate-900/60 text-slate-400 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <Network className="w-3 h-3 mx-1" />
                  <span>{language === 'ar' ? 'سويتش' : 'Switch'}</span>
                </button>
                <button
                  onClick={() => setSelectedType(selectedType === 'access point' ? 'ALL' : 'access point')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition cursor-pointer flex items-center space-x-1 ${
                    selectedType === 'access point'
                      ? 'bg-sky-600/30 text-sky-300 border-sky-500'
                      : 'bg-slate-900/60 text-slate-400 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <Wifi className="w-3 h-3 mx-1" />
                  <span>{language === 'ar' ? 'نقطة وصول' : 'Access Point'}</span>
                </button>
              </>
            )}

            <div className="h-4 w-[1px] bg-slate-700 mx-2 hidden sm:block" />

            {/* Department Filter: Selectable from Organizational Structure */}
            <select
              value={selectedDepartment}
              onChange={(e) => setSelectedDepartment(e.target.value)}
              className="bg-slate-900/80 border border-slate-700 text-slate-300 text-xs rounded-lg px-2.5 py-1.5 focus:outline-hidden focus:border-cyan-500 font-medium cursor-pointer"
            >
              <option value="ALL">{language === 'ar' ? 'كافة أقسام الهيكل التنظيمي' : 'All Org Departments'}</option>
              {orgDepts.map(dept => (
                <option key={dept.id || dept.nameEn} value={dept.nameEn}>
                  {language === 'ar' ? `${dept.nameAr} (${dept.nameEn})` : `${dept.nameEn} - ${dept.nameAr}`}
                </option>
              ))}
            </select>

            {/* Warranty Status Filter */}
            <select
              value={selectedWarrantyStatus}
              onChange={(e) => setSelectedWarrantyStatus(e.target.value as any)}
              className="bg-slate-900/80 border border-slate-700 text-slate-300 text-xs rounded-lg px-2.5 py-1.5 focus:outline-hidden focus:border-cyan-500"
            >
              <option value="ALL">{language === 'ar' ? 'حالة الضمان: الكل' : 'Warranty: All'}</option>
              <option value="active">{language === 'ar' ? 'ساري المفعول (Active)' : 'Under Warranty'}</option>
              <option value="expired">{language === 'ar' ? 'منتهي الضمان (Expired)' : 'Warranty Expired'}</option>
            </select>

            {(selectedType !== 'ALL' || selectedDepartment !== 'ALL' || selectedWarrantyStatus !== 'ALL' || searchQuery) && (
              <button
                onClick={() => {
                  setSelectedCategory('ALL');
                  setSelectedType('ALL');
                  setSelectedDepartment('ALL');
                  setSelectedWarrantyStatus('ALL');
                  setSearchQuery('');
                }}
                className="text-xs text-rose-400 hover:text-rose-300 font-semibold px-2 py-1 transition cursor-pointer"
              >
                {language === 'ar' ? 'إعادة ضبط الفلاتر' : 'Reset Filters'}
              </button>
            )}
          </div>
        </div>

        {/* DEVICE LIST / GRID */}
        {filteredDevices.length === 0 ? (
          <div className="bg-slate-800/40 rounded-2xl border border-slate-800 p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center mx-auto text-slate-500">
              <HardDrive className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">
              {language === 'ar' ? 'لا توجد أصول مطابقة للبحث أو الفلتر' : 'No Assets Found Matching Filters'}
            </h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              {language === 'ar'
                ? 'جرّب تعديل مصطلحات البحث أو تغيير فلاتر التصنيف، أو قم بإدخال أصل جديد.'
                : 'Try adjusting your search criteria, clear active filters, or register a new asset.'}
            </p>
            <button
              onClick={handleOpenCreate}
              className="mt-3 inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shadow-md"
            >
              <Plus className="w-4 h-4 mx-1" />
              <span>{language === 'ar' ? 'إدخال أصل جديد' : 'Register New Asset'}</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
            {filteredDevices.map(device => {
              const maintCount = device.maintenanceHistory?.length || 0;
              const deptTransfersCount = device.departmentHistory?.length || 0;

              return (
                <div
                  key={device.id}
                  className="bg-slate-800/70 hover:bg-slate-800/90 rounded-2xl border border-slate-700/80 hover:border-slate-600 transition duration-200 shadow-md hover:shadow-xl p-5 flex flex-col justify-between space-y-4 group"
                >
                  {/* Card Header: Type Badge, Icon, Device Code, Status */}
                  <div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-9 h-9 rounded-xl bg-slate-900/90 border border-slate-700/80 flex items-center justify-center group-hover:scale-105 transition">
                          {getDeviceIcon(device.deviceType, device.category)}
                        </div>
                        <div>
                          <span className="font-mono text-xs font-bold text-white tracking-wide">
                            {device.deviceCode}
                          </span>
                          <div className="flex items-center space-x-1.5 text-[11px] text-slate-400">
                            <span className="capitalize">{device.deviceType}</span>
                            <span>•</span>
                            <span className="text-slate-300 font-semibold">{device.brand}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col items-end space-y-1">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                          device.status === 'Operational'
                            ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                            : device.status === 'Under Maintenance'
                            ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                            : 'bg-slate-600/20 text-slate-300 border-slate-600/30'
                        }`}>
                          {device.status}
                        </span>

                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                          device.isWarrantyActive
                            ? 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                            : 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                        }`}>
                          {device.isWarrantyActive 
                            ? (language === 'ar' ? 'ضمان ساري' : 'Warranty Active')
                            : (language === 'ar' ? 'منتهي الضمان' : 'Warranty Expired')}
                        </span>
                      </div>
                    </div>

                    {/* Model & Basic Specs */}
                    <div className="mt-3.5">
                      <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition line-clamp-1">
                        {device.model}
                      </h3>
                      {device.serialNumber && (
                        <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                          S/N: {device.serialNumber}
                        </p>
                      )}
                    </div>

                    {/* Department Tag & IP */}
                    <div className="mt-3 pt-3 border-t border-slate-700/60 space-y-2 text-xs">
                      <div className="flex items-center justify-between text-slate-300">
                        <span className="flex items-center space-x-1.5 text-slate-400">
                          <Building2 className="w-3.5 h-3.5 text-blue-400 mx-1" />
                          <span>{language === 'ar' ? 'القسم الحالي:' : 'Department:'}</span>
                        </span>
                        <span className="font-semibold text-white truncate max-w-[160px]" title={language === 'ar' ? (device.departmentAr || device.department) : device.department}>
                          {language === 'ar' ? (device.departmentAr || device.department) : device.department}
                        </span>
                      </div>

                      {device.ipAddress && (
                        <div className="flex items-center justify-between text-slate-300">
                          <span className="flex items-center space-x-1.5 text-slate-400">
                            <Globe className="w-3.5 h-3.5 text-cyan-400 mx-1" />
                            <span>{language === 'ar' ? 'عنوان IP:' : 'IP Address:'}</span>
                          </span>
                          <span className="font-mono text-cyan-300 font-semibold">{device.ipAddress}</span>
                        </div>
                      )}

                      <div className="flex items-center justify-between text-slate-300">
                        <span className="flex items-center space-x-1.5 text-slate-400">
                          <Calendar className="w-3.5 h-3.5 text-amber-400 mx-1" />
                          <span>{language === 'ar' ? 'تاريخ الشراء:' : 'Purchase Date:'}</span>
                        </span>
                        <span className="font-mono">{device.dateOfPurchase}</span>
                      </div>

                      <div className="flex items-center justify-between text-slate-300">
                        <span className="flex items-center space-x-1.5 text-slate-400">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 mx-1" />
                          <span>{language === 'ar' ? 'مدة الضمان:' : 'Warranty Period:'}</span>
                        </span>
                        <span className="font-medium text-slate-200">
                          {device.warrantyPeriod} {device.warrantyExpiryDate ? `(${device.warrantyExpiryDate})` : ''}
                        </span>
                      </div>
                    </div>

                    {/* Counts of Maintenance & Department History */}
                    <div className="mt-3 flex items-center justify-between text-[11px] text-slate-400 bg-slate-900/60 p-2 rounded-xl border border-slate-700/60">
                      <span className="flex items-center space-x-1">
                        <Wrench className="w-3.5 h-3.5 text-amber-400 mx-1" />
                        <span>{maintCount} {language === 'ar' ? 'سجلات صيانة' : 'Maintenance Logs'}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <History className="w-3.5 h-3.5 text-purple-400 mx-1" />
                        <span>{deptTransfersCount} {language === 'ar' ? 'تحويلات سابقة' : 'Past Transfers'}</span>
                      </span>
                    </div>
                  </div>

                  {/* Card Actions Ribbon */}
                  <div className="pt-3 border-t border-slate-700/60 flex items-center justify-between gap-1">
                    <button
                      onClick={() => { setViewDeviceModal(device); setActiveDetailTab('overview'); }}
                      className="flex-1 py-1.5 px-2 rounded-xl bg-slate-700/80 hover:bg-slate-700 text-cyan-300 hover:text-cyan-200 text-xs font-bold border border-slate-600/70 transition flex items-center justify-center space-x-1 cursor-pointer"
                      title={language === 'ar' ? 'عرض السجلات والتفاصيل' : 'View Full Details & History'}
                    >
                      <FileText className="w-3.5 h-3.5 mx-1" />
                      <span>{language === 'ar' ? 'التفاصيل والسجل' : 'Details & History'}</span>
                    </button>

                    <button
                      onClick={() => handleOpenTransfer(device)}
                      className="p-1.5 rounded-xl bg-slate-700/80 hover:bg-slate-700 text-purple-300 hover:text-purple-200 border border-slate-600/70 transition cursor-pointer"
                      title={language === 'ar' ? 'تحويل الجهاز لقسم آخر' : 'Transfer Department'}
                    >
                      <ArrowRightLeft className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleOpenMaintenance(device)}
                      className="p-1.5 rounded-xl bg-slate-700/80 hover:bg-slate-700 text-amber-300 hover:text-amber-200 border border-slate-600/70 transition cursor-pointer"
                      title={language === 'ar' ? 'إضافة سجل صيانة' : 'Add Maintenance Log'}
                    >
                      <Wrench className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => setBadgeModalDevice(device)}
                      className="p-1.5 rounded-xl bg-slate-700/80 hover:bg-slate-700 text-teal-300 hover:text-teal-200 border border-slate-600/70 transition cursor-pointer"
                      title={language === 'ar' ? 'عرض وطباعة ملصق كود الأصل (QR)' : 'View / Print QR Code Tag'}
                    >
                      <QrCodeIcon className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleOpenEdit(device)}
                      className="p-1.5 rounded-xl bg-slate-700/80 hover:bg-slate-700 text-blue-300 hover:text-blue-200 border border-slate-600/70 transition cursor-pointer"
                      title={language === 'ar' ? 'تعديل بيانات الجهاز' : 'Edit Specs'}
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleDelete(device)}
                      className="p-1.5 rounded-xl bg-slate-700/80 hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 border border-slate-600/70 transition cursor-pointer"
                      title={language === 'ar' ? 'حذف الجهاز' : 'Delete Device'}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>

      {/* ========================================================================= */}
      {/* MODAL 1: VIEW DEVICE DETAILS & CHRONOLOGICAL HISTORIES (Department & Maint) */}
      {/* ========================================================================= */}
      {viewDeviceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div 
            className="bg-slate-900 border border-slate-700/90 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            dir={dir}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/50">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-cyan-400">
                  {getDeviceIcon(viewDeviceModal.deviceType, viewDeviceModal.category)}
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h2 className="text-base sm:text-lg font-bold text-white">
                      {viewDeviceModal.brand} {viewDeviceModal.model}
                    </h2>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      {viewDeviceModal.deviceCode}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    {viewDeviceModal.category === 'network' ? 'Network Device' : 'Electronic Device'} • {viewDeviceModal.deviceType}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={() => setBadgeModalDevice(viewDeviceModal)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 hover:text-teal-200 border border-slate-700 transition flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
                  title={language === 'ar' ? 'عرض وطباعة ملصق كود الأصل (QR)' : 'Print / View QR Tag'}
                >
                  <QrCodeIcon className="w-4 h-4" />
                  <span>{language === 'ar' ? 'ملصق QR' : 'QR Tag'}</span>
                </button>

                <button
                  onClick={() => setViewDeviceModal(null)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Navigation Tabs */}
            <div className="flex items-center border-b border-slate-800 px-5 bg-slate-900/60">
              <button
                onClick={() => setActiveDetailTab('overview')}
                className={`py-3 px-4 text-xs font-bold border-b-2 transition flex items-center space-x-2 cursor-pointer ${
                  activeDetailTab === 'overview'
                    ? 'border-cyan-500 text-cyan-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <HardDrive className="w-3.5 h-3.5 mx-1" />
                <span>{language === 'ar' ? 'المواصفات والضمان' : 'Overview & Warranty'}</span>
              </button>

              <button
                onClick={() => setActiveDetailTab('departments')}
                className={`py-3 px-4 text-xs font-bold border-b-2 transition flex items-center space-x-2 cursor-pointer ${
                  activeDetailTab === 'departments'
                    ? 'border-purple-500 text-purple-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <History className="w-3.5 h-3.5 mx-1" />
                <span>{language === 'ar' ? 'سجل الأقسام السابقة' : 'Department History'}</span>
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-800 text-slate-300">
                  {viewDeviceModal.departmentHistory?.length || 0}
                </span>
              </button>

              <button
                onClick={() => setActiveDetailTab('maintenance')}
                className={`py-3 px-4 text-xs font-bold border-b-2 transition flex items-center space-x-2 cursor-pointer ${
                  activeDetailTab === 'maintenance'
                    ? 'border-amber-500 text-amber-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Wrench className="w-3.5 h-3.5 mx-1" />
                <span>{language === 'ar' ? 'سجل الصيانة والدعم' : 'Maintenance History'}</span>
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-800 text-slate-300">
                  {viewDeviceModal.maintenanceHistory?.length || 0}
                </span>
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
              
              {/* TAB 1: OVERVIEW & WARRANTY */}
              {activeDetailTab === 'overview' && (
                <div className="space-y-6">
                  {/* Quick specs grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
                      <span className="text-[11px] text-slate-400 block">{language === 'ar' ? 'القسم الحالي' : 'Current Department'}</span>
                      <span className="text-sm font-bold text-white mt-1 block">
                        {language === 'ar' ? (viewDeviceModal.departmentAr || viewDeviceModal.department) : viewDeviceModal.department}
                      </span>
                    </div>

                    <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
                      <span className="text-[11px] text-slate-400 block">{language === 'ar' ? 'حالة التشغيل' : 'Operational Status'}</span>
                      <span className="text-sm font-bold text-emerald-400 mt-1 block">{viewDeviceModal.status}</span>
                    </div>

                    <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
                      <span className="text-[11px] text-slate-400 block">{language === 'ar' ? 'الرقم التسلسلي (Serial No)' : 'Serial Number'}</span>
                      <span className="text-sm font-mono font-bold text-cyan-300 mt-1 block">{viewDeviceModal.serialNumber || 'N/A'}</span>
                    </div>

                    <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
                      <span className="text-[11px] text-slate-400 block">{language === 'ar' ? 'تاريخ الشراء' : 'Date of Purchase'}</span>
                      <span className="text-sm font-mono font-bold text-white mt-1 block">{viewDeviceModal.dateOfPurchase}</span>
                    </div>

                    <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
                      <span className="text-[11px] text-slate-400 block">{language === 'ar' ? 'تاريخ بدء الضمان' : 'Warranty Start Date'}</span>
                      <span className="text-sm font-mono font-bold text-white mt-1 block">{viewDeviceModal.warrantyStartDate}</span>
                    </div>

                    <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
                      <span className="text-[11px] text-slate-400 block">{language === 'ar' ? 'مدة الضمان وحالته' : 'Warranty Period & Status'}</span>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="text-sm font-bold text-white">{viewDeviceModal.warrantyPeriod}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          viewDeviceModal.isWarrantyActive 
                            ? 'bg-emerald-500/20 text-emerald-300' 
                            : 'bg-rose-500/20 text-rose-300'
                        }`}>
                          {viewDeviceModal.isWarrantyActive 
                            ? (language === 'ar' ? 'ساري حتى ' + viewDeviceModal.warrantyExpiryDate : 'Active until ' + viewDeviceModal.warrantyExpiryDate)
                            : (language === 'ar' ? 'منتهي بتاريخ ' + viewDeviceModal.warrantyExpiryDate : 'Expired on ' + viewDeviceModal.warrantyExpiryDate)}
                        </span>
                      </div>
                    </div>

                    {viewDeviceModal.ipAddress && (
                      <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
                        <span className="text-[11px] text-slate-400 block">{language === 'ar' ? 'عنوان IP' : 'IP Address'}</span>
                        <span className="text-sm font-mono font-bold text-cyan-300 mt-1 block">{viewDeviceModal.ipAddress}</span>
                      </div>
                    )}

                    {viewDeviceModal.macAddress && (
                      <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
                        <span className="text-[11px] text-slate-400 block">{language === 'ar' ? 'عنوان MAC' : 'MAC Address'}</span>
                        <span className="text-sm font-mono font-bold text-slate-300 mt-1 block">{viewDeviceModal.macAddress}</span>
                      </div>
                    )}

                    {viewDeviceModal.location && (
                      <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
                        <span className="text-[11px] text-slate-400 block">{language === 'ar' ? 'الموقع الفعلي / الغرفة' : 'Physical Location'}</span>
                        <span className="text-sm font-bold text-slate-200 mt-1 block">{viewDeviceModal.location}</span>
                      </div>
                    )}

                    {viewDeviceModal.assignedEmployee && (
                      <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
                        <span className="text-[11px] text-slate-400 block">{language === 'ar' ? 'الموظف المسند إليه' : 'Assigned Employee'}</span>
                        <span className="text-sm font-bold text-slate-200 mt-1 block">{viewDeviceModal.assignedEmployee}</span>
                      </div>
                    )}
                  </div>

                  {viewDeviceModal.notes && (
                    <div className="bg-slate-800/40 p-4 rounded-xl border border-slate-700/60 space-y-1">
                      <span className="text-[11px] font-bold text-slate-400">{language === 'ar' ? 'ملاحظات وتفاصيل إضافية:' : 'Additional Notes / Specifications:'}</span>
                      <p className="text-slate-300 leading-relaxed">{viewDeviceModal.notes}</p>
                    </div>
                  )}

                  {/* Actions inside Modal */}
                  <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
                    <button
                      onClick={() => handleOpenTransfer(viewDeviceModal)}
                      className="px-3.5 py-2 rounded-xl bg-purple-600/30 text-purple-300 hover:bg-purple-600/40 border border-purple-500/40 font-bold transition flex items-center space-x-1.5 cursor-pointer"
                    >
                      <ArrowRightLeft className="w-4 h-4 mx-1" />
                      <span>{language === 'ar' ? 'تحويل لقسم آخر' : 'Transfer Department'}</span>
                    </button>

                    <button
                      onClick={() => handleOpenMaintenance(viewDeviceModal)}
                      className="px-3.5 py-2 rounded-xl bg-amber-600/30 text-amber-300 hover:bg-amber-600/40 border border-amber-500/40 font-bold transition flex items-center space-x-1.5 cursor-pointer"
                    >
                      <Wrench className="w-4 h-4 mx-1" />
                      <span>{language === 'ar' ? 'إضافة سجل صيانة' : 'Add Maintenance Log'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 2: DEPARTMENT HISTORY LIST */}
              {activeDetailTab === 'departments' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-white text-sm">
                        {language === 'ar' ? 'سجل تحويلات الجهاز بين الإدارات والأقسام' : 'Department Assignment & Transfer History'}
                      </h4>
                      <p className="text-slate-400 text-xs mt-0.5">
                        {language === 'ar'
                          ? 'قائمة توضح كافة الأقسام التي كان يتبع لها هذا الجهاز منذ تاريخ شرائه وحتى الآن.'
                          : 'List of all departments this device was previously assigned to with transfer justifications.'}
                      </p>
                    </div>

                    <button
                      onClick={() => handleOpenTransfer(viewDeviceModal)}
                      className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold transition flex items-center space-x-1 cursor-pointer"
                    >
                      <ArrowRightLeft className="w-3.5 h-3.5 mx-1" />
                      <span>{language === 'ar' ? 'تحويل الآن' : 'Transfer Now'}</span>
                    </button>
                  </div>

                  {/* Current Active Department Badge */}
                  <div className="p-3.5 rounded-xl bg-purple-950/30 border border-purple-800/60 flex items-center justify-between">
                    <div className="flex items-center space-x-2.5">
                      <div className="w-8 h-8 rounded-lg bg-purple-600/30 border border-purple-500/50 flex items-center justify-center text-purple-300">
                        <Building2 className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block">
                          {language === 'ar' ? 'القسم الحالي النشط' : 'Current Active Assignment'}
                        </span>
                        <span className="text-sm font-bold text-white">
                          {language === 'ar' ? (viewDeviceModal.departmentAr || viewDeviceModal.department) : viewDeviceModal.department}
                        </span>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {language === 'ar' ? 'نشط حالياً' : 'Active'}
                    </span>
                  </div>

                  {/* Previous Historical Departments Timeline */}
                  {(!viewDeviceModal.departmentHistory || viewDeviceModal.departmentHistory.length === 0) ? (
                    <div className="text-center py-8 text-slate-500 bg-slate-800/30 rounded-xl border border-slate-800">
                      <History className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                      <p>{language === 'ar' ? 'لم يتم تحويل هذا الجهاز من قبل، القسم الحالي هو القسم الأصلي منذ تاريخ الشراء.' : 'No previous department transfers recorded. This device has remained in its initial department.'}</p>
                    </div>
                  ) : (
                    <div className="space-y-3 relative before:absolute before:inset-0 before:left-3.5 before:w-0.5 before:bg-slate-700/60">
                      {viewDeviceModal.departmentHistory.map((item, idx) => (
                        <div key={item.id || idx} className="relative pl-8 space-y-1">
                          <div className="absolute left-2 top-2 w-3 h-3 rounded-full bg-purple-500 border-2 border-slate-900" />
                          <div className="bg-slate-800/70 p-3.5 rounded-xl border border-slate-700/70 space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-white text-xs">
                                {language === 'ar' ? (item.departmentAr || item.department) : item.department}
                              </span>
                              <span className="text-[11px] font-mono text-slate-400">
                                {item.transferredDate || item.assignedDate}
                              </span>
                            </div>

                            <div className="text-slate-300 text-xs">
                              <span className="text-slate-400">{language === 'ar' ? 'سبب التحويل: ' : 'Reason: '}</span>
                              {item.reason || (language === 'ar' ? 'إعادة توزيع الأصول التقنية' : 'Asset reassignment')}
                            </div>

                            {item.transferredBy && (
                              <div className="text-[11px] text-slate-400 flex items-center space-x-1">
                                <UserCheck className="w-3 h-3 text-cyan-400 mx-1" />
                                <span>{language === 'ar' ? 'بواسطة: ' : 'Transferred by: '}</span>
                                <span className="text-slate-300 font-semibold">{item.transferredBy}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: MAINTENANCE HISTORY */}
              {activeDetailTab === 'maintenance' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-white text-sm">
                        {language === 'ar' ? 'سجل الصيانة الدورية والدعم الفني' : 'Maintenance & Repair History Log'}
                      </h4>
                      <p className="text-slate-400 text-xs mt-0.5">
                        {language === 'ar'
                          ? 'توثيق كافة عمليات الصيانة، الإصلاح، استبدال القطع، وترقيات العتاد.'
                          : 'Document all maintenance procedures, part replacements, hardware upgrades, and inspections.'}
                      </p>
                    </div>

                    <button
                      onClick={() => handleOpenMaintenance(viewDeviceModal)}
                      className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold transition flex items-center space-x-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5 mx-1" />
                      <span>{language === 'ar' ? 'إضافة سجل' : 'Log Maintenance'}</span>
                    </button>
                  </div>

                  {(!viewDeviceModal.maintenanceHistory || viewDeviceModal.maintenanceHistory.length === 0) ? (
                    <div className="text-center py-8 text-slate-500 bg-slate-800/30 rounded-xl border border-slate-800">
                      <Wrench className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                      <p>{language === 'ar' ? 'لا توجد سجلات صيانة مسجلة لهذا الجهاز حتى الآن.' : 'No maintenance records registered for this device yet.'}</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {viewDeviceModal.maintenanceHistory.map((maint, idx) => (
                        <div key={maint.id || idx} className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/80 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold ${
                                maint.type === 'Repair' 
                                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                  : maint.type === 'Upgrade'
                                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                                  : maint.type === 'Inspection'
                                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              }`}>
                                {maint.type}
                              </span>
                              <span className="font-bold text-white text-xs">{maint.performedBy}</span>
                            </div>

                            <div className="flex items-center space-x-2 font-mono text-[11px] text-slate-400">
                              <span>{maint.date}</span>
                              {maint.cost !== undefined && maint.cost > 0 && (
                                <span className="text-emerald-400 font-bold">${maint.cost}</span>
                              )}
                            </div>
                          </div>

                          <p className="text-slate-200 text-xs leading-relaxed">
                            {maint.description}
                          </p>

                          {maint.notes && (
                            <p className="text-slate-400 text-[11px] italic bg-slate-900/60 p-2 rounded-lg">
                              {maint.notes}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-950/60 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-500 font-mono">
                ID: {viewDeviceModal.id} • Created: {new Date(viewDeviceModal.createdAt).toLocaleDateString()}
              </span>
              <button
                onClick={() => setViewDeviceModal(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition cursor-pointer"
              >
                {language === 'ar' ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: REGISTER / EDIT DEVICE */}
      {/* ========================================================================= */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div 
            className="bg-slate-900 border border-slate-700/90 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
            dir={dir}
          >
            <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/50">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white">
                  <Laptop className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-bold text-white">
                    {editingDevice 
                      ? (language === 'ar' ? 'تعديل بيانات الأصل' : 'Edit Asset Specifications')
                      : (language === 'ar' ? 'إدخال أصل تقني أو شبكي جديد' : 'Register New Asset')}
                  </h2>
                  <p className="text-xs text-slate-400">
                    {language === 'ar'
                      ? 'أدخل بيانات الماركة، الموديل، فترات الضمان، القسم، وسجل الصيانة'
                      : 'Provide model, brand, warranty dates, department assignment, and network parameters'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitDevice} className="p-6 overflow-y-auto space-y-4 flex-1 text-xs">
              
              {/* Category selector */}
              <div>
                <label className="block text-slate-300 font-bold mb-1.5">
                  {language === 'ar' ? 'تصنيف الجهاز الأساسي *' : 'Device Category *'}
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setFormCategory('electronic');
                      setFormDeviceType('Computer');
                    }}
                    className={`py-2.5 px-3 rounded-xl border font-bold flex items-center justify-center space-x-2 transition cursor-pointer ${
                      formCategory === 'electronic'
                        ? 'bg-cyan-600/30 text-cyan-300 border-cyan-500 shadow-xs'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <Laptop className="w-4 h-4 mx-1" />
                    <span>{language === 'ar' ? 'جهاز إلكتروني (Electronic)' : 'Electronic Device'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setFormCategory('network');
                      setFormDeviceType('router');
                    }}
                    className={`py-2.5 px-3 rounded-xl border font-bold flex items-center justify-center space-x-2 transition cursor-pointer ${
                      formCategory === 'network'
                        ? 'bg-teal-600/30 text-teal-300 border-teal-500 shadow-xs'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <Network className="w-4 h-4 mx-1" />
                    <span>{language === 'ar' ? 'جهاز شبكي (Network)' : 'Network Device'}</span>
                  </button>
                </div>
              </div>

              {/* Device Type */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'نوع الجهاز المحدد *' : 'Device Type *'}
                  </label>
                  {formCategory === 'electronic' ? (
                    <select
                      value={formDeviceType}
                      onChange={(e) => setFormDeviceType(e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-cyan-500"
                    >
                      <option value="Computer">{language === 'ar' ? 'Computer (حاسوب)' : 'Computer'}</option>
                      <option value="Printer">{language === 'ar' ? 'Printer (طابعة)' : 'Printer'}</option>
                      <option value="Screen">{language === 'ar' ? 'Screen (شاشة)' : 'Screen'}</option>
                      <option value="Fingerprint device">{language === 'ar' ? 'Fingerprint device (جهاز بصمة)' : 'Fingerprint device'}</option>
                      <option value="Scanner">{language === 'ar' ? 'Scanner (ماسح ضوئي)' : 'Scanner'}</option>
                    </select>
                  ) : (
                    <select
                      value={formDeviceType}
                      onChange={(e) => setFormDeviceType(e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-cyan-500"
                    >
                      <option value="router">{language === 'ar' ? 'Router (راوتر)' : 'Router'}</option>
                      <option value="switch">{language === 'ar' ? 'Switch (موزع شبكة / سويتش)' : 'Switch'}</option>
                      <option value="access point">{language === 'ar' ? 'Access Point (نقطة وصول لاسلكية)' : 'Access Point'}</option>
                    </select>
                  )}
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-slate-300 font-bold">
                      {language === 'ar' ? 'القسم / الوحدة الإدارية بالهيكل التنظيمي *' : 'Org Structure Department / Unit *'}
                    </label>
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-indigo-950/80 text-indigo-300 border border-indigo-700/60">
                      <Building2 className="w-3 h-3 text-indigo-400" />
                      {language === 'ar' ? 'بيانات الهيكل التنظيمي' : 'Org Structure Linked'}
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    <select
                      required
                      value={formDepartment}
                      onChange={(e) => {
                        const val = e.target.value;
                        setFormDepartment(val);
                        const matched = orgDepts.find(d => d.nameEn === val || d.nameAr === val);
                        if (matched) {
                          setFormDepartmentAr(matched.nameAr);
                        }
                      }}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-hidden focus:border-cyan-500 font-medium cursor-pointer"
                    >
                      {orgDepts.map(dept => (
                        <option key={dept.id || dept.nameEn} value={dept.nameEn}>
                          {language === 'ar' 
                            ? `${dept.nameAr} (${dept.nameEn}) — ${dept.type}` 
                            : `${dept.nameEn} — ${dept.nameAr} [${dept.type}]`}
                        </option>
                      ))}
                    </select>
                    <p className="text-[11px] text-cyan-400/90 flex items-center gap-1 font-medium">
                      <Building2 className="w-3.5 h-3.5 text-cyan-400 inline shrink-0" />
                      <span>
                        {language === 'ar'
                          ? 'اختر الإدارة أو القسم أو الوحدة التابع لها الأصل من الهيكل التنظيمي للمؤسسة'
                          : 'Select the department or organizational unit owning this asset from the org structure'}
                      </span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Brand & Model */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'العلامة التجارية / الماركة (Brand) *' : 'Brand / Manufacturer *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formBrand}
                    onChange={(e) => setFormBrand(e.target.value)}
                    placeholder="e.g. Dell, HP, Cisco, Canon, ZKTeco, Lenovo"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'الموديل والتفاصيل (Model) *' : 'Model & Specs *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formModel}
                    onChange={(e) => setFormModel(e.target.value)}
                    placeholder="e.g. OptiPlex 7090, LaserJet M608dn, Catalyst 2960"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>
              </div>

              {/* Serial Number & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'الرقم التسلسلي (Serial Number / Asset Tag)' : 'Serial Number / Asset Tag'}
                  </label>
                  <input
                    type="text"
                    value={formSerialNumber}
                    onChange={(e) => setFormSerialNumber(e.target.value)}
                    placeholder="e.g. SN-883910-US"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-hidden focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'الحالة التشغيلية' : 'Operational Status'}
                  </label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-cyan-500"
                  >
                    <option value="Operational">Operational (يعمل بكفاءة)</option>
                    <option value="Under Maintenance">Under Maintenance (تحت الصيانة)</option>
                    <option value="Storage">Storage (في المخزن / احتياطي)</option>
                    <option value="Retired">Retired (متقاعد / خارج الخدمة)</option>
                  </select>
                </div>
              </div>

              {/* Purchase Date & Warranty */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-3.5 bg-slate-950/40 rounded-xl border border-slate-800">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'تاريخ الشراء (Date of Purchase) *' : 'Date of Purchase *'}
                  </label>
                  <input
                    type="date"
                    required
                    value={formDateOfPurchase}
                    onChange={(e) => {
                      setFormDateOfPurchase(e.target.value);
                      if (!formWarrantyStartDate) setFormWarrantyStartDate(e.target.value);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'تاريخ بدء الضمان (Warranty Start)' : 'Warranty Start Date'}
                  </label>
                  <input
                    type="date"
                    required
                    value={formWarrantyStartDate}
                    onChange={(e) => setFormWarrantyStartDate(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'فترة الضمان (Warranty Period) *' : 'Warranty Period *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formWarrantyPeriod}
                    onChange={(e) => setFormWarrantyPeriod(e.target.value)}
                    placeholder="e.g. 12 Months, 24 Months, 3 Years"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>
              </div>

              {/* IP, MAC, Location */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'عنوان IP (اختياري)' : 'IP Address (Optional)'}
                  </label>
                  <input
                    type="text"
                    value={formIpAddress}
                    onChange={(e) => setFormIpAddress(e.target.value)}
                    placeholder="e.g. 192.168.1.100"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-hidden focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'عنوان MAC (اختياري)' : 'MAC Address (Optional)'}
                  </label>
                  <input
                    type="text"
                    value={formMacAddress}
                    onChange={(e) => setFormMacAddress(e.target.value)}
                    placeholder="e.g. 00:1A:2B:3C:4D:5E"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-hidden focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'الموقع الفعلي / الغرفة' : 'Physical Location / Room'}
                  </label>
                  <input
                    type="text"
                    value={formLocation}
                    onChange={(e) => setFormLocation(e.target.value)}
                    placeholder="e.g. Server Room A, Floor 2"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {language === 'ar' ? 'ملاحظات وتفاصيل إضافية' : 'Notes / Additional Details'}
                </label>
                <textarea
                  rows={2}
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder={language === 'ar' ? 'أي تفاصيل فنية، مواصفات رام أو معالج، أو شروط صيانة خاصة...' : 'Any technical specs, CPU, RAM, or special instructions...'}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-cyan-500"
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition cursor-pointer"
                >
                  {language === 'ar' ? 'إلغاء' : 'Cancel'}
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold shadow-lg shadow-blue-500/20 transition cursor-pointer"
                >
                  {editingDevice 
                    ? (language === 'ar' ? 'حفظ التعديلات' : 'Save Changes')
                    : (language === 'ar' ? 'حفظ الجهاز الجديد' : 'Register Device')}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: TRANSFER DEPARTMENT */}
      {/* ========================================================================= */}
      {transferModalDevice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div 
            className="bg-slate-900 border border-slate-700/90 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden"
            dir={dir}
          >
            <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/50">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300">
                  <ArrowRightLeft className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">
                    {language === 'ar' ? 'تحويل الأصل لقسم آخر' : 'Transfer Asset to Another Department'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {transferModalDevice.brand} {transferModalDevice.model} ({transferModalDevice.deviceCode})
                  </p>
                </div>
              </div>

              <button
                onClick={() => setTransferModalDevice(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitTransfer} className="p-6 space-y-4 text-xs">
              
              <div className="p-3.5 bg-slate-800/60 rounded-xl border border-slate-700/60 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block">{language === 'ar' ? 'القسم الحالي:' : 'Current Department:'}</span>
                  <span className="text-sm font-bold text-white">
                    {language === 'ar' ? (transferModalDevice.departmentAr || transferModalDevice.department) : transferModalDevice.department}
                  </span>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-700 text-slate-300">
                  {language === 'ar' ? 'سيتم أرشفته بالسجل' : 'Will be archived'}
                </span>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-slate-300 font-bold">
                    {language === 'ar' ? 'القسم الجديد المستلم (من الهيكل التنظيمي) *' : 'New Target Department (from Org Structure) *'}
                  </label>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-900/60 text-purple-300 border border-purple-700/50">
                    <Building2 className="w-3 h-3 text-purple-400" />
                    {language === 'ar' ? 'الهيكل التنظيمي' : 'Org Structure'}
                  </span>
                </div>
                <select
                  required
                  value={transferTargetDept}
                  onChange={(e) => {
                    const val = e.target.value;
                    setTransferTargetDept(val);
                    const matched = orgDepts.find(d => d.nameEn === val || d.nameAr === val);
                    if (matched) {
                      setTransferTargetDeptAr(matched.nameAr);
                    }
                  }}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white text-sm focus:outline-hidden focus:border-purple-500 font-medium"
                >
                  {orgDepts
                    .filter(d => !isSameDepartment(d.nameEn, transferModalDevice.department) && !isSameDepartment(d.nameAr, transferModalDevice.department))
                    .map(dept => (
                      <option key={dept.id || dept.nameEn} value={dept.nameEn}>
                        {language === 'ar' 
                          ? `${dept.nameAr} (${dept.nameEn})` 
                          : `${dept.nameEn} — ${dept.nameAr} [${dept.type}]`}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {language === 'ar' ? 'تاريخ التحويل الفعلي' : 'Effective Transfer Date'}
                </label>
                <input
                  type="date"
                  required
                  value={transferDate}
                  onChange={(e) => setTransferDate(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {language === 'ar' ? 'سبب التحويل / المبرر الإداري' : 'Transfer Reason / Justification'}
                </label>
                <textarea
                  rows={3}
                  required
                  value={transferReason}
                  onChange={(e) => setTransferReason(e.target.value)}
                  placeholder={language === 'ar' ? 'مثال: إعادة هيكلة، متطلبات مشروع جديد، انتقال الموظف...' : 'e.g. Reassigned for new project requirements or staff relocation'}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-purple-500"
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setTransferModalDevice(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition cursor-pointer"
                >
                  {language === 'ar' ? 'إلغاء' : 'Cancel'}
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold transition shadow-lg shadow-purple-500/20 cursor-pointer"
                >
                  {language === 'ar' ? 'تأكيد التحويل وحفظ السجل' : 'Confirm Transfer & Archive'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: ADD MAINTENANCE RECORD */}
      {/* ========================================================================= */}
      {maintenanceModalDevice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div 
            className="bg-slate-900 border border-slate-700/90 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden"
            dir={dir}
          >
            <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/50">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-amber-600/30 border border-amber-500/40 flex items-center justify-center text-amber-300">
                  <Wrench className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">
                    {language === 'ar' ? 'تسجيل عملية صيانة جديدة' : 'Log Maintenance Event'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {maintenanceModalDevice.brand} {maintenanceModalDevice.model} ({maintenanceModalDevice.deviceCode})
                  </p>
                </div>
              </div>

              <button
                onClick={() => setMaintenanceModalDevice(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitMaintenance} className="p-6 space-y-4 text-xs">
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'تاريخ الصيانة *' : 'Maintenance Date *'}
                  </label>
                  <input
                    type="date"
                    required
                    value={maintDate}
                    onChange={(e) => setMaintDate(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'نوع الصيانة *' : 'Maintenance Type *'}
                  </label>
                  <select
                    value={maintType}
                    onChange={(e) => setMaintType(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-amber-500"
                  >
                    <option value="Routine">Routine (صيانة دورية وقائية)</option>
                    <option value="Repair">Repair (إصلاح عطل)</option>
                    <option value="Upgrade">Upgrade (ترقية عتاد / سوفتوير)</option>
                    <option value="Inspection">Inspection (فحص ومعايرة)</option>
                    <option value="Replacement">Replacement (استبدال قطع غيار)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {language === 'ar' ? 'الجهة / الفني المنفذ *' : 'Performed By (Technician / Vendor) *'}
                </label>
                <input
                  type="text"
                  required
                  value={maintPerformedBy}
                  onChange={(e) => setMaintPerformedBy(e.target.value)}
                  placeholder="e.g. Internal IT Hardware Team, Canon Official Support"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {language === 'ar' ? 'وصف تفاصيل عملية الصيانة المنجزة *' : 'Detailed Work Description *'}
                </label>
                <textarea
                  rows={3}
                  required
                  value={maintDescription}
                  onChange={(e) => setMaintDescription(e.target.value)}
                  placeholder={language === 'ar' ? 'اكتب ما تم إنجازه، استبدال القطع، تنظيف، فحص، أو تحديث...' : 'Describe the work performed, replaced parts, testing results...'}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'التكلفة المالية ($)' : 'Cost ($)'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={maintCost}
                    onChange={(e) => setMaintCost(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {language === 'ar' ? 'حالة عملية الصيانة' : 'Status'}
                  </label>
                  <select
                    value={maintStatus}
                    onChange={(e) => setMaintStatus(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-amber-500"
                  >
                    <option value="Completed">Completed (مكتمل بنجاح)</option>
                    <option value="In Progress">In Progress (قيد التنفيذ)</option>
                    <option value="Scheduled">Scheduled (مجدول لاحقاً)</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setMaintenanceModalDevice(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition cursor-pointer"
                >
                  {language === 'ar' ? 'إلغاء' : 'Cancel'}
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold transition shadow-lg shadow-amber-500/20 cursor-pointer"
                >
                  {language === 'ar' ? 'حفظ سجل الصيانة' : 'Save Maintenance Log'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: ASSET QR CODE CAMERA SCANNER (HTML5-QRCODE LIVE CAMERA & FILE)    */}
      {/* ========================================================================= */}
      <AssetQrScannerModal
        isOpen={isQrScannerOpen}
        onClose={() => setIsQrScannerOpen(false)}
        devices={devices}
        onSelectDevice={(device) => {
          setViewDeviceModal(device);
          setActiveDetailTab('overview');
        }}
        onTransferDevice={(device) => handleOpenTransfer(device)}
        onMaintenanceDevice={(device) => handleOpenMaintenance(device)}
        onRegisterWithCode={(code) => {
          handleOpenCreate();
          setFormSerialNumber(code);
        }}
      />

      {/* ========================================================================= */}
      {/* MODAL 6: ASSET QR BADGE & PRINTABLE STICKER                                */}
      {/* ========================================================================= */}
      <AssetQrBadgeModal
        device={badgeModalDevice}
        onClose={() => setBadgeModalDevice(null)}
      />

    </div>
  );
}
