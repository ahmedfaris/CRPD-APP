import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import { 
  LifeBuoy, 
  ShieldCheck, 
  Users, 
  BarChart3, 
  Terminal, 
  UserCheck, 
  LogOut, 
  ChevronDown, 
  PlusCircle, 
  AlertTriangle,
  Lock,
  Database,
  Grid,
  Languages,
  RotateCcw,
  Moon,
  Sun,
  FileText,
  LayoutDashboard,
  Ticket
} from 'lucide-react';

interface NavbarProps {
  currentTab: 'tickets' | 'dashboard' | 'users';
  onSelectTab: (tab: 'tickets' | 'dashboard' | 'users') => void;
  onOpenCreateTicket: () => void;
  onBackToMetro?: () => void;
  onOpenDocsExport?: () => void;
}

export function Navbar({ 
  currentTab, 
  onSelectTab, 
  onOpenCreateTicket, 
  onBackToMetro,
  onOpenDocsExport
}: NavbarProps) {
  const { currentUser, users, switchUser, logout, resetUser2FA, isAdmin, canAccessTeamManagement } = useAuth();
  const { t, language, toggleLanguage, dir } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const [showSwitchMenu, setShowSwitchMenu] = useState(false);

  const getRoleBadge = (role?: string) => {
    switch (role) {
      case 'Admin':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'Agent':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'Employee':
      default:
        return 'bg-slate-100 text-slate-700 border-slate-300';
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-slate-900 text-slate-100 border-b border-slate-800 shadow-md select-none" dir={dir}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo, Metro Hub link & Identity */}
          <div className="flex items-center space-x-4">
            
            {onBackToMetro && (
              <button
                onClick={onBackToMetro}
                className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold transition group cursor-pointer"
                title={language === 'ar' ? 'العودة إلى مركز مترو' : 'Return to Metro Hub'}
              >
                <Grid className="w-4 h-4 text-blue-400 group-hover:rotate-45 transition-transform mx-1" />
                <span className="hidden sm:inline">{t('nav.allApps')}</span>
              </button>
            )}

            {/* Main Navigation Tabs */}
            <nav className={`flex items-center space-x-1 ${dir === 'rtl' ? 'pr-2 sm:pr-3 mr-1 sm:mr-2 border-r' : 'pl-2 sm:pl-3 ml-1 sm:ml-2 border-l'} border-slate-800`}>
              {/* Tickets List Button */}
              <button
                id="nav-tickets"
                onClick={() => onSelectTab('tickets')}
                className={`px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center space-x-1.5 cursor-pointer ${
                  currentTab === 'tickets'
                    ? 'bg-slate-800 text-white shadow-xs ring-1 ring-slate-700'
                    : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                }`}
                title={language === 'ar' ? 'عرض جدول التذاكر والبلاغات' : 'View Tickets List'}
              >
                <Ticket className="w-3.5 h-3.5 text-blue-400 mx-0.5" />
                <span>{language === 'ar' ? 'التذاكر' : 'Tickets'}</span>
              </button>

              {/* Tickets Dashboard Button */}
              <button
                id="nav-tickets-dashboard"
                onClick={() => onSelectTab('dashboard')}
                className={`px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center space-x-1.5 cursor-pointer ${
                  currentTab === 'dashboard'
                    ? 'bg-slate-800 text-white shadow-xs ring-1 ring-slate-700'
                    : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                }`}
                title={language === 'ar' ? 'لوحة تحكم ومؤشرات أداء التذاكر' : 'Tickets Dashboard & Performance Metrics'}
              >
                <LayoutDashboard className="w-3.5 h-3.5 text-emerald-400 mx-0.5" />
                <span>{language === 'ar' ? 'لوحة تحكم التذاكر' : 'Tickets Dashboard'}</span>
              </button>
              
              {canAccessTeamManagement && (
                <button
                  id="nav-users"
                  onClick={() => onSelectTab('users')}
                  className={`px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center space-x-1.5 cursor-pointer ${
                    currentTab === 'users'
                      ? 'bg-slate-800 text-white shadow-xs ring-1 ring-slate-700'
                      : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                  }`}
                  title={language === 'ar' ? 'إدارة وتوزيع فرق العمل الفنية' : 'Support Teams Management'}
                >
                  <Users className="w-3.5 h-3.5 text-purple-400 mx-0.5" />
                  <span className="hidden sm:inline">{language === 'ar' ? 'إدارة فرق العمل' : 'Team Management'}</span>
                </button>
              )}
            </nav>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center space-x-2">
            
            {/* Quick Create Ticket Button in Navbar */}
            <button
              id="nav-btn-create-ticket"
              onClick={onOpenCreateTicket}
              className="hidden md:flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shadow-xs cursor-pointer"
              title={language === 'ar' ? 'إنشاء تذكرة جديدة' : 'Create New Ticket'}
            >
              <PlusCircle className="w-3.5 h-3.5 mx-0.5" />
              <span>{language === 'ar' ? 'تذكرة جديدة' : 'New Ticket'}</span>
            </button>
            
            {/* Bilingual Language Switcher Button */}
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition cursor-pointer"
              title={language === 'en' ? 'التحويل إلى اللغة العربية' : 'Switch to English'}
            >
              <Languages className="w-3.5 h-3.5 text-blue-400 mx-1" />
              <span>{language === 'en' ? 'العربية' : 'EN'}</span>
            </button>

            {/* Profile Dropdown */}
            <div className="relative">
              <button
                id="btn-user-menu"
                onClick={() => setShowSwitchMenu(!showSwitchMenu)}
                className="flex items-center space-x-2 p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700 transition cursor-pointer"
              >
                <div className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${currentUser?.avatarColor || 'bg-slate-700'}`}>
                  {currentUser?.fullName ? currentUser.fullName.split(' ').map(n => n[0]).join('').slice(0, 2) : 'U'}
                </div>
                <div className={`hidden xl:block ${dir === 'rtl' ? 'text-right pl-1' : 'text-left pr-1'} mx-1`}>
                  <div className="text-xs font-semibold text-slate-200 leading-tight">
                    {currentUser?.fullName}
                  </div>
                </div>
                <span className={`text-[10px] font-semibold uppercase px-1.5 py-0.2 rounded border ${getRoleBadge(currentUser?.role)} mx-1`}>
                  {currentUser?.role}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {/* Popover */}
              {showSwitchMenu && (
                <>
                  <div 
                    className="fixed inset-0 z-40"
                    onClick={() => setShowSwitchMenu(false)}
                  />
                  <div className={`absolute ${dir === 'rtl' ? 'left-0' : 'right-0'} mt-2 w-80 rounded-2xl bg-white text-slate-800 shadow-2xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95`} dir={dir}>
                    <div className="px-4 py-2 border-b border-slate-100">
                      <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">{t('auth.sessionActive')}</p>
                      <p className="text-sm font-bold text-slate-900">{currentUser?.fullName}</p>
                      <p className="text-xs text-slate-500">{currentUser?.jobTitle} • {currentUser?.department}</p>
                      <div className="mt-1 flex items-center space-x-1.5 text-[11px] text-emerald-600 font-semibold">
                        <ShieldCheck className="w-3.5 h-3.5 mx-1" />
                        <span>{language === 'ar' ? 'محمي بنظام 2FA (سماحية ±1د)' : '2FA Protected (±1m tolerance)'}</span>
                      </div>
                    </div>

                    <div className="px-4 py-2 border-b border-slate-100 bg-slate-50">
                      <p className="text-xs font-medium text-slate-600 flex items-center space-x-1.5">
                        <UserCheck className="w-3.5 h-3.5 text-blue-600 mx-1" />
                        <span>{t('metro.quickSwitch')}</span>
                      </p>
                    </div>

                    <div className="max-h-56 overflow-y-auto py-1">
                      {users.map((u) => {
                        const isCurrent = u.id === currentUser?.id;
                        return (
                          <button
                            key={u.id}
                            onClick={() => {
                              switchUser(u.id);
                              setShowSwitchMenu(false);
                            }}
                            className={`w-full px-4 py-2 text-xs flex items-center justify-between hover:bg-slate-100 transition cursor-pointer ${dir === 'rtl' ? 'text-right' : 'text-left'} ${
                              isCurrent ? 'bg-blue-50/70 font-semibold' : ''
                            }`}
                          >
                            <div className="flex items-center space-x-2.5">
                              <div className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[10px] ${u.avatarColor} mx-1 shrink-0`}>
                                {u.fullName.split(' ').map(n => n[0]).join('').slice(0, 2)}
                              </div>
                              <div className="mx-1">
                                <p className="text-slate-900">{u.fullName}</p>
                                <p className="text-slate-500 text-[10px]">{u.email}</p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-1">
                              {u.isLockedOut && (
                                <span title={language === 'ar' ? 'الحساب مقفل' : 'Account Locked'} className="text-red-500 mx-1">
                                  <Lock className="w-3 h-3" />
                                </span>
                              )}
                              <span className={`px-1.5 py-0.5 rounded text-[10px] border ${getRoleBadge(u.role)}`}>
                                {u.role}
                              </span>
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    <div className="pt-2 border-t border-slate-100 px-2 space-y-1">
                      {/* Theme Toggle */}
                      <button
                        onClick={() => {
                          toggleTheme();
                          setShowSwitchMenu(false);
                        }}
                        className="w-full flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-100 transition cursor-pointer"
                      >
                        {theme === 'dark' ? (
                          <Sun className="w-3.5 h-3.5 text-amber-500 mx-1" />
                        ) : (
                          <Moon className="w-3.5 h-3.5 text-slate-500 mx-1" />
                        )}
                        <span>
                          {theme === 'dark' ? (language === 'ar' ? 'المظهر الفاتح' : 'Light Mode') : (language === 'ar' ? 'المظهر الداكن' : 'Dark Mode')}
                        </span>
                      </button>

                      {onOpenDocsExport && (
                        <button
                          onClick={() => {
                            setShowSwitchMenu(false);
                            onOpenDocsExport();
                          }}
                          className="w-full flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium text-blue-700 hover:bg-blue-50 transition cursor-pointer"
                        >
                          <FileText className="w-3.5 h-3.5 text-blue-600 mx-1" />
                          <span>{language === 'ar' ? 'توثيق النظام (Google Docs)' : 'System Docs (Google Docs)'}</span>
                        </button>
                      )}

                      <button
                        onClick={() => {
                          if (currentUser) resetUser2FA(currentUser.id);
                          logout();
                          setShowSwitchMenu(false);
                        }}
                        className="w-full flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium text-amber-700 hover:bg-amber-50 transition cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5 mx-1" />
                        <span>{language === 'ar' ? 'إعادة ضبط 2FA وعرض الباركود' : 'Reset 2FA & View Barcode'}</span>
                      </button>

                      <button
                        onClick={() => {
                          logout();
                          setShowSwitchMenu(false);
                        }}
                        className="w-full flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-bold text-rose-700 hover:bg-rose-50 transition cursor-pointer"
                      >
                        <LogOut className="w-3.5 h-3.5 mx-1" />
                        <span>{t('nav.logout')}</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

          </div>

        </div>
      </div>
    </header>
  );
}
