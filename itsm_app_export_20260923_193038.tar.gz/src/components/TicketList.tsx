import { useState, useMemo } from 'react';
import { useTickets } from '../context/TicketContext';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { Ticket, TicketPriority, TicketStatus, TicketCategory, TicketDepartment, TicketType } from '../types';
import { CATEGORIES, DEPARTMENTS } from '../data/mockData';
import { 
  Search, 
  Filter, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  MessageSquare, 
  Paperclip, 
  User, 
  Flame, 
  Layers, 
  RefreshCw,
  FileSpreadsheet,
  ArrowUpDown,
  Star,
  Wrench,
  Laptop,
  UserPlus,
  PlusCircle,
  Server,
  Image as ImageIcon,
  LayoutDashboard
} from 'lucide-react';

interface TicketListProps {
  onSelectTicket: (ticket: Ticket) => void;
  onOpenCreate: () => void;
  onNavigateToDashboard?: () => void;
}

export function TicketList({ onSelectTicket, onOpenCreate, onNavigateToDashboard }: TicketListProps) {
  const { tickets } = useTickets();
  const { currentUser, isAgent, isOperationalUser } = useAuth();
  const { language, dir } = useLanguage();

  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [quickPreset, setQuickPreset] = useState<'all' | 'my-assigned' | 'my-created' | 'critical' | 'sla-risk'>('all');
  const [sortOrder, setSortOrder] = useState<'newest' | 'priority' | 'sla'>('newest');

  // Filter and sort tickets
  const filteredTickets = useMemo(() => {
    return tickets.filter((ticket) => {
      // Quick preset
      if (quickPreset === 'my-assigned' && ticket.assigneeId !== currentUser?.id) return false;
      if (quickPreset === 'my-created' && ticket.requesterId !== currentUser?.id) return false;
      if (quickPreset === 'critical' && ticket.priority !== 'Critical') return false;
      if (quickPreset === 'sla-risk' && !ticket.isResponseBreached && !ticket.isResolutionBreached) return false;

      // Ticket Type
      if (typeFilter !== 'all' && ticket.ticketType !== typeFilter) return false;

      // Status
      if (statusFilter !== 'all' && ticket.status !== statusFilter) return false;

      // Priority
      if (priorityFilter !== 'all' && ticket.priority !== priorityFilter) return false;

      // Category
      if (categoryFilter !== 'all' && ticket.category !== categoryFilter) return false;

      // Department
      if (departmentFilter !== 'all' && ticket.department !== departmentFilter) return false;

      // Search term
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const matchesId = (ticket.ticketNo || ticket.id).toLowerCase().includes(query);
        const matchesTitle = ticket.title.toLowerCase().includes(query);
        const matchesDesc = ticket.description.toLowerCase().includes(query);
        const matchesRequester = ticket.requesterName.toLowerCase().includes(query);
        const matchesType = (ticket.ticketType || '').toLowerCase().includes(query);
        const matchesTeam = (ticket.assignedTeam || '').toLowerCase().includes(query);
        const matchesSystem = (ticket.targetSystem || '').toLowerCase().includes(query);
        const matchesTags = ticket.tags.some((t) => t.toLowerCase().includes(query));
        if (!matchesId && !matchesTitle && !matchesDesc && !matchesRequester && !matchesTags && !matchesType && !matchesTeam && !matchesSystem) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortOrder === 'priority') {
        const weight: Record<TicketPriority, number> = { Critical: 4, High: 3, Medium: 2, Low: 1 };
        return weight[b.priority] - weight[a.priority];
      }
      if (sortOrder === 'sla') {
        const aDue = new Date(a.resolutionDueAt).getTime();
        const bDue = new Date(b.resolutionDueAt).getTime();
        return aDue - bDue;
      }
      // default newest
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }, [tickets, searchTerm, typeFilter, statusFilter, priorityFilter, categoryFilter, departmentFilter, quickPreset, sortOrder, currentUser]);

  const getPriorityBadge = (priority: TicketPriority) => {
    switch (priority) {
      case 'Critical':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-red-100 text-red-800 border border-red-300">
            <Flame className="w-3 h-3 mx-1 text-red-600 animate-pulse" />
            {language === 'ar' ? 'حرج وعاجل' : 'Critical'}
          </span>
        );
      case 'High':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-orange-100 text-orange-800 border border-orange-300">
            {language === 'ar' ? 'عالي الأولوية' : 'High'}
          </span>
        );
      case 'Medium':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-800 border border-amber-300">
            {language === 'ar' ? 'متوسط' : 'Medium'}
          </span>
        );
      case 'Low':
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-100 text-slate-700 border border-slate-300">
            {language === 'ar' ? 'منخفض' : 'Low'}
          </span>
        );
    }
  };

  const getStatusBadge = (status: TicketStatus) => {
    if (language === 'ar') {
      switch (status) {
        case 'New':
          return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-purple-100 text-purple-800 border border-purple-200">جديدة</span>;
        case 'Open':
          return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-200">مفتوحة</span>;
        case 'In Progress':
          return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-indigo-100 text-indigo-800 border border-indigo-200">قيد المعالجة</span>;
        case 'Pending Customer':
          return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">بانتظار المستخدم</span>;
        case 'Resolved':
          return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">تم الحل</span>;
        case 'Closed':
        default:
          return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">مغلقة</span>;
      }
    }

    switch (status) {
      case 'New':
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-purple-100 text-purple-800 border border-purple-200">New</span>;
      case 'Open':
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-200">Open</span>;
      case 'In Progress':
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-indigo-100 text-indigo-800 border border-indigo-200">In Progress</span>;
      case 'Pending Customer':
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">Pending User</span>;
      case 'Resolved':
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">Resolved</span>;
      case 'Closed':
      default:
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">Closed</span>;
    }
  };

  const getStageBadge = (stage?: string, status?: string) => {
    const val = stage || status || 'New';
    if (language === 'ar') {
      switch (val) {
        case 'New': return 'جديد (New)';
        case 'Triaged': return 'تم الفرز (Triaged)';
        case 'In Progress': return 'قيد المعالجة (In Progress)';
        case 'Pending Review': return 'بانتظار المراجعة (Pending)';
        case 'Resolved': return 'تم الحل (Resolved)';
        case 'Closed': return 'مغلق (Closed)';
        default: return val;
      }
    }
    return val;
  };

  const getTicketTypeLabel = (type?: string) => {
    if (!type) return language === 'ar' ? 'بلاغ دعم فني' : 'Support Ticket';
    if (language === 'ar') {
      switch (type) {
        case 'Hardware Maintenance': return 'صيانة أجهزة ومعدات';
        case 'Systems Troubleshoot': return 'أعطال أنظمة وتشغيل';
        case 'User Request': return 'طلب مستخدم وصلاحيات';
        default: return type;
      }
    }
    return type;
  };

  const getSlaIndicator = (ticket: Ticket) => {
    if (ticket.status === 'Resolved' || ticket.status === 'Closed') {
      return (
        <span className="inline-flex items-center text-xs text-emerald-700 font-medium">
          <CheckCircle2 className="w-3.5 h-3.5 mx-1 text-emerald-600" />
          {language === 'ar' ? 'مكتمل بنجاح' : 'Completed'}
        </span>
      );
    }

    if (ticket.isResolutionBreached || ticket.isResponseBreached) {
      return (
        <span className="inline-flex items-center text-xs text-rose-700 font-bold bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
          <AlertCircle className="w-3.5 h-3.5 mx-1 text-rose-600" />
          {language === 'ar' ? 'تجاوز وقت SLA' : 'SLA Breached'}
        </span>
      );
    }

    const dueMs = new Date(ticket.resolutionDueAt).getTime();
    const remainingHours = Math.max(0, (dueMs - Date.now()) / 3600000);

    if (remainingHours < 2) {
      return (
        <span className="inline-flex items-center text-xs text-amber-800 font-bold bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
          <Clock className="w-3.5 h-3.5 mx-1 text-amber-600 animate-spin" />
          {language === 'ar' 
            ? (remainingHours < 1 ? 'متبقي أقل من ساعة' : `متبقي ${remainingHours.toFixed(1)} ساعة`)
            : (remainingHours < 1 ? '< 1h due' : `${remainingHours.toFixed(1)}h due`)}
        </span>
      );
    }

    return (
      <span className="inline-flex items-center text-xs text-slate-600 font-medium">
        <Clock className="w-3.5 h-3.5 mx-1 text-slate-400" />
        {language === 'ar'
          ? (remainingHours > 24 ? `متبقي ${Math.round(remainingHours / 24)} يوم` : `متبقي ${remainingHours.toFixed(0)} ساعة`)
          : (remainingHours > 24 ? `${Math.round(remainingHours / 24)}d left` : `${remainingHours.toFixed(0)}h left`)}
      </span>
    );
  };

  const exportTicketsJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(filteredTickets, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `pwdsnapp-tickets-${new Date().toISOString().slice(0,10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-4" dir={dir}>
      {/* Preset Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex flex-wrap items-center gap-1.5 text-xs font-medium">
          <span className="text-slate-500 mx-1 flex items-center">
            <Layers className="w-3.5 h-3.5 mx-1 text-slate-400" />
            {language === 'ar' ? 'العروض السريعة:' : 'Views:'}
          </span>
          <button
            onClick={() => setQuickPreset('all')}
            className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
              quickPreset === 'all'
                ? 'bg-slate-900 text-white font-semibold shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {language === 'ar' ? `كافة البلاغات (${tickets.length})` : `All Tickets (${tickets.length})`}
          </button>
          {isAgent && (
            <button
              onClick={() => setQuickPreset('my-assigned')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                quickPreset === 'my-assigned'
                  ? 'bg-blue-700 text-white font-semibold shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {language === 'ar' ? 'المسندة إليّ' : 'Assigned to Me'}
            </button>
          )}
          <button
            onClick={() => setQuickPreset('my-created')}
            className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
              quickPreset === 'my-created'
                ? 'bg-blue-700 text-white font-semibold shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {language === 'ar' ? 'المقدمة بواسطتي' : 'Submitted by Me'}
          </button>
          <button
            onClick={() => setQuickPreset('critical')}
            className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
              quickPreset === 'critical'
                ? 'bg-rose-700 text-white font-semibold shadow-xs'
                : 'text-rose-700 hover:bg-rose-50'
            }`}
          >
            {language === 'ar' ? 'البلاغات الحرجة (3 نجوم)' : 'Critical Incidents'}
          </button>
          <button
            onClick={() => setQuickPreset('sla-risk')}
            className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
              quickPreset === 'sla-risk'
                ? 'bg-amber-600 text-white font-semibold shadow-xs'
                : 'text-amber-700 hover:bg-amber-50'
            }`}
          >
            {language === 'ar' ? 'متجاوزة لـ SLA' : 'SLA Breached'}
          </button>
        </div>

        <div className="flex items-center space-x-2">
          {onNavigateToDashboard && (
            <button
              onClick={onNavigateToDashboard}
              title={language === 'ar' ? 'عرض لوحة تحكم التذاكر ومؤشرات الأداء' : 'View Tickets Dashboard & Performance Metrics'}
              className="flex items-center space-x-1 px-2.5 py-1.5 text-xs text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 transition cursor-pointer mx-1 font-semibold"
            >
              <LayoutDashboard className="w-3.5 h-3.5 text-emerald-600 mx-1" />
              <span className="hidden sm:inline">{language === 'ar' ? 'لوحة تحكم التذاكر' : 'Tickets Dashboard'}</span>
            </button>
          )}

          <button
            onClick={exportTicketsJson}
            title={language === 'ar' ? 'تصدير السجل بتنسيق JSON' : 'Export filtered records to JSON'}
            className="flex items-center space-x-1 px-2.5 py-1.5 text-xs text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-300 transition cursor-pointer mx-1"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-slate-600 mx-1" />
            <span className="hidden sm:inline">{language === 'ar' ? 'تصدير السجل' : 'Export Audit'}</span>
          </button>

          <button
            onClick={onOpenCreate}
            id="ticket-list-btn-create"
            className="flex items-center space-x-1.5 px-3 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-xs transition cursor-pointer mx-1"
          >
            <PlusCircle className="w-4 h-4 mx-1" />
            <span>{language === 'ar' ? 'إنشاء تذكرة جديدة' : 'New Ticket'}</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          
          {/* Search Box */}
          <div className="md:col-span-4 relative">
            <Search className={`w-4 h-4 text-slate-400 absolute top-3 ${dir === 'rtl' ? 'right-3' : 'left-3'}`} />
            <input
              type="text"
              placeholder={language === 'ar' ? 'بحث برقم البلاغ، النوع، الفريق، النظام، العنوان...' : 'Search by ticket #ID, type, team, system, summary...'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={`w-full py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition ${
                dir === 'rtl' ? 'pr-9 pl-4' : 'pl-9 pr-4'
              }`}
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className={`absolute top-2.5 text-slate-400 hover:text-slate-600 text-xs ${dir === 'rtl' ? 'left-3' : 'right-3'}`}
              >
                {language === 'ar' ? 'مسح' : 'Clear'}
              </button>
            )}
          </div>

          {/* Ticket Type Dropdown */}
          <div className="md:col-span-2">
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="w-full py-2 px-2.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500 focus:bg-white cursor-pointer"
            >
              <option value="all">{language === 'ar' ? 'جميع أنواع البلاغات' : 'All Ticket Types'}</option>
              <option value="Hardware Maintenance">{language === 'ar' ? 'صيانة الأجهزة والمعدات' : 'Hardware Maint.'}</option>
              <option value="Systems Troubleshoot">{language === 'ar' ? 'أعطال الأنظمة' : 'Systems Troubleshoot'}</option>
              <option value="User Request">{language === 'ar' ? 'طلبات المستخدمين (IAM)' : 'User Request (IAM)'}</option>
            </select>
          </div>

          {/* Status / Stage Dropdown */}
          <div className="md:col-span-2">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full py-2 px-2.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-800 focus:ring-2 focus:ring-blue-500 focus:bg-white cursor-pointer"
            >
              <option value="all">{language === 'ar' ? 'كافة المراحل والحالات' : 'All Stages & Statuses'}</option>
              <option value="New">{language === 'ar' ? 'جديد (New)' : 'New'}</option>
              <option value="Open">{language === 'ar' ? 'مفتوح (Open)' : 'Open'}</option>
              <option value="In Progress">{language === 'ar' ? 'قيد المعالجة (In Progress)' : 'In Progress'}</option>
              <option value="Pending Customer">{language === 'ar' ? 'بانتظار المستخدم' : 'Pending User'}</option>
              <option value="Resolved">{language === 'ar' ? 'تم الحل (Resolved)' : 'Resolved'}</option>
              <option value="Closed">{language === 'ar' ? 'مغلق (Closed)' : 'Closed'}</option>
            </select>
          </div>

          {/* Priority Dropdown */}
          <div className="md:col-span-2">
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="w-full py-2 px-2.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-800 focus:ring-2 focus:ring-blue-500 focus:bg-white cursor-pointer"
            >
              <option value="all">{language === 'ar' ? 'كافة مستويات الأولوية' : 'All Priorities'}</option>
              <option value="Critical">{language === 'ar' ? '★★★ حرج وعاجل (Sev-1)' : '★★★ Critical (Sev-1)'}</option>
              <option value="High">{language === 'ar' ? '★★★ عالي الأولوية' : '★★★ High'}</option>
              <option value="Medium">{language === 'ar' ? '★★☆ متوسط الأولوية' : '★★☆ Medium'}</option>
              <option value="Low">{language === 'ar' ? '★☆☆ منخفض' : '★☆☆ Low'}</option>
            </select>
          </div>

          {/* Sort By Dropdown */}
          <div className="md:col-span-2">
            <select
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value as any)}
              className="w-full py-2 px-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-800 focus:ring-2 focus:ring-blue-500 focus:bg-white cursor-pointer"
              title="Sort tickets"
            >
              <option value="newest">{language === 'ar' ? 'الترتيب: الأحدث' : 'Sort: Newest'}</option>
              <option value="priority">{language === 'ar' ? 'الترتيب: الأولوية' : 'Sort: Priority'}</option>
              <option value="sla">{language === 'ar' ? 'الترتيب: موعد SLA' : 'Sort: SLA Due'}</option>
            </select>
          </div>

        </div>
      </div>

      {/* Ticket Table / List */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-5 py-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-600 font-semibold uppercase tracking-wider">
          <div className="flex items-center space-x-2">
            <span className="mx-1">{language === 'ar' ? 'قائمة البلاغات والتذاكر' : 'Ticket Queue'}</span>
            <span className="px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 font-mono text-[11px] mx-1">
              {filteredTickets.length}
            </span>
          </div>
          <span className="hidden sm:block text-slate-400 font-normal normal-case">
            {language === 'ar' ? 'انقر على أي بلاغ لعرض تفاصيل المحادثة وسجل التدقيق ومواعيد SLA' : 'Click any ticket row to view conversation, audit history & SLA details'}
          </span>
        </div>

        {filteredTickets.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-3 text-slate-400">
              <Filter className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-slate-800">
              {language === 'ar' ? 'لم يتم العثور على تذاكر مطابقة' : 'No matching tickets found'}
            </h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              {language === 'ar' 
                ? 'جرب تعديل خيارات البحث أو تصفية الفلاتر لعرض مزيد من التذاكر.' 
                : 'Try adjusting your search filters or clearing the search terms to see more tickets.'}
            </p>
            <button
              onClick={() => {
                setSearchTerm('');
                setTypeFilter('all');
                setStatusFilter('all');
                setPriorityFilter('all');
                setCategoryFilter('all');
                setQuickPreset('all');
              }}
              className="mt-4 px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition cursor-pointer"
            >
              {language === 'ar' ? 'إعادة ضبط كافة الفلاتر' : 'Reset all filters'}
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredTickets.map((ticket) => {
              const stars = ticket.priorityStars || (ticket.priority === 'Critical' || ticket.priority === 'High' ? 3 : ticket.priority === 'Medium' ? 2 : 1);

              return (
                <div
                  key={ticket.id}
                  onClick={() => onSelectTicket(ticket)}
                  className="p-4 hover:bg-blue-50/40 transition cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
                >
                  {/* Left info: ID, Priority, Title, Meta */}
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                        #{ticket.ticketNo || ticket.id}
                      </span>

                      {/* Ticket Type Badge */}
                      <span className="inline-flex items-center text-xs font-bold px-2 py-0.5 rounded-full bg-slate-800 text-white">
                        {ticket.ticketType === 'Hardware Maintenance' && <Wrench className="w-3 h-3 mx-1 text-amber-400" />}
                        {ticket.ticketType === 'Systems Troubleshoot' && <Laptop className="w-3 h-3 mx-1 text-blue-400" />}
                        {ticket.ticketType === 'User Request' && <UserPlus className="w-3 h-3 mx-1 text-emerald-400" />}
                        {getTicketTypeLabel(ticket.ticketType)}
                      </span>

                      {/* 3 Yellow Stars Priority Badge */}
                      <div className="inline-flex items-center space-x-0.5 px-1.5 py-0.5 rounded bg-amber-50 border border-amber-200" title={`Priority Level ${stars}`}>
                        {[1, 2, 3].map((starNum) => (
                          <Star
                            key={starNum}
                            className={`w-3 h-3 ${
                              starNum <= stars
                                ? 'fill-amber-400 text-amber-500'
                                : 'text-slate-300'
                            }`}
                          />
                        ))}
                      </div>

                      {/* Stage Badge */}
                      <span className="px-2 py-0.5 rounded text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-200">
                        {getStageBadge(ticket.stage, ticket.status)}
                      </span>

                      {/* Target System if applicable */}
                      {ticket.targetSystem && (
                        <span className="inline-flex items-center text-xs font-medium px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
                          <Server className="w-3 h-3 mx-1 text-indigo-500" />
                          {ticket.targetSystem}
                        </span>
                      )}

                      <span className="text-xs text-slate-400 hidden sm:inline">•</span>
                      <span className="text-xs text-slate-500 hidden sm:inline">
                        {language === 'ar' ? 'الفريق:' : 'Team:'} <strong className="text-slate-700">{ticket.assignedTeam}</strong>
                      </span>
                    </div>

                    <h4 className="text-sm font-semibold text-slate-900 group-hover:text-blue-600 transition truncate">
                      {ticket.title}
                    </h4>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                      <span className="flex items-center">
                        <User className="w-3.5 h-3.5 mx-1 text-slate-400" />
                        {language === 'ar' ? 'مقدم البلاغ:' : 'Requester:'}{' '}
                        <span className="font-medium text-slate-700 mx-1">{ticket.requesterName}</span>
                        {ticket.department && (
                          <span className="mx-1 text-[10px] px-1.5 py-0.2 rounded bg-blue-50 text-blue-700 border border-blue-200 font-medium">
                            {ticket.department}
                          </span>
                        )}
                        {ticket.requesterUserType && (
                          <span className="mx-1 text-[10px] px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-medium">
                            {ticket.requesterUserType === 'Operational User' && language === 'ar' ? 'مستخدم تشغيلي' : ticket.requesterUserType}
                          </span>
                        )}
                      </span>

                      <span className="flex items-center">
                        {language === 'ar' ? 'المكلف:' : 'Assignee:'}{' '}
                        {ticket.assigneeName ? (
                          <span className="font-medium text-slate-800 mx-1 bg-slate-100 px-1.5 py-0.5 rounded text-[11px]">
                            {ticket.assigneeName}
                          </span>
                        ) : (
                          <span className="text-amber-700 font-medium mx-1 bg-amber-50 px-1.5 py-0.5 rounded text-[11px] border border-amber-200">
                            {language === 'ar' ? 'غير مسند' : 'Unassigned'}
                          </span>
                        )}
                      </span>

                      {ticket.comments.length > 0 && (
                        <span className="flex items-center text-slate-500">
                          <MessageSquare className="w-3.5 h-3.5 mx-1 text-slate-400" />
                          {ticket.comments.length}
                        </span>
                      )}

                      {ticket.attachments.length > 0 && (
                        <span className="flex items-center text-slate-500">
                          <ImageIcon className="w-3.5 h-3.5 mx-1 text-blue-500" />
                          {ticket.attachments.length} {language === 'ar' ? 'صور مرفقة' : 'pictures'}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Right side SLA & Timestamp */}
                  <div className="sm:text-right flex sm:flex-col items-center sm:items-end justify-between sm:justify-center border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100 shrink-0">
                    <div>{getSlaIndicator(ticket)}</div>
                    <div className="text-[11px] text-slate-400 mt-1">
                      {language === 'ar' ? 'تاريخ الإنشاء: ' : 'Created '}
                      {new Date(ticket.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                    </div>
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
