import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';
import { auth } from '../lib/firebase';
import { signOut, onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { ApplicationUser } from '../types';
import { INITIAL_USERS } from '../data/mockData';
import { logger } from '../utils/logger';
import { verifyTOTPWithTolerance } from '../utils/totp';
import { apiFetch, safeParseJson, SessionInvalidationEventDetail } from '../utils/api';
import { SessionSecurityModal, SessionSecurityAlert } from '../components/SessionSecurityModal';

export const IDLE_TIMEOUT_DURATION_MS = 15 * 60 * 1000; // 15 minutes
export const IDLE_WARNING_THRESHOLD_MS = 13 * 60 * 1000; // 13 minutes (2 min warning)

interface AuthContextType {
  currentUser: ApplicationUser | null;
  users: ApplicationUser[];
  isAuthenticated: boolean;
  isAdmin: boolean;
  isAgent: boolean;
  isEmployee: boolean;
  isOperationalUser: boolean;
  isOperatorUser: boolean;
  isTechnicalUser: boolean;
  isSystemAdmin: boolean;
  canJoinTeams: boolean;
  canSolveTickets: boolean;
  
  // Login flow
  initiateLogin: (email: string, pass: string) => Promise<{
    success: boolean;
    error?: string;
    isLockedOut?: boolean;
    lockoutMinutes?: number;
    remainingMinutes?: number;
    lockoutCount?: number;
    periodEn?: string;
    periodAr?: string;
    messageEn?: string;
    messageAr?: string;
    failedAccessCount?: number;
    maxAttempts?: number;
    lockoutEnd?: string | null;
  }>;
  verify2FACode: (code: string) => Promise<{ success: boolean; error?: string }>;
  cancelPendingLogin: () => void;
  pendingUser: ApplicationUser | null;
  pending2FASecret: string | null;
  isFirstTime2FA: boolean;
  
  logout: (reason?: string) => Promise<void>;
  changePassword: (newPassword: string, currentPassword?: string) => Promise<{ success: boolean; error?: string }>;
  switchUser: (userId: string) => void;
  resetUser2FA: (userId: string) => void;
  adminCreateUser: (data: any) => Promise<{ success: boolean; error?: string }>;
  adminDeleteUser: (userId: string) => Promise<{ success: boolean; error?: string }>;
  adminUpdateUser: (userId: string, updates: any) => Promise<{ success: boolean; error?: string }>;
  rolesList: any[];
  userPermissions: string[];
  hasPermission: (permission: string) => boolean;
  canAccessTeamManagement: boolean;
  refreshRoles: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<ApplicationUser | null>(null);
  const [users, setUsers] = useState<ApplicationUser[]>(INITIAL_USERS);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);

  // Security Alert Modal State
  const [securityModal, setSecurityModal] = useState<{
    isOpen: boolean;
    type: SessionSecurityAlert['type'];
    messageEn?: string;
    messageAr?: string;
    remainingSeconds?: number;
  }>({
    isOpen: false,
    type: 'IDLE_WARNING'
  });

  // Timers and Activity Tracking Ref
  const lastActivityRef = useRef<number>(Date.now());
  const idleWarningShownRef = useRef<boolean>(false);

  // Sync users list with backend
  const fetchUsers = async () => {
    try {
      const res = await apiFetch('/api/users');
      if (res.ok) {
        const data = await res.json();
        if (data.data && Array.isArray(data.data) && data.data.length > 0) {
          const dbUsers = data.data.map((u: any) => ({
            ...u,
            id: String(u.id ?? u.uid),
            uid: String(u.uid ?? u.id)
          }));
          setUsers(dbUsers);
        }
      }
    } catch (error) {
      console.error("Failed to load users from backend", error);
    }
  };

  const [rolesList, setRolesList] = useState<any[]>([]);

  const fetchRoles = async () => {
    try {
      const res = await apiFetch('/api/roles');
      if (res.ok) {
        const data = await res.json();
        if (data.data && Array.isArray(data.data)) {
          setRolesList(data.data);
        }
      }
    } catch (err) {
      console.warn('Failed to load roles in AuthContext', err);
    }
  };

  // 1. Initial Session Check on App Load
  useEffect(() => {
    fetchUsers();
    fetchRoles();

    const checkLocalSession = async () => {
      const token = localStorage.getItem('auth_token');
      if (token) {
        try {
          const res = await apiFetch('/api/auth/sync', {
            method: 'POST'
          });
          if (res.ok) {
            const data = await res.json();
            if (data.data) {
              setCurrentUser(data.data as ApplicationUser);
              lastActivityRef.current = Date.now();
              await fetchUsers();
              return;
            }
          } else {
            localStorage.removeItem('auth_token');
          }
        } catch (e) {
          console.error('Failed to validate session', e);
        }
      }
      
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        setFirebaseUser(user);
        if (user) {
          try {
            const token = await user.getIdToken();
            const res = await apiFetch('/api/auth/sync', {
              method: 'POST',
              headers: { 'Authorization': `Bearer ${token}` }
            });
            
            if (res.ok) {
              const data = await res.json();
              if (data.data) {
                setCurrentUser(data.data as ApplicationUser);
                lastActivityRef.current = Date.now();
              }
            }
            await fetchUsers();
          } catch (err) {
            console.error('Firebase token resolution error:', err);
          }
        } else {
          if (!localStorage.getItem('auth_token')) {
            setCurrentUser(null);
          }
        }
      });
      return unsubscribe;
    };
    
    let unsub = () => {};
    checkLocalSession().then((ret) => { if (ret) unsub = ret; });
    return () => unsub();
  }, []);

  // 2. Activity Tracking for Idle Timeout
  useEffect(() => {
    if (!currentUser) return;

    const handleUserActivity = () => {
      lastActivityRef.current = Date.now();
      // If idle warning was active, auto-dismiss if user became active again
      if (idleWarningShownRef.current) {
        idleWarningShownRef.current = false;
        setSecurityModal(prev => prev.type === 'IDLE_WARNING' ? { ...prev, isOpen: false } : prev);
      }
    };

    const events = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart', 'click'];
    events.forEach(evt => window.addEventListener(evt, handleUserActivity, { passive: true }));

    return () => {
      events.forEach(evt => window.removeEventListener(evt, handleUserActivity));
    };
  }, [currentUser]);

  // 3. Idle Timeout Interval & Server Heartbeat (Detects Concurrent Logins & Inactivity)
  useEffect(() => {
    if (!currentUser) return;

    // Heartbeat check to server: verifies session status and enforces single computer policy
    const heartbeatInterval = setInterval(async () => {
      try {
        const res = await apiFetch('/api/auth/session-status');
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          if (data.code === 'CONCURRENT_LOGIN') {
            handleSessionInvalidation({
              code: 'CONCURRENT_LOGIN',
              error: data.error || 'Your session was terminated because your account was logged into from another computer.',
              errorAr: data.errorAr || 'تم إنهاء جلستك لتسجيل الدخول إلى حسابك من جهاز حاسوب أو متصفح آخر. يُسمح بجلسة نشطة واحدة فقط.'
            });
          } else if (data.code === 'IDLE_TIMEOUT') {
            handleSessionInvalidation({
              code: 'IDLE_TIMEOUT',
              error: data.error || 'Session timed out due to 15 minutes of inactivity.',
              errorAr: data.errorAr || 'انتهت جلستك بسبب عدم النشاط لمدة 15 دقيقة.'
            });
          } else if (data.code === 'PRIVILEGE_CHANGE' || data.code === 'PASSWORD_CHANGE' || data.code === 'ABSOLUTE_TIMEOUT') {
            handleSessionInvalidation({
              code: data.code,
              error: data.error,
              errorAr: data.errorAr
            });
          }
        }
      } catch (_) {
        // Transient network glitch, will retry next interval
      }
    }, 20000); // 20s heartbeat

    // Local Idle Timer Checker (every 1 second)
    const timerInterval = setInterval(() => {
      const now = Date.now();
      const elapsed = now - lastActivityRef.current;

      // Check if 15 minutes idle timeout reached
      if (elapsed >= IDLE_TIMEOUT_DURATION_MS) {
        handleSessionInvalidation({
          code: 'IDLE_TIMEOUT',
          error: 'Your session has expired due to 15 minutes of inactivity (Idle Timeout). Please log in again.',
          errorAr: 'انتهت جلستك بسبب عدم النشاط لمدة 15 دقيقة (مهلة عدم النشاط). يرجى تسجيل الدخول مجدداً.'
        });
        return;
      }

      // Check if 13 minutes reached: show warning with countdown
      if (elapsed >= IDLE_WARNING_THRESHOLD_MS) {
        const remainingSec = Math.max(0, Math.floor((IDLE_TIMEOUT_DURATION_MS - elapsed) / 1000));
        idleWarningShownRef.current = true;
        setSecurityModal({
          isOpen: true,
          type: 'IDLE_WARNING',
          remainingSeconds: remainingSec,
          messageEn: 'You have been inactive. To safeguard your account, you will be logged out automatically in 2 minutes.',
          messageAr: 'لم يتم رصد أي نشاط منذ فترة. لحماية حسابك، سيتم تسجيل خروجك تلقائياً خلال دقيقتين.'
        });
      }
    }, 1000);

    return () => {
      clearInterval(heartbeatInterval);
      clearInterval(timerInterval);
    };
  }, [currentUser]);

  // 4. Global Event Listener for Session Invalidation
  useEffect(() => {
    const handleInvalidationEvent = (evt: Event) => {
      const customEvent = evt as CustomEvent<SessionInvalidationEventDetail>;
      if (customEvent.detail) {
        handleSessionInvalidation(customEvent.detail);
      }
    };

    window.addEventListener('auth:session_invalidated', handleInvalidationEvent);
    return () => {
      window.removeEventListener('auth:session_invalidated', handleInvalidationEvent);
    };
  }, []);

  const handleSessionInvalidation = (detail: {
    code: string;
    error?: string;
    errorAr?: string;
  }) => {
    // Clear local storage and current user
    localStorage.removeItem('auth_token');
    sessionStorage.removeItem('auth_token');
    setCurrentUser(null);
    setPendingUser(null);

    let modalType: SessionSecurityAlert['type'] = 'IDLE_TIMEOUT';
    if (detail.code === 'CONCURRENT_LOGIN') modalType = 'CONCURRENT_LOGIN';
    else if (detail.code === 'ABSOLUTE_TIMEOUT') modalType = 'ABSOLUTE_TIMEOUT';
    else if (detail.code === 'PRIVILEGE_CHANGE') modalType = 'PRIVILEGE_CHANGE';
    else if (detail.code === 'PASSWORD_CHANGE') modalType = 'PASSWORD_CHANGE';

    setSecurityModal({
      isOpen: true,
      type: modalType,
      messageEn: detail.error,
      messageAr: detail.errorAr
    });
  };

  const [pendingUser, setPendingUser] = useState<ApplicationUser | null>(null);
  const [pending2FASecret, setPending2FASecret] = useState<string | null>(null);
  const [isFirstTime2FA, setIsFirstTime2FA] = useState(false);

  const initiateLogin = async (email: string, pass: string) => {
    try {
      const response = await apiFetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: pass })
      });

      const { ok, data } = await safeParseJson<any>(response);
      
      if (!ok) {
        return {
          success: false,
          error: data?.error || 'Invalid username or password.',
          isLockedOut: !!data?.isLockedOut,
          lockoutMinutes: data?.lockoutMinutes,
          remainingMinutes: data?.remainingMinutes,
          lockoutCount: data?.lockoutCount,
          periodEn: data?.periodEn,
          periodAr: data?.periodAr,
          messageEn: data?.messageEn,
          messageAr: data?.messageAr,
          failedAccessCount: data?.failedAccessCount,
          maxAttempts: data?.maxAttempts,
          lockoutEnd: data?.lockoutEnd
        };
      }

      // Handle 2FA logic
      if (data.requires2FA || (data.user && data.user.twoFactorEnabled)) {
        setPendingUser(data.user);
        setIsFirstTime2FA(!!data.isFirstTime2FA);
        setPending2FASecret(data.twoFactorSecret || data.user.twoFactorSecret || null);
        return { success: true };
      }
      
      // Store JWT in local storage for fallback authorization header
      if (data.token) {
        localStorage.setItem('auth_token', data.token);
      }
      lastActivityRef.current = Date.now();
      setCurrentUser(data.user);
      return { success: true };
    } catch (error: any) {
      console.error("Login failed", error);
      return { success: false, error: error?.message || "An unexpected network error occurred." };
    }
  };

  const verify2FACode = async (code: string): Promise<{ success: boolean; error?: string }> => {
    if (!pendingUser) {
      return { success: false, error: 'No pending authentication session.' };
    }

    const cleanCode = code.trim().replace(/\s+/g, '');
    if (!/^\d{6}$/.test(cleanCode)) {
      return { success: false, error: 'Please enter a valid 6-digit code from your authenticator app.' };
    }

    try {
      const response = await apiFetch('/api/auth/verify-2fa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: pendingUser.email,
          code: cleanCode,
          secret: pending2FASecret
        })
      });

      const { ok, data } = await safeParseJson<any>(response);

      if (!ok || !data.success) {
        return {
          success: false,
          error: data?.error || 'Invalid authenticator code. Please check your authenticator app and try again.'
        };
      }

      // Store authenticated session
      if (data.token) {
        localStorage.setItem('auth_token', data.token);
      }

      lastActivityRef.current = Date.now();
      setCurrentUser(data.user || pendingUser);
      setPendingUser(null);
      setPending2FASecret(null);
      setIsFirstTime2FA(false);

      if (data.user) {
        setUsers(prev => prev.map(u => u.email.toLowerCase() === data.user.email.toLowerCase() ? data.user : u));
      }

      return { success: true };
    } catch (err: any) {
      const secretToTest = pending2FASecret || pendingUser.twoFactorSecret;
      if (!secretToTest) {
        return { success: false, error: 'No 2FA secret found for this account.' };
      }

      const verification = verifyTOTPWithTolerance(cleanCode, secretToTest, 60, 30);
      if (!verification.valid) {
        return {
          success: false,
          error: 'Invalid authenticator code. Please check your authenticator app and try again.'
        };
      }

      const updatedUser = {
        ...pendingUser,
        twoFactorSecret: secretToTest,
        twoFactorEnabled: true
      };

      lastActivityRef.current = Date.now();
      setCurrentUser(updatedUser);
      setPendingUser(null);
      setPending2FASecret(null);
      setIsFirstTime2FA(false);
      setUsers(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));

      return { success: true };
    }
  };

  const cancelPendingLogin = () => {
    setPendingUser(null);
    setPending2FASecret(null);
    localStorage.removeItem('auth_token');
    try {
      signOut(auth);
    } catch (_) {}
  };

  /**
   * Explicitly destroy session on server and clear tokens
   */
  const logout = async (reason?: string) => {
    try {
      // 1. Explicitly inform server to destroy session record and clear HttpOnly cookie
      await apiFetch('/api/auth/logout', { method: 'POST' }).catch(() => {});

      // 2. Clear client storage
      localStorage.removeItem('auth_token');
      sessionStorage.removeItem('auth_token');

      // 3. Sign out from Firebase if present
      try {
        await signOut(auth);
      } catch (err) {
        console.warn("Firebase signOut error:", err);
      }

      // 4. Clear all React state
      setCurrentUser(null);
      setFirebaseUser(null);
      setPendingUser(null);
      setPending2FASecret(null);
      setIsFirstTime2FA(false);

      logger.information('User logged out successfully ({Reason})', { Reason: reason || 'ManualLogout' });
    } catch (error) {
      console.error("Error during logout:", error);
      localStorage.removeItem('auth_token');
      sessionStorage.removeItem('auth_token');
      setCurrentUser(null);
    }
  };

  /**
   * Change password: sends request to server, which invalidates all active sessions
   * and creates a fresh session for this device.
   */
  const changePassword = async (newPassword: string, currentPassword?: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await apiFetch('/api/auth/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPassword, currentPassword })
      });

      const { ok, data } = await safeParseJson<any>(res);
      if (!ok || !data?.success) {
        return { success: false, error: data?.error || 'Failed to update password.' };
      }

      if (data.token) {
        localStorage.setItem('auth_token', data.token);
      }

      if (data.user) {
        setCurrentUser(prev => prev ? { ...prev, ...data.user, mustChangePassword: false } : data.user);
      }

      lastActivityRef.current = Date.now();
      logger.information('Password successfully updated and session refreshed.');
      return { success: true };
    } catch (e: any) {
      return { success: false, error: e.message || 'An unexpected error occurred.' };
    }
  };

  const switchUser = (userId: string) => {
    const target = users.find((u) => u.id === userId) || INITIAL_USERS.find((u) => u.id === userId);
    if (target) {
      setCurrentUser(target);
      lastActivityRef.current = Date.now();
      logger.information('Switched active user to {UserEmail} ({Role})', {
        UserEmail: target.email,
        Role: target.role,
      });
    }
  };

  const resetUser2FA = async (userId: string) => {
    try {
      await apiFetch('/api/auth/reset-2fa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId })
      });
    } catch (e) {
      console.warn("Backend reset 2FA call error:", e);
    }
    setUsers((prev) =>
      prev.map((u) => (u.id === userId || u.uid === userId ? { ...u, twoFactorSecret: undefined } : u))
    );
    if (currentUser?.id === userId || currentUser?.uid === userId) {
      setCurrentUser((prev) => (prev ? { ...prev, twoFactorSecret: undefined } : null));
    }
    logger.information('Reset 2FA credentials for user {UserId}', { UserId: userId });
  };

  const adminCreateUser = async (data: any) => {
    try {
      const res = await apiFetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (res.ok) {
        await fetchUsers();
        return { success: true };
      }
      const err = await res.json();
      return { success: false, error: err.error || 'Failed' };
    } catch (error: any) {
      return { success: false, error: error.message || 'Failed' };
    }
  };

  const adminDeleteUser = async (userId: string) => {
    try {
      const res = await apiFetch(`/api/users/${userId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        await fetchUsers();
        return { success: true };
      }
      return { success: false, error: 'Failed' };
    } catch (error) {
      return { success: false, error: 'Failed' };
    }
  };

  const adminUpdateUser = async (userId: string, updates: any) => {
    try {
      const res = await apiFetch(`/api/users/${userId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.success) {
        const updatedUser = data.data;
        setUsers(prev => prev.map(u => {
          if (String(u.id) === String(userId) || u.uid === userId || (updatedUser && (String(u.id) === String(updatedUser.id) || u.email === updatedUser.email))) {
            return { ...u, ...updates, ...(updatedUser || {}) };
          }
          return u;
        }));
        if (currentUser && (String(currentUser.id) === String(userId) || currentUser.uid === userId || (updatedUser && currentUser.email === updatedUser.email))) {
          const newCurrent = { ...currentUser, ...updates, ...(updatedUser || {}) };
          setCurrentUser(newCurrent);
          try {
            localStorage.setItem('auth_user_cache', JSON.stringify(newCurrent));
          } catch (_) {}
        }
        await fetchUsers();
        return { success: true };
      }
      return { success: false, error: data?.error || 'Failed to update user' };
    } catch (error: any) {
      return { success: false, error: error.message || 'Failed to update user' };
    }
  };

  const isAdmin = currentUser?.role === 'Admin' || currentUser?.role === 'Administrator' || currentUser?.userType === 'System Admin';
  const isAgent = currentUser?.role === 'Agent' || currentUser?.role === 'Helpdesk Agent' || currentUser?.userType === 'Technical' || currentUser?.userType === 'Technical User' || isAdmin;
  const isEmployee = currentUser?.role === 'Employee' || isAgent;
  const isTechnicalUser = currentUser?.userType === 'Technical' || currentUser?.userType === 'Technical User' || currentUser?.role === 'Agent' || currentUser?.role === 'Helpdesk Agent' || isAdmin;
  const isOperatorUser = currentUser?.userType === 'Operator' || currentUser?.userType === 'Operational User' || (!isTechnicalUser && !isAdmin);
  const isOperationalUser = isOperatorUser;
  const isSystemAdmin = currentUser?.userType === 'System Admin' || currentUser?.role === 'Admin' || currentUser?.role === 'Administrator';

  // Technical users can join tickets teams and solve tickets. Operators cannot join teams or solve tickets.
  const canJoinTeams = isTechnicalUser;
  const canSolveTickets = isTechnicalUser;

  // Compute active user permissions from their assigned role in rolesList
  const userRoleObj = rolesList.find(r => r.name?.toLowerCase() === currentUser?.role?.toLowerCase());
  const userPermissions: string[] = userRoleObj?.permissions || [];

  const hasPermission = (permission: string): boolean => {
    if (!currentUser) return false;
    // Admins have full access
    if (isAdmin) return true;

    if (userPermissions.includes('*') || userPermissions.includes(permission)) {
      return true;
    }

    // Dynamic Team Management permission resolution
    if (permission.startsWith('Team Management')) {
      const action = permission.split('.')[1] || 'View';
      if (userPermissions.includes(`Team Management.${action}`)) return true;
      if (userPermissions.includes('Team Management.*') || userPermissions.includes('Team Management')) return true;
      if (action === 'View' && (
        userPermissions.includes('tickets.manage') || 
        userPermissions.includes('teams.manage') || 
        userPermissions.includes('tickets.read')
      )) {
        return true;
      }
      if ((action === 'Create' || action === 'Edit' || action === 'Delete') && (
        userPermissions.includes('tickets.manage') || 
        userPermissions.includes('teams.manage')
      )) {
        return true;
      }
    }

    return false;
  };

  const canAccessTeamManagement = hasPermission('Team Management.View');

  const handleStayLoggedIn = async () => {
    lastActivityRef.current = Date.now();
    idleWarningShownRef.current = false;
    setSecurityModal(prev => ({ ...prev, isOpen: false }));
    // Touch server session
    await apiFetch('/api/auth/session-status').catch(() => {});
  };

  const handleConfirmSecurityRelogin = () => {
    setSecurityModal(prev => ({ ...prev, isOpen: false }));
    logout('security_relogin_confirmed');
  };

  return (
    <AuthContext.Provider value={{
      currentUser, users, isAuthenticated: !!currentUser, isAdmin, isAgent, isEmployee,
      isOperationalUser, isOperatorUser, isTechnicalUser, isSystemAdmin,
      canJoinTeams, canSolveTickets,
      rolesList, userPermissions, hasPermission, canAccessTeamManagement, refreshRoles: fetchRoles,
      initiateLogin, logout, changePassword, switchUser, resetUser2FA,
      adminCreateUser, adminDeleteUser, adminUpdateUser,
      verify2FACode, cancelPendingLogin, pendingUser, pending2FASecret, isFirstTime2FA
    }}>
      {children}

      {/* Global Enterprise Session Security & Inactivity Alert Modal */}
      <SessionSecurityModal
        isOpen={securityModal.isOpen}
        type={securityModal.type}
        messageEn={securityModal.messageEn}
        messageAr={securityModal.messageAr}
        remainingSeconds={securityModal.remainingSeconds}
        onStayLoggedIn={handleStayLoggedIn}
        onConfirm={handleConfirmSecurityRelogin}
      />
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be within provider");
  return context;
};
