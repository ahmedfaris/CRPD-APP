import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { ElectronicDevice, DeviceMaintenanceItem, DeviceDepartmentHistoryItem } from '../types';
import { INITIAL_DEVICES } from '../data/mockDevices';

interface DeviceFilters {
  category?: string;
  type?: string;
  search?: string;
  department?: string;
}

interface DeviceContextType {
  devices: ElectronicDevice[];
  loading: boolean;
  error: string | null;
  fetchDevices: (filters?: DeviceFilters) => Promise<void>;
  addDevice: (device: Partial<ElectronicDevice>) => Promise<{ success: boolean; data?: ElectronicDevice; error?: string }>;
  updateDevice: (id: string | number, device: Partial<ElectronicDevice>) => Promise<{ success: boolean; data?: ElectronicDevice; error?: string }>;
  transferDepartment: (id: string | number, newDepartment: string, reason?: string, newDepartmentAr?: string) => Promise<{ success: boolean; error?: string }>;
  addMaintenanceRecord: (id: string | number, record: Omit<DeviceMaintenanceItem, 'id'>) => Promise<{ success: boolean; error?: string }>;
  deleteDevice: (id: string | number) => Promise<{ success: boolean; error?: string }>;
}

const DeviceContext = createContext<DeviceContextType | undefined>(undefined);

// Helper to calculate warranty expiration date and whether it's still active
export function calculateWarranty(startDateStr: string, periodStr: string): { expiryDate: string; isActive: boolean; months: number } {
  try {
    const start = new Date(startDateStr);
    if (isNaN(start.getTime())) {
      return { expiryDate: startDateStr, isActive: false, months: 12 };
    }

    let months = 12;
    const lower = (periodStr || '').toLowerCase();
    const numMatch = lower.match(/\d+/);
    const num = numMatch ? parseInt(numMatch[0], 10) : 12;

    if (lower.includes('year') || lower.includes('سنة') || lower.includes('سنوات')) {
      months = num * 12;
    } else if (lower.includes('month') || lower.includes('شهر') || lower.includes('شهور')) {
      months = num;
    } else {
      months = num;
    }

    const expiry = new Date(start);
    expiry.setMonth(expiry.getMonth() + months);

    const now = new Date();
    const isActive = expiry.getTime() > now.getTime();

    return {
      expiryDate: expiry.toISOString().split('T')[0],
      isActive,
      months
    };
  } catch {
    return { expiryDate: startDateStr, isActive: false, months: 12 };
  }
}

export function DeviceProvider({ children }: { children: ReactNode }) {
  const [devices, setDevices] = useState<ElectronicDevice[]>(() => {
    try {
      const saved = localStorage.getItem('crpd_electronic_devices_v1');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {}
    return INITIAL_DEVICES;
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const saveToStorage = (updated: ElectronicDevice[]) => {
    try {
      localStorage.setItem('crpd_electronic_devices_v1', JSON.stringify(updated));
    } catch {}
  };

  const enrichDevice = (dev: any): ElectronicDevice => {
    const warrantyInfo = calculateWarranty(dev.warrantyStartDate || dev.dateOfPurchase, dev.warrantyPeriod || '24 Months');
    return {
      ...dev,
      id: String(dev.id),
      warrantyExpiryDate: warrantyInfo.expiryDate,
      isWarrantyActive: warrantyInfo.isActive,
      warrantyPeriodMonths: warrantyInfo.months,
      departmentHistory: Array.isArray(dev.departmentHistory) 
        ? dev.departmentHistory 
        : (typeof dev.departmentHistory === 'string' ? JSON.parse(dev.departmentHistory) : []),
      maintenanceHistory: Array.isArray(dev.maintenanceHistory) 
        ? dev.maintenanceHistory 
        : (typeof dev.maintenanceHistory === 'string' ? JSON.parse(dev.maintenanceHistory) : []),
    };
  };

  const fetchDevices = useCallback(async (filters?: DeviceFilters) => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('auth_token');
      const params = new URLSearchParams();
      if (filters?.category && filters.category !== 'ALL') params.append('category', filters.category);
      if (filters?.type && filters.type !== 'ALL') params.append('type', filters.type);
      if (filters?.department && filters.department !== 'ALL') params.append('department', filters.department);
      if (filters?.search) params.append('search', filters.search);

      const url = `/api/devices${params.toString() ? `?${params.toString()}` : ''}`;
      const res = await fetch(url, {
        headers: token ? { 'Authorization': `Bearer ${token}` } : {}
      });

      if (res.ok) {
        const json = await res.json();
        if (json.success && Array.isArray(json.data)) {
          const enriched = json.data.map(enrichDevice);
          setDevices(enriched);
          saveToStorage(enriched);
          setLoading(false);
          return;
        }
      }
    } catch (e: any) {
      console.warn('API fetchDevices offline, fallback to local state:', e.message);
    }

    // Local fallback filter if backend failed
    setDevices(prev => {
      let filtered = [...prev];
      if (filters?.category && filters.category !== 'ALL') {
        filtered = filtered.filter(d => d.category.toLowerCase() === filters.category?.toLowerCase());
      }
      if (filters?.type && filters.type !== 'ALL') {
        filtered = filtered.filter(d => d.deviceType.toLowerCase() === filters.type?.toLowerCase());
      }
      if (filters?.department && filters.department !== 'ALL') {
        filtered = filtered.filter(d => d.department.toLowerCase() === filters.department?.toLowerCase());
      }
      if (filters?.search) {
        const q = filters.search.toLowerCase();
        filtered = filtered.filter(d => 
          d.deviceCode.toLowerCase().includes(q) ||
          d.brand.toLowerCase().includes(q) ||
          d.model.toLowerCase().includes(q) ||
          (d.serialNumber && d.serialNumber.toLowerCase().includes(q)) ||
          d.department.toLowerCase().includes(q)
        );
      }
      return filtered;
    });
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchDevices();
  }, [fetchDevices]);

  const addDevice = async (deviceData: Partial<ElectronicDevice>): Promise<{ success: boolean; data?: ElectronicDevice; error?: string }> => {
    const token = localStorage.getItem('auth_token');
    try {
      const res = await fetch('/api/devices', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(deviceData)
      });

      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          const enriched = enrichDevice(json.data);
          setDevices(prev => {
            const next = [enriched, ...prev.filter(d => d.id !== enriched.id)];
            saveToStorage(next);
            return next;
          });
          return { success: true, data: enriched };
        }
      }
    } catch (e: any) {
      console.warn('Backend addDevice failed, applying local fallback:', e.message);
    }

    // Local fallback creation
    const year = new Date().getFullYear();
    const randomSeq = Math.floor(100 + Math.random() * 900);
    const code = deviceData.deviceCode || `DEV-${year}-${randomSeq}`;
    const newDev: ElectronicDevice = enrichDevice({
      id: 'local_' + Date.now(),
      deviceCode: code,
      category: deviceData.category || 'electronic',
      deviceType: deviceData.deviceType || 'Computer',
      brand: deviceData.brand || 'Standard',
      model: deviceData.model || 'Model',
      serialNumber: deviceData.serialNumber || '',
      dateOfPurchase: deviceData.dateOfPurchase || new Date().toISOString().split('T')[0],
      warrantyStartDate: deviceData.warrantyStartDate || deviceData.dateOfPurchase || new Date().toISOString().split('T')[0],
      warrantyPeriod: deviceData.warrantyPeriod || '24 Months',
      department: deviceData.department || 'Information Technology',
      departmentAr: deviceData.departmentAr || '',
      status: deviceData.status || 'Operational',
      ipAddress: deviceData.ipAddress || '',
      macAddress: deviceData.macAddress || '',
      location: deviceData.location || '',
      assignedEmployee: deviceData.assignedEmployee || '',
      departmentHistory: deviceData.departmentHistory || [],
      maintenanceHistory: deviceData.maintenanceHistory || [],
      notes: deviceData.notes || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    setDevices(prev => {
      const next = [newDev, ...prev];
      saveToStorage(next);
      return next;
    });

    return { success: true, data: newDev };
  };

  const updateDevice = async (id: string | number, deviceData: Partial<ElectronicDevice>): Promise<{ success: boolean; data?: ElectronicDevice; error?: string }> => {
    const token = localStorage.getItem('auth_token');
    try {
      const res = await fetch(`/api/devices/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(deviceData)
      });

      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          const enriched = enrichDevice(json.data);
          setDevices(prev => {
            const next = prev.map(d => d.id === String(id) ? enriched : d);
            saveToStorage(next);
            return next;
          });
          return { success: true, data: enriched };
        }
      }
    } catch (e: any) {
      console.warn('Backend updateDevice failed, applying local fallback:', e.message);
    }

    setDevices(prev => {
      const next = prev.map(d => {
        if (d.id === String(id)) {
          return enrichDevice({ ...d, ...deviceData, updatedAt: new Date().toISOString() });
        }
        return d;
      });
      saveToStorage(next);
      return next;
    });

    return { success: true };
  };

  const transferDepartment = async (id: string | number, newDepartment: string, reason?: string, newDepartmentAr?: string): Promise<{ success: boolean; error?: string }> => {
    const token = localStorage.getItem('auth_token');
    try {
      const res = await fetch(`/api/devices/${id}/transfer`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify({ newDepartment, newDepartmentAr, reason })
      });

      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          const enriched = enrichDevice(json.data);
          setDevices(prev => {
            const next = prev.map(d => d.id === String(id) ? enriched : d);
            saveToStorage(next);
            return next;
          });
          return { success: true };
        }
      }
    } catch (e: any) {
      console.warn('Backend transfer failed, applying local fallback:', e.message);
    }

    // Local fallback
    setDevices(prev => {
      const next = prev.map(d => {
        if (d.id === String(id)) {
          const historyItem: DeviceDepartmentHistoryItem = {
            id: 'dh-' + Date.now(),
            department: d.department,
            departmentAr: d.departmentAr || d.department,
            assignedDate: d.dateOfPurchase,
            transferredDate: new Date().toISOString().split('T')[0],
            transferredBy: 'Current User',
            reason: reason || 'Departmental transfer'
          };
          return {
            ...d,
            department: newDepartment,
            departmentAr: newDepartmentAr || d.departmentAr,
            departmentHistory: [...d.departmentHistory, historyItem],
            updatedAt: new Date().toISOString()
          };
        }
        return d;
      });
      saveToStorage(next);
      return next;
    });

    return { success: true };
  };

  const addMaintenanceRecord = async (id: string | number, record: Omit<DeviceMaintenanceItem, 'id'>): Promise<{ success: boolean; error?: string }> => {
    const token = localStorage.getItem('auth_token');
    try {
      const res = await fetch(`/api/devices/${id}/maintenance`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(record)
      });

      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          const enriched = enrichDevice(json.data);
          setDevices(prev => {
            const next = prev.map(d => d.id === String(id) ? enriched : d);
            saveToStorage(next);
            return next;
          });
          return { success: true };
        }
      }
    } catch (e: any) {
      console.warn('Backend maintenance failed, applying local fallback:', e.message);
    }

    // Local fallback
    setDevices(prev => {
      const next = prev.map(d => {
        if (d.id === String(id)) {
          const newRecord: DeviceMaintenanceItem = {
            ...record,
            id: 'mh-' + Date.now()
          };
          return {
            ...d,
            maintenanceHistory: [...d.maintenanceHistory, newRecord],
            status: record.status === 'In Progress' ? 'Under Maintenance' : d.status,
            updatedAt: new Date().toISOString()
          };
        }
        return d;
      });
      saveToStorage(next);
      return next;
    });

    return { success: true };
  };

  const deleteDevice = async (id: string | number): Promise<{ success: boolean; error?: string }> => {
    const token = localStorage.getItem('auth_token');
    try {
      const res = await fetch(`/api/devices/${id}`, {
        method: 'DELETE',
        headers: token ? { 'Authorization': `Bearer ${token}` } : {}
      });

      if (res.ok) {
        setDevices(prev => {
          const next = prev.filter(d => d.id !== String(id));
          saveToStorage(next);
          return next;
        });
        return { success: true };
      }
    } catch (e: any) {
      console.warn('Backend delete failed, applying local fallback:', e.message);
    }

    setDevices(prev => {
      const next = prev.filter(d => d.id !== String(id));
      saveToStorage(next);
      return next;
    });

    return { success: true };
  };

  return (
    <DeviceContext.Provider value={{
      devices,
      loading,
      error,
      fetchDevices,
      addDevice,
      updateDevice,
      transferDepartment,
      addMaintenanceRecord,
      deleteDevice
    }}>
      {children}
    </DeviceContext.Provider>
  );
}

export function useDevices() {
  const context = useContext(DeviceContext);
  if (context === undefined) {
    throw new Error('useDevices must be used within a DeviceProvider');
  }
  return context;
}
