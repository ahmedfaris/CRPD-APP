import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface TreeNode {
  id: string;
  nameEn: string;
  nameAr: string;
  type: 'org' | 'directorate' | 'department' | 'division';
  children: TreeNode[];
  managerId?: string | null;
  dbId?: number;
  parentId?: number | null;
}

export interface OrgDepartmentItem {
  id: string;
  dbId?: number;
  nameEn: string;
  nameAr: string;
  type: string;
}

interface OrgContextType {
  orgData: TreeNode[];
  setOrgData: (data: TreeNode[]) => void;
  getAllDepartments: () => OrgDepartmentItem[];
  fetchOrgData: () => Promise<void>;
  saveNode: (node: TreeNode, parentId?: string | number | null) => Promise<any>;
  deleteNode: (node: TreeNode) => Promise<any>;
}

const OrgContext = createContext<OrgContextType | undefined>(undefined);

export function OrgProvider({ children }: { children: ReactNode }) {
  const [orgData, setOrgData] = useState<TreeNode[]>([]);

  const buildTree = (flatList: any[]) => {
    const nodeMap = new Map();
    const roots: TreeNode[] = [];

    // First pass
    flatList.forEach(item => {
      nodeMap.set(item.id, {
        id: `db_${item.id}`,
        dbId: item.id,
        parentId: item.parentId || null,
        nameEn: item.nameEn || item.name,
        nameAr: item.nameAr || item.name,
        type: item.orgType as any || 'department',
        managerId: item.managerId,
        children: []
      });
    });

    // Second pass
    flatList.forEach(item => {
      const node = nodeMap.get(item.id);
      if (item.parentId) {
        const parent = nodeMap.get(item.parentId);
        if (parent) {
          parent.children.push(node);
        } else {
          roots.push(node); // Parent missing
        }
      } else {
        roots.push(node);
      }
    });

    return roots;
  };

  const fetchOrgData = async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const headers: Record<string, string> = {};
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      const res = await fetch('/api/departments', { headers });
      if (res.ok) {
        const json = await res.json();
        if (json.success && Array.isArray(json.data) && json.data.length > 0) {
          setOrgData(buildTree(json.data));
        }
      }
    } catch (e) {
      console.error('Failed to fetch org structure', e);
    }
  };

  const saveNode = async (node: TreeNode, parentId?: string | number | null) => {
    try {
      const token = localStorage.getItem('auth_token');
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;
      
      const payload: any = {
        nameEn: node.nameEn,
        nameAr: node.nameAr,
        orgType: node.type,
        managerId: node.managerId || null
      };

      if (parentId !== undefined) {
        if (typeof parentId === 'string' && parentId.startsWith('db_')) {
          payload.parentId = parseInt(parentId.replace('db_', ''), 10);
        } else if (typeof parentId === 'number') {
          payload.parentId = parentId;
        } else if (parentId === null || parentId === '') {
          payload.parentId = null;
        }
      } else if (node.parentId !== undefined) {
        payload.parentId = node.parentId;
      }

      let res;
      if (node.dbId) {
        // Update
        res = await fetch(`/api/departments/${node.dbId}`, {
          method: 'PUT',
          headers,
          body: JSON.stringify(payload)
        });
      } else {
        // Create
        res = await fetch('/api/departments', {
          method: 'POST',
          headers,
          body: JSON.stringify(payload)
        });
      }

      const data = await res.json();
      if (data.success) {
        await fetchOrgData();
        return { success: true, data: data.data };
      }
      return data;
    } catch (e) {
      return { success: false, error: 'Network error' };
    }
  };

  const deleteNode = async (node: TreeNode) => {
    if (!node.dbId) return { success: true }; // Not saved in DB yet
    try {
      const token = localStorage.getItem('auth_token');
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;
      
      const res = await fetch(`/api/departments/${node.dbId}`, {
        method: 'DELETE',
        headers
      });
      const data = await res.json();
      if (data.success) {
        await fetchOrgData();
        return { success: true };
      }
      return data;
    } catch (e) {
      return { success: false, error: 'Network error' };
    }
  };

  useEffect(() => {
    fetchOrgData();
  }, []);

  const getAllDepartments = (): OrgDepartmentItem[] => {
    const depts: OrgDepartmentItem[] = [];
    const seenNames = new Set<string>();

    const traverse = (node: TreeNode) => {
      const nameKey = (node.nameEn || node.nameAr || '').trim().toLowerCase();
      if (nameKey && !seenNames.has(nameKey)) {
        seenNames.add(nameKey);
        depts.push({
          id: node.id,
          dbId: node.dbId,
          nameEn: node.nameEn || '',
          nameAr: node.nameAr || node.nameEn || '',
          type: node.type || 'department',
        });
      }
      if (Array.isArray(node.children)) {
        node.children.forEach(traverse);
      }
    };

    orgData.forEach(traverse);

    // Fallback if orgData has not finished loading from backend yet
    if (depts.length === 0) {
      return [
        { id: 'dept_it', dbId: 1, nameEn: 'Information Technology', nameAr: 'تكنولوجيا المعلومات', type: 'department' },
        { id: 'dept_ops', dbId: 2, nameEn: 'Operations', nameAr: 'العمليات والتنفيذ', type: 'department' },
        { id: 'dept_arch', dbId: 3, nameEn: 'Electronic Archiving & Records', nameAr: 'الأرشفة الإلكترونية والسجلات', type: 'department' },
        { id: 'dept_help', dbId: 4, nameEn: 'Customer Support & Helpdesk', nameAr: 'دعم العملاء ومكتب المساعدة', type: 'department' },
        { id: 'dept_hr', dbId: 5, nameEn: 'Human Resources', nameAr: 'الموارد البشرية', type: 'department' },
      ];
    }
    return depts;
  };

  return (
    <OrgContext.Provider value={{ orgData, setOrgData, getAllDepartments, fetchOrgData, saveNode, deleteNode }}>
      {children}
    </OrgContext.Provider>
  );
}

export function useOrg() {
  const context = useContext(OrgContext);
  if (context === undefined) {
    throw new Error('useOrg must be used within an OrgProvider');
  }
  return context;
}
