// src/server/db/initTicketTables.ts
import { createPool } from '../../db/index.ts';

export async function initTicketTables(): Promise<void> {
  const pool = createPool();

  try {
    const client = await pool.connect();
    try {
      // 1. Ensure core tables exist
      await client.query(`
        -- Departments Table
        CREATE TABLE IF NOT EXISTS departments (
          id SERIAL PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT,
          parent_id INTEGER,
          manager_id TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Users Table
        CREATE TABLE IF NOT EXISTS users (
          id SERIAL PRIMARY KEY,
          uid TEXT NOT NULL UNIQUE,
          user_name TEXT,
          email TEXT NOT NULL,
          email_confirmed BOOLEAN DEFAULT FALSE,
          full_name TEXT NOT NULL,
          department TEXT,
          job_title TEXT,
          role TEXT NOT NULL DEFAULT 'Employee',
          user_type TEXT DEFAULT 'Operational User',
          failed_access_count INTEGER DEFAULT 0,
          lockout_end TEXT,
          is_locked_out BOOLEAN DEFAULT FALSE,
          lockout_count INTEGER DEFAULT 0,
          must_change_password BOOLEAN DEFAULT FALSE,
          two_factor_enabled BOOLEAN DEFAULT FALSE,
          two_factor_secret TEXT,
          password_hash TEXT,
          password_min_length INTEGER DEFAULT 8,
          password_require_special BOOLEAN DEFAULT FALSE,
          password_require_number BOOLEAN DEFAULT FALSE,
          password_require_uppercase BOOLEAN DEFAULT FALSE,
          password_require_lowercase BOOLEAN DEFAULT FALSE,
          password_last_changed_at TIMESTAMP,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          last_active_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          avatar_color TEXT,
          phone TEXT
        );

        -- Roles Table
        CREATE TABLE IF NOT EXISTS roles (
          id SERIAL PRIMARY KEY,
          name TEXT NOT NULL UNIQUE,
          permissions TEXT[] NOT NULL DEFAULT '{}',
          created_by TEXT,
          is_deleted BOOLEAN DEFAULT FALSE,
          deleted_at TIMESTAMP,
          deleted_by TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Role Audit Logs Table
        CREATE TABLE IF NOT EXISTS role_audit_logs (
          id SERIAL PRIMARY KEY,
          role_id INTEGER NOT NULL,
          action TEXT NOT NULL,
          performed_by TEXT NOT NULL,
          details TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- User Sessions Table
        CREATE TABLE IF NOT EXISTS user_sessions (
          id SERIAL PRIMARY KEY,
          session_id TEXT NOT NULL UNIQUE,
          user_uid TEXT NOT NULL,
          user_email TEXT NOT NULL,
          device_info TEXT,
          ip_address TEXT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          last_activity_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
          is_active BOOLEAN DEFAULT TRUE,
          invalidation_reason TEXT
        );

        -- Tickets Table
        CREATE TABLE IF NOT EXISTS tickets (
          id SERIAL PRIMARY KEY,
          ticket_no TEXT,
          title TEXT NOT NULL,
          description TEXT NOT NULL,
          ticket_type TEXT NOT NULL DEFAULT 'Hardware Maintenance',
          assigned_team TEXT NOT NULL DEFAULT 'Technical Team',
          team_id TEXT,
          hardware_device_type TEXT,
          target_system TEXT,
          user_request_action TEXT,
          priority_stars INTEGER NOT NULL DEFAULT 2,
          priority TEXT NOT NULL DEFAULT 'Medium',
          stage TEXT NOT NULL DEFAULT 'New',
          status TEXT NOT NULL DEFAULT 'Open',
          category TEXT NOT NULL DEFAULT 'Hardware & Devices',
          department TEXT NOT NULL DEFAULT 'IT Service Desk',
          created_by TEXT,
          assigned_to TEXT,
          requester_id TEXT NOT NULL DEFAULT 'USR-EMP-001',
          requester_name TEXT NOT NULL DEFAULT 'Employee',
          requester_email TEXT NOT NULL DEFAULT 'employee@company.gov',
          requester_dept TEXT DEFAULT 'IT Service Desk',
          requester_user_type TEXT DEFAULT 'Operational User',
          assignee_id TEXT,
          assignee_name TEXT,
          assignee_role TEXT,
          response_sla_minutes INTEGER DEFAULT 240,
          resolution_sla_minutes INTEGER DEFAULT 1440,
          response_due_at TIMESTAMP,
          resolution_due_at TIMESTAMP,
          is_response_breached BOOLEAN DEFAULT FALSE,
          is_resolution_breached BOOLEAN DEFAULT FALSE,
          responded_at TIMESTAMP,
          resolved_at TIMESTAMP,
          closed_at TIMESTAMP,
          dept_request TEXT,
          user_request_details TEXT,
          hardware_details TEXT,
          tags TEXT[] DEFAULT ARRAY[]::TEXT[],
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Add columns to tickets if they don't exist
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS ticket_no TEXT;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS ticket_type TEXT DEFAULT 'Hardware Maintenance';
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS assigned_team TEXT DEFAULT 'Technical Team';
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS team_id TEXT;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS hardware_device_type TEXT;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS target_system TEXT;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS user_request_action TEXT;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS priority_stars INTEGER DEFAULT 2;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS stage TEXT DEFAULT 'New';
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'Hardware & Devices';
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS requester_id TEXT DEFAULT 'USR-EMP-001';
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS requester_name TEXT DEFAULT 'Employee';
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS requester_email TEXT DEFAULT 'employee@company.gov';
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS requester_dept TEXT DEFAULT 'IT Service Desk';
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS requester_user_type TEXT DEFAULT 'Operational User';
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS assignee_id TEXT;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS assignee_name TEXT;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS assignee_role TEXT;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS response_sla_minutes INTEGER DEFAULT 240;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS resolution_sla_minutes INTEGER DEFAULT 1440;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS response_due_at TIMESTAMP;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS resolution_due_at TIMESTAMP;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS is_response_breached BOOLEAN DEFAULT FALSE;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS is_resolution_breached BOOLEAN DEFAULT FALSE;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS responded_at TIMESTAMP;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS resolved_at TIMESTAMP;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS closed_at TIMESTAMP;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS dept_request TEXT;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS user_request_details TEXT;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS hardware_details TEXT;
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS tags TEXT[] DEFAULT ARRAY[]::TEXT[];

        -- Ticket Comments
        CREATE TABLE IF NOT EXISTS ticket_comments (
          id SERIAL PRIMARY KEY,
          ticket_id INTEGER REFERENCES tickets(id) ON DELETE CASCADE,
          ticket_no TEXT,
          author_id TEXT NOT NULL,
          author_name TEXT NOT NULL DEFAULT 'Support Agent',
          author_role TEXT DEFAULT 'Employee',
          author_user_type TEXT DEFAULT 'Operational User',
          author_email TEXT DEFAULT '',
          content TEXT NOT NULL,
          is_internal BOOLEAN DEFAULT FALSE,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        ALTER TABLE ticket_comments ADD COLUMN IF NOT EXISTS ticket_no TEXT;
        ALTER TABLE ticket_comments ADD COLUMN IF NOT EXISTS author_name TEXT DEFAULT 'Support Agent';
        ALTER TABLE ticket_comments ADD COLUMN IF NOT EXISTS author_role TEXT DEFAULT 'Employee';
        ALTER TABLE ticket_comments ADD COLUMN IF NOT EXISTS author_user_type TEXT DEFAULT 'Operational User';
        ALTER TABLE ticket_comments ADD COLUMN IF NOT EXISTS author_email TEXT DEFAULT '';
        ALTER TABLE ticket_comments ADD COLUMN IF NOT EXISTS is_internal BOOLEAN DEFAULT FALSE;

        -- Ticket History
        CREATE TABLE IF NOT EXISTS ticket_history (
          id SERIAL PRIMARY KEY,
          ticket_id INTEGER REFERENCES tickets(id) ON DELETE CASCADE,
          ticket_no TEXT,
          actor_id TEXT,
          actor_name TEXT NOT NULL,
          actor_role TEXT DEFAULT 'Employee',
          actor_user_type TEXT DEFAULT 'Operational User',
          action TEXT NOT NULL,
          details TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Ticket Attachments
        CREATE TABLE IF NOT EXISTS ticket_attachments (
          id SERIAL PRIMARY KEY,
          ticket_id INTEGER REFERENCES tickets(id) ON DELETE CASCADE,
          ticket_no TEXT,
          file_name TEXT NOT NULL,
          file_size TEXT NOT NULL,
          file_type TEXT NOT NULL,
          data_url TEXT,
          uploaded_by TEXT NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Support Teams
        CREATE TABLE IF NOT EXISTS support_teams (
          id SERIAL PRIMARY KEY,
          team_key TEXT UNIQUE NOT NULL,
          name TEXT NOT NULL,
          name_ar TEXT NOT NULL,
          type TEXT NOT NULL,
          description TEXT,
          description_ar TEXT,
          member_user_ids TEXT[] DEFAULT ARRAY[]::TEXT[],
          lead_user_id TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- System Settings
        CREATE TABLE IF NOT EXISTS system_settings (
          id SERIAL PRIMARY KEY,
          setting_key TEXT UNIQUE NOT NULL DEFAULT 'default',
          max_picture_attachments INTEGER DEFAULT 3,
          max_attachment_size_bytes INTEGER DEFAULT 5242880,
          max_attachment_size_mb INTEGER DEFAULT 5,
          allowed_image_types TEXT[] DEFAULT ARRAY['image/jpeg', 'image/png']::TEXT[],
          sla_critical_hours INTEGER DEFAULT 4,
          sla_medium_hours INTEGER DEFAULT 24,
          sla_low_hours INTEGER DEFAULT 48,
          serilog_api_url TEXT,
          serilog_api_key TEXT,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Electronic Devices Table
        CREATE TABLE IF NOT EXISTS electronic_devices (
          id SERIAL PRIMARY KEY,
          device_code TEXT UNIQUE NOT NULL,
          category TEXT NOT NULL,
          device_type TEXT NOT NULL,
          brand TEXT NOT NULL,
          model TEXT NOT NULL,
          serial_number TEXT,
          date_of_purchase TEXT NOT NULL,
          warranty_start_date TEXT NOT NULL,
          warranty_period TEXT NOT NULL,
          department TEXT NOT NULL,
          department_ar TEXT,
          status TEXT NOT NULL DEFAULT 'Operational',
          ip_address TEXT,
          mac_address TEXT,
          location TEXT,
          assigned_employee TEXT,
          department_history JSONB DEFAULT '[]'::jsonb,
          maintenance_history JSONB DEFAULT '[]'::jsonb,
          notes TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
      `);

      // Try grants if user exists
      try {
        await client.query(`
          GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO ai_studio_app_user;
          GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO ai_studio_app_user;
        `);
      } catch (_) {}

      // 2. Seed initial default support teams if empty
      const teamsCount = await client.query('SELECT COUNT(*) FROM support_teams');
      if (parseInt(teamsCount.rows[0].count, 10) === 0) {
        await client.query(`
          INSERT INTO support_teams (team_key, name, name_ar, type, description, description_ar, member_user_ids)
          VALUES 
            ('tech-team', 'Technical Team', 'الفريق الفني للعتاد والأجهزة', 'Technical Team', 'Specialized team for physical machines, barcode scanners, printers and hardware maintenance.', 'فريق الصيانة الميدانية للأجهزة، الطابعات، أجهزة البصمة والماسحات الضوئية.', ARRAY['usr_002', 'usr_003']),
            ('db-admin-team', 'Database and Systems Admins', 'إدارة قواعد البيانات والأنظمة', 'Database and Systems Admins', 'Core systems administration, database migrations, backups and application servers.', 'إدارة قواعد البيانات ونظام IMS والأرشفة والصلاحيات المركزية.', ARRAY['usr_001', 'usr_002']),
            ('security-team', 'Security Team', 'فريق أمن المعلومات والامتثال', 'Security Team', 'SOC / Cybersecurity monitoring, audit tracking, policy enforcement and account lockouts.', 'فريق أمن المعلومات، تدقيق الصلاحيات ومكافحة التهديدات السيبرانية.', ARRAY['usr_001']);
        `);
      }

      // 3. Seed default system settings if empty
      const settingsCount = await client.query('SELECT COUNT(*) FROM system_settings');
      if (parseInt(settingsCount.rows[0].count, 10) === 0) {
        await client.query(`
          INSERT INTO system_settings (setting_key, max_picture_attachments, max_attachment_size_bytes, max_attachment_size_mb, allowed_image_types, sla_critical_hours, sla_medium_hours, sla_low_hours)
          VALUES ('default', 3, 5242880, 5, ARRAY['image/jpeg', 'image/png'], 4, 24, 48);
        `);
      }

      // 4. Seed initial electronic & network devices if empty
      const devicesCount = await client.query('SELECT COUNT(*) FROM electronic_devices');
      if (parseInt(devicesCount.rows[0].count, 10) === 0) {
        await client.query(`
          INSERT INTO electronic_devices 
            (device_code, category, device_type, brand, model, serial_number, date_of_purchase, warranty_start_date, warranty_period, department, department_ar, status, ip_address, mac_address, location, assigned_employee, department_history, maintenance_history, notes)
          VALUES
            ('DEV-2024-001', 'electronic', 'Computer', 'Dell', 'OptiPlex 7090 Tower Core i7 32GB', 'DL-7090-88341', '2024-01-15', '2024-01-15', '36 Months', 'Information Technology', 'تكنولوجيا المعلومات', 'Operational', '192.168.10.45', '00:1A:2B:3C:4D:5E', 'HQ Building - 3rd Floor, Server Room A', 'Ahmed Faris', 
             '[{"id":"dh-1","department":"Human Resources","departmentAr":"الموارد البشرية","assignedDate":"2024-01-15","transferredDate":"2024-06-20","transferredBy":"Admin","reason":"Reassigned to IT infrastructure management"}]'::jsonb,
             '[{"id":"mh-1","date":"2024-07-10","type":"Routine","description":"Annual dust cleaning, thermal paste replacement, and RAM diagnostic pass.","performedBy":"Hardware Tech Team","status":"Completed","cost":45}]'::jsonb,
             'High-performance development and monitoring workstation'),
            
            ('DEV-2024-002', 'electronic', 'Printer', 'HP', 'LaserJet Enterprise M608dn Duplex Network', 'HP-LJ-992144', '2024-02-10', '2024-02-10', '24 Months', 'Operations', 'العمليات والتنفيذ', 'Operational', '192.168.10.120', '00:14:22:01:23:45', 'Floor 1 - Administrative Reception Desk', NULL,
             '[]'::jsonb,
             '[{"id":"mh-2","date":"2024-08-15","type":"Routine","description":"Replaced pickup rollers and installed genuine HP high-yield toner cartridge.","performedBy":"IT Field Support","status":"Completed","cost":120}]'::jsonb,
             'High-speed heavy duty black & white department printer'),

            ('DEV-2024-003', 'electronic', 'Screen', 'Dell', 'UltraSharp U2722D 27" QHD IPS Monitor', 'DL-US-349012', '2024-03-01', '2024-03-01', '36 Months', 'Software Development', 'تطوير البرمجيات', 'Operational', NULL, NULL, 'Engineering Wing - Workstation 12', 'Software Lead',
             '[]'::jsonb, '[]'::jsonb, 'Color calibrated monitor for design and system UI testing'),

            ('DEV-2024-004', 'electronic', 'Fingerprint device', 'ZKTeco', 'SilkBio-101TC Multi-Biometric Time Attendance', 'ZK-SB-774109', '2023-11-20', '2023-11-20', '24 Months', 'Human Resources', 'الموارد البشرية', 'Operational', '192.168.10.15', 'B8:27:EB:44:91:02', 'Main Gate - Employee Access Portal', NULL,
             '[]'::jsonb,
             '[{"id":"mh-3","date":"2024-05-12","type":"Inspection","description":"Biometric optical sensor calibration and firmware security patch applied.","performedBy":"Security & Hardware Team","status":"Completed","cost":0}]'::jsonb,
             'Employee entry & attendance time log device connected to HR payroll'),

            ('DEV-2024-005', 'electronic', 'Scanner', 'Fujitsu', 'fi-7160 High-Speed Sheetfed Document Scanner', 'FJ-7160-55120', '2024-04-05', '2024-04-05', '12 Months', 'Electronic Archiving & Records', 'الأرشفة الإلكترونية والسجلات', 'Operational', NULL, NULL, 'Archiving Central Vault - Ingestion Station', 'Archive Specialist',
             '[{"id":"dh-2","department":"Customer Support & Helpdesk","departmentAr":"دعم العملاء ومكتب المساعدة","assignedDate":"2024-04-05","transferredDate":"2024-07-01","transferredBy":"Records Director","reason":"Dedicated for mass digitizing historical government archives."}]'::jsonb,
             '[{"id":"mh-4","date":"2024-09-02","type":"Repair","description":"Cleared paper feed path jam and ultrasonic sensor recalibration.","performedBy":"Vendor Service Tech","status":"Completed","cost":85}]'::jsonb,
             'Double-sided color document ingestion scanner with OCR feeder'),

            ('DEV-2024-006', 'network', 'router', 'Cisco', 'ISR 4331 Gigabit Enterprise Security Gateway', 'FOC241908AB', '2023-09-10', '2023-09-10', '36 Months', 'Cloud Infrastructure', 'البنية التحتية السحابية', 'Operational', '10.0.0.1', '00:00:0C:07:AC:01', 'MDF Main Server Room - Rack 01-U22', 'Network Architect',
             '[]'::jsonb,
             '[{"id":"mh-5","date":"2024-06-18","type":"Upgrade","description":"Cisco IOS XE security upgrade to version 17.9.4a and redundant power supply test.","performedBy":"Network Infrastructure Team","status":"Completed","cost":0}]'::jsonb,
             'Primary core border router handling WAN routing and VPN tunnels'),

            ('DEV-2024-007', 'network', 'switch', 'Cisco', 'Catalyst 2960-X 48 GigE PoE+ 740W', 'FCW2145A092', '2023-10-15', '2023-10-15', '36 Months', 'Information Technology', 'تكنولوجيا المعلومات', 'Operational', '10.0.0.11', '00:1E:F7:28:90:80', 'IDF-2 Network Closet - 2nd Floor West', 'Network Admin',
             '[]'::jsonb,
             '[{"id":"mh-6","date":"2024-08-01","type":"Routine","description":"PoE power budget audit, port security inspection, and cable management re-dressing.","performedBy":"Network Admin","status":"Completed","cost":0}]'::jsonb,
             'Distribution PoE+ switch powering VoIP desk phones and APs'),

            ('DEV-2024-008', 'network', 'access point', 'Cisco', 'Catalyst 9115AX Series Wi-Fi 6 AP', 'FOC2510A499', '2024-01-20', '2024-01-20', '36 Months', 'Operations', 'العمليات والتنفيذ', 'Operational', '10.0.5.24', '70:69:79:AA:BB:CC', 'Building B - Executive Conference Hall Ceiling', NULL,
             '[]'::jsonb, '[]'::jsonb, 'High-density Wi-Fi 6 wireless access point');
        `);
      }

      console.log('✅ Ticket tables initialized and verified successfully in PostgreSQL database');
    } finally {
      client.release();
    }
  } catch (err: any) {
    console.error('⚠️ Ticket tables initialization error:', err.message);
    if (err.message?.includes('failed to initialize properly') || err.message?.includes('could not open file "base/')) {
      console.log('🔄 Attempting recovery and retry for ticket tables initialization...');
      try {
        const { resetPgliteInstance } = await import('../../db/index.ts');
        resetPgliteInstance();
        const retryPool = createPool();
        const retryClient = await retryPool.connect();
        try {
          await initTicketTables();
        } finally {
          retryClient.release();
        }
      } catch (retryErr: any) {
        console.error('Ticket tables recovery retry failed:', retryErr.message);
      }
    }
  }
}

