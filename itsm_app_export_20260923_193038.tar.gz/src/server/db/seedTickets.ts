// src/server/db/seedTickets.ts
import { db } from '../../db/index.ts';
import { sql } from 'drizzle-orm';
import { INITIAL_TICKETS } from '../../data/mockData.ts';

export async function seedTicketsIfEmpty(): Promise<void> {
  try {
    // Delete legacy mock and example tickets
    await db.execute(sql`DELETE FROM ticket_comments WHERE ticket_no IN ('TCK-2026-1042', 'TCK-2026-1041', 'TCK-2026-1040', 'TCK-2026-1039', 'TCK-2026-1038')`);
    await db.execute(sql`DELETE FROM ticket_history WHERE ticket_no IN ('TCK-2026-1042', 'TCK-2026-1041', 'TCK-2026-1040', 'TCK-2026-1039', 'TCK-2026-1038')`);
    await db.execute(sql`DELETE FROM ticket_attachments WHERE ticket_no IN ('TCK-2026-1042', 'TCK-2026-1041', 'TCK-2026-1040', 'TCK-2026-1039', 'TCK-2026-1038')`);
    await db.execute(sql`DELETE FROM tickets WHERE ticket_no IN ('TCK-2026-1042', 'TCK-2026-1041', 'TCK-2026-1040', 'TCK-2026-1039', 'TCK-2026-1038')`);
    console.log('🧹 Cleaned up example tickets from database.');

    if (!INITIAL_TICKETS || INITIAL_TICKETS.length === 0) {
      return;
    }
  } catch (err: any) {
    console.error('⚠️ Ticket seeding notice:', err.message);
  }
}
