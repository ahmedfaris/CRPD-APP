import { Router } from 'express';
import { requireAuth, AuthRequest } from '../../middleware/auth.ts';
import { db } from '../../db/index.ts';
import { electronicDevices } from '../../db/schema.ts';
import { eq, desc, ilike, or } from 'drizzle-orm';
import { logger } from '../utils/logger.ts';

const router = Router();

// GET /api/devices - List all electronic and network devices
router.get('/', requireAuth, async (req: AuthRequest, res) => {
  try {
    const { category, type, search, department } = req.query;

    let devices = await db.select().from(electronicDevices).orderBy(desc(electronicDevices.createdAt));

    if (category && typeof category === 'string' && category !== 'ALL') {
      devices = devices.filter(d => d.category.toLowerCase() === category.toLowerCase());
    }

    if (type && typeof type === 'string' && type !== 'ALL') {
      devices = devices.filter(d => d.deviceType.toLowerCase() === type.toLowerCase());
    }

    if (department && typeof department === 'string' && department !== 'ALL') {
      devices = devices.filter(d => d.department.toLowerCase() === department.toLowerCase());
    }

    if (search && typeof search === 'string') {
      const q = search.toLowerCase();
      devices = devices.filter(d => 
        d.deviceCode.toLowerCase().includes(q) ||
        d.brand.toLowerCase().includes(q) ||
        d.model.toLowerCase().includes(q) ||
        (d.serialNumber && d.serialNumber.toLowerCase().includes(q)) ||
        d.department.toLowerCase().includes(q) ||
        (d.ipAddress && d.ipAddress.toLowerCase().includes(q)) ||
        (d.assignedEmployee && d.assignedEmployee.toLowerCase().includes(q))
      );
    }

    // Parse JSON fields safely if stringified
    const mapped = devices.map(d => ({
      ...d,
      departmentHistory: typeof d.departmentHistory === 'string' ? JSON.parse(d.departmentHistory) : (d.departmentHistory || []),
      maintenanceHistory: typeof d.maintenanceHistory === 'string' ? JSON.parse(d.maintenanceHistory) : (d.maintenanceHistory || [])
    }));

    res.json({ success: true, count: mapped.length, data: mapped });
  } catch (error: any) {
    logger.error('Error fetching devices', { error: error.message });
    res.status(500).json({ error: 'Failed to fetch devices', details: error.message });
  }
});

// GET /api/devices/:id - Get single device
router.get('/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const id = parseInt(req.params.id as string, 10);
    const [device] = await db.select().from(electronicDevices).where(eq(electronicDevices.id, id));

    if (!device) {
      return res.status(404).json({ error: 'Device not found' });
    }

    const mapped = {
      ...device,
      departmentHistory: typeof device.departmentHistory === 'string' ? JSON.parse(device.departmentHistory) : (device.departmentHistory || []),
      maintenanceHistory: typeof device.maintenanceHistory === 'string' ? JSON.parse(device.maintenanceHistory) : (device.maintenanceHistory || [])
    };

    res.json({ success: true, data: mapped });
  } catch (error: any) {
    logger.error('Error fetching device', { error: error.message });
    res.status(500).json({ error: 'Failed to fetch device', details: error.message });
  }
});

// POST /api/devices - Register new device
router.post('/', requireAuth, async (req: AuthRequest, res) => {
  try {
    const body = req.body;
    if (!body.category || !body.deviceType || !body.brand || !body.model || !body.department) {
      return res.status(400).json({ error: 'Required fields missing: category, deviceType, brand, model, department' });
    }

    const year = new Date().getFullYear();
    const randomSeq = Math.floor(100 + Math.random() * 900);
    const generatedCode = body.deviceCode || `DEV-${year}-${randomSeq}`;

    const [created] = await db.insert(electronicDevices).values({
      deviceCode: generatedCode,
      category: body.category,
      deviceType: body.deviceType,
      brand: body.brand,
      model: body.model,
      serialNumber: body.serialNumber || null,
      dateOfPurchase: body.dateOfPurchase || new Date().toISOString().split('T')[0],
      warrantyStartDate: body.warrantyStartDate || body.dateOfPurchase || new Date().toISOString().split('T')[0],
      warrantyPeriod: body.warrantyPeriod || '24 Months',
      department: body.department,
      departmentAr: body.departmentAr || null,
      status: body.status || 'Operational',
      ipAddress: body.ipAddress || null,
      macAddress: body.macAddress || null,
      location: body.location || null,
      assignedEmployee: body.assignedEmployee || null,
      departmentHistory: body.departmentHistory || [],
      maintenanceHistory: body.maintenanceHistory || [],
      notes: body.notes || null,
    }).returning();

    logger.info('Device registered', { deviceCode: created.deviceCode, user: req.user?.email });
    res.status(201).json({ success: true, data: created });
  } catch (error: any) {
    logger.error('Error creating device', { error: error.message });
    res.status(500).json({ error: 'Failed to create device', details: error.message });
  }
});

// PUT /api/devices/:id - Update device
router.put('/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const id = parseInt(req.params.id as string, 10);
    const body = req.body;

    const [existing] = await db.select().from(electronicDevices).where(eq(electronicDevices.id, id));
    if (!existing) {
      return res.status(404).json({ error: 'Device not found' });
    }

    const [updated] = await db.update(electronicDevices).set({
      category: body.category !== undefined ? body.category : existing.category,
      deviceType: body.deviceType !== undefined ? body.deviceType : existing.deviceType,
      brand: body.brand !== undefined ? body.brand : existing.brand,
      model: body.model !== undefined ? body.model : existing.model,
      serialNumber: body.serialNumber !== undefined ? body.serialNumber : existing.serialNumber,
      dateOfPurchase: body.dateOfPurchase !== undefined ? body.dateOfPurchase : existing.dateOfPurchase,
      warrantyStartDate: body.warrantyStartDate !== undefined ? body.warrantyStartDate : existing.warrantyStartDate,
      warrantyPeriod: body.warrantyPeriod !== undefined ? body.warrantyPeriod : existing.warrantyPeriod,
      department: body.department !== undefined ? body.department : existing.department,
      departmentAr: body.departmentAr !== undefined ? body.departmentAr : existing.departmentAr,
      status: body.status !== undefined ? body.status : existing.status,
      ipAddress: body.ipAddress !== undefined ? body.ipAddress : existing.ipAddress,
      macAddress: body.macAddress !== undefined ? body.macAddress : existing.macAddress,
      location: body.location !== undefined ? body.location : existing.location,
      assignedEmployee: body.assignedEmployee !== undefined ? body.assignedEmployee : existing.assignedEmployee,
      notes: body.notes !== undefined ? body.notes : existing.notes,
      updatedAt: new Date(),
    }).where(eq(electronicDevices.id, id)).returning();

    res.json({ success: true, data: updated });
  } catch (error: any) {
    logger.error('Error updating device', { error: error.message });
    res.status(500).json({ error: 'Failed to update device', details: error.message });
  }
});

// POST /api/devices/:id/transfer - Transfer device to a different department
router.post('/:id/transfer', requireAuth, async (req: AuthRequest, res) => {
  try {
    const id = parseInt(req.params.id as string, 10);
    const { newDepartment, newDepartmentAr, reason, transferDate } = req.body;

    if (!newDepartment) {
      return res.status(400).json({ error: 'New department is required' });
    }

    const [device] = await db.select().from(electronicDevices).where(eq(electronicDevices.id, id));
    if (!device) {
      return res.status(404).json({ error: 'Device not found' });
    }

    const currentHistory = Array.isArray(device.departmentHistory) 
      ? device.departmentHistory 
      : (typeof device.departmentHistory === 'string' ? JSON.parse(device.departmentHistory) : []);

    const effectiveDate = transferDate || new Date().toISOString().split('T')[0];
    
    // Add current department to historical records
    const historyEntry = {
      id: 'dh-' + Date.now(),
      department: device.department,
      departmentAr: device.departmentAr || device.department,
      assignedDate: device.dateOfPurchase,
      transferredDate: effectiveDate,
      transferredBy: req.user?.fullName || req.user?.email || 'System User',
      reason: reason || 'Departmental reorganization / equipment reassignment'
    };

    const updatedHistory = [...currentHistory, historyEntry];

    const [updated] = await db.update(electronicDevices).set({
      department: newDepartment,
      departmentAr: newDepartmentAr || null,
      departmentHistory: updatedHistory,
      updatedAt: new Date()
    }).where(eq(electronicDevices.id, id)).returning();

    logger.info('Device department transferred', {
      deviceId: id,
      from: device.department,
      to: newDepartment,
      user: req.user?.email
    });

    res.json({ success: true, data: updated, historyEntry });
  } catch (error: any) {
    logger.error('Error transferring device department', { error: error.message });
    res.status(500).json({ error: 'Failed to transfer device', details: error.message });
  }
});

// POST /api/devices/:id/maintenance - Add a maintenance record
router.post('/:id/maintenance', requireAuth, async (req: AuthRequest, res) => {
  try {
    const id = parseInt(req.params.id as string, 10);
    const { date, type, description, performedBy, cost, status, notes } = req.body;

    if (!description || !type) {
      return res.status(400).json({ error: 'Maintenance type and description are required' });
    }

    const [device] = await db.select().from(electronicDevices).where(eq(electronicDevices.id, id));
    if (!device) {
      return res.status(404).json({ error: 'Device not found' });
    }

    const currentHistory = Array.isArray(device.maintenanceHistory) 
      ? device.maintenanceHistory 
      : (typeof device.maintenanceHistory === 'string' ? JSON.parse(device.maintenanceHistory) : []);

    const maintenanceEntry = {
      id: 'mh-' + Date.now(),
      date: date || new Date().toISOString().split('T')[0],
      type: type || 'Routine',
      description,
      performedBy: performedBy || req.user?.fullName || 'Internal IT Technician',
      cost: cost ? parseFloat(cost) : 0,
      status: status || 'Completed',
      notes: notes || ''
    };

    const updatedHistory = [...currentHistory, maintenanceEntry];

    // If maintenance status is 'In Progress', optionally mark device status
    const newDeviceStatus = status === 'In Progress' ? 'Under Maintenance' : device.status === 'Under Maintenance' ? 'Operational' : device.status;

    const [updated] = await db.update(electronicDevices).set({
      maintenanceHistory: updatedHistory,
      status: newDeviceStatus,
      updatedAt: new Date()
    }).where(eq(electronicDevices.id, id)).returning();

    logger.info('Maintenance record added to device', {
      deviceId: id,
      type,
      user: req.user?.email
    });

    res.json({ success: true, data: updated, maintenanceEntry });
  } catch (error: any) {
    logger.error('Error logging maintenance record', { error: error.message });
    res.status(500).json({ error: 'Failed to log maintenance record', details: error.message });
  }
});

// DELETE /api/devices/:id - Delete device
router.delete('/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const id = parseInt(req.params.id as string, 10);
    const [deleted] = await db.delete(electronicDevices).where(eq(electronicDevices.id, id)).returning();

    if (!deleted) {
      return res.status(404).json({ error: 'Device not found' });
    }

    logger.info('Device deleted', { deviceId: id, code: deleted.deviceCode });
    res.json({ success: true, message: 'Device deleted successfully' });
  } catch (error: any) {
    logger.error('Error deleting device', { error: error.message });
    res.status(500).json({ error: 'Failed to delete device', details: error.message });
  }
});

export default router;
